# Changelog / Değişiklik günlüğü

## [3.2.0] - 2026-11-20

### Türkçe

**Yeni**
- **F5 > Tuş atamaları:** her trainer tuşunu oyunun içinden değiştir (keyconfig.lua'yı açmaya gerek yok). Hızlı hilelere (ölümsüzlük, sınırsız cephane...) kendi tuşunu ata: tek tuşla aç / kapat. Işınlanma ve profil menülerine de tuş atanabilir.
- **F5 > Işınlanma noktaları** (oyunda): her haritada 30'a kadar nokta kaydet, tek tıkla geri ışınlan, son ışınlanmayı geri al, ekipten birine (oyuncu / bot) veya ekrandaki bir hedef işaretine ışınlan.
- **F5 > Hile profilleri:** açık hızlı hileleri profil olarak kaydet, hepsini birden aç; "otomatik" işaretli profil her soygun başında kendiliğinden açılır.
- **Soygun girişini otomatik geç** (F5 > PPR Kurulum Menüsü > Çeşitli, sadece kurucu).
- Trainer'daki bütün yazılar Türkçe (son İngilizce kalanlar: Terminator HUD, hata ayıklama HUD'u, FOV ipucu).

**Düzeltmeler** (bütün kod PAYDAY 2'nin güncel kaynak koduyla karşılaştırıldı)
- "Düzenlenmiş yetenekleri koru" (varsayılan açık) eski oyun kodunu kopyalıyordu; Copycat gibi seçmeli avantaj kartları uygulanmıyordu.
- Flaş / sis bombası kısayolları polis bombalarını oyun kapanana kadar bozuyordu; artık oyunun kendi senkron bombaları kullanılıyor. Flaş kısayolu artık kendi bombanı bedava atar.
- Kutsal el bombası sonraki bütün bomba atışlarını değiştiriyor ve kurucuda çöküyordu.
- Haritanın yüklemediği bir birimi (düşman, araç, eşya) çıkarmak oyunu masaüstüne atıyordu; artık uyarı çıkıyor.
- "Envanter yuvalarını artır" 320. yuvadan sonra bozuktu; artık 480 yuva.
- "Torba bekleme süresi yok" kapatılamıyordu. "Etkileşimde etrafa bak" ve "Ayakta çatal ayak" eski kod kopyalarıydı.
- İstemcide çanta verme (GiveBag) kaldırılmış bir ağ mesajı yüzünden çöküyordu.
- AimBot kısayolu ilk hedefte çöküyordu. LEGO favorilerinde Geri tuşu çalışmıyordu, dosya yoksa menü çöküyordu.
- Şöhret kontrolü tamamen kapatılıyordu; artık güvenli şekilde çalışıyor. Giriş atlama özelliği hiç çalışmıyordu.
- Taret kalkan düzeltmesi güncel oyunda gereksiz (oyun kendisi yapıyor). Konsol, nişangâh ve silah menüsünde tanımsız değişken hataları.
- Çökme uyarısındaki "Evet" hiçbir şey açmıyordu (eksik kısayol); artık PAYDAY 2'nin `crash.txt` dosyasını açıyor. Eski bir geliştiricinin bilgisayar bilgilerini içeren kısayol dosyaları (`Logfiles`) kaldırıldı.

### English

**New**
- **F5 > Key bindings:** change any trainer key in game (no need to edit keyconfig.lua). Bind quick cheats (god mode, infinite ammo...) to their own key: one key switches them on / off. The teleport and profile menus can get keys too.
- **F5 > Teleport points** (in game): save up to 30 spots per map, teleport back with one click, undo the last teleport, teleport to a crew member (player / bot) or to a waypoint on screen.
- **F5 > Cheat profiles:** save which quick cheats are on and switch them on together; a profile marked "automatic" switches on at the start of every heist.
- **Auto-Skip Heist Intro** (F5 > PPR Setup Menu > Miscellaneous, host only).
- Every trainer text is translated (the last English ones: Terminator HUD, debug HUD, FOV hint).

**Fixed** (all code was compared with PAYDAY 2's current source code)
- "Keep Edited Skills" (on by default) used a copy of old game code; perk decks with multiple-choice cards such as Copycat did not work.
- Flashbang / smoke grenade keys broke the police grenades until the game was restarted; they now use the game's own synced grenades. The flash key now throws your own grenade for free.
- Holy hand grenade changed every later grenade throw and crashed as host.
- Spawning a unit (enemy, vehicle, prop) that the map has not loaded crashed the game to desktop; a message is shown instead.
- "Extend Inventory Slots" was broken past slot 320; now 480 slots.
- "No bag cooldown" could not be turned off. "Interact and look around" and "Bipod standing" were old code copies.
- Giving a bag as client (GiveBag) crashed because of a network message the game removed.
- The AimBot key crashed on its first target. LEGO favourites: Back did nothing and a missing file crashed the menu.
- The infamy check was switched off completely; it now runs safely. Skip intro never worked.
- The sentry shield fix is no longer needed on the current game (the game does it). Undefined variables in the console, crosshair and weapon menu code.
- "Yes" in the crash warning opened nothing (missing shortcut); it now opens PAYDAY 2's `crash.txt`. Removed shortcut files (`Logfiles`) that contained an old developer's PC details.

## [3.1.0] - 2026-11-20

### Türkçe
- Oyunda sağ üstte açık hileler listesi (başkasının lobisinde kırmızı).
- F5: "Bütün hileleri kapat", hızlı hileler listesi; lobide tek tıkla "Bütün silah parçalarını aç" / "Bütün eşyaları aç".
- Hazır profiller: F2 > Ayar dosyası yükle > Gizlilik / Çatışma.
- Oyun güncellemesi bir özelliği bozarsa trainer'ın geri kalanı çalışmaya devam eder; yüklenemeyenler F5'te yazar.
- Düzeltme: ayar dosyası silme / yeniden adlandırma çalışmıyordu.

### English
- Active cheats list in the top right corner in game (red on someone else's lobby).
- F5: "Turn every cheat off", quick cheats list; in the lobby one-click "Unlock all weapon mods" / "Unlock all items".
- Preset profiles: F2 > Load configuration file > Stealth / Loud.
- One broken feature (e.g. after a game update) no longer stops the trainer; failures are listed in F5.
- Fixed: deleting / renaming config files did nothing.

## [3.0.0] - 2026-11-20

### Türkçe
- Tam Türkçe ve İngilizce arayüz, menüden anında dil değiştirme; yeni F5 Ana Menü; F1'de otomatik tuş listesi; menülerde klavye ile gezinme.
- Düzeltmeler: sohbete yazarken kısayolların tetiklenmesi, hiç yüklenmeyen eski Türkçe dosya, varsayılan zorluk hatası, çalışmayan SuperBLT kısayolları, lobide "herkesi hazır yap".
- Güvenlik: kapanmış sitelerden dosya indirip çalıştıran kodlar kaldırıldı; trainer hiçbir yere bağlanmıyor.
- Kaldırılanlar: DLC kilit açıcı, ücretli skin açma, kasa simülatörü, kart sahteleme, eşya kopyalama, anti-hile / sahiplik doğrulamasını atlatma, modları gizleme, "modsuz lobi", isim taklidi, ekipman tespitinden kaçma, Troll menüsü, PvP modu.

### English
- Full English / Turkish interface with instant language switch; new F5 hub; auto-generated key list in F1; keyboard navigation in menus.
- Fixed: hotkeys firing while typing in chat, the never-loading Turkish file, the default difficulty bug, dead SuperBLT keybinds, "force ready" in lobbies.
- Security: removed code that downloaded and ran files from dead websites; the trainer makes no network requests.
- Removed: DLC unlocker, paid skin unlocks, safe simulator, loot card spoofing, item copying, anti-cheat / ownership verification bypass, mod hiding, "not modded" lobby, name spoofing, equipment-detection evasion, troll menu, PvP mode.
