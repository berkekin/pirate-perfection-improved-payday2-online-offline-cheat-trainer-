@echo off
setlocal
cd /d "%~dp0"
title PPR Improved Edition - GitHub'a yukle / upload to GitHub

echo ==============================================================
echo  PPR Improved Edition v3.2.0 - GitHub'a yukleme
echo ==============================================================
echo.
echo Once GitHub'da BOS bir depo ac (README, lisans, .gitignore EKLEME):
echo   https://github.com/new   (ornek ad: pirate-perfection-improved)
echo First create an EMPTY repository on GitHub (no README, license or .gitignore).
echo.

where git >nul 2>nul
if errorlevel 1 (
  echo [HATA] Git bulunamadi. Kur: https://git-scm.com/download/win  ve bu dosyayi tekrar calistir.
  echo [ERROR] Git not found. Install it from the link above and run this file again.
  pause
  exit /b 1
)

set "GN="
for /f "delims=" %%i in ('git config user.name 2^>nul') do set "GN=%%i"
if not defined GN (
  set /p "GN=GitHub kullanici adin / your GitHub user name: "
)
if defined GN git config --global user.name "%GN%"

set "GE="
for /f "delims=" %%i in ('git config user.email 2^>nul') do set "GE=%%i"
if not defined GE (
  echo GitHub e-postan ^(GitHub ^> Settings ^> Emails; gizli adres de olur: ...@users.noreply.github.com^)
  set /p "GE=Your GitHub e-mail: "
)
if defined GE git config --global user.email "%GE%"

set "REPO_URL="
set /p "REPO_URL=Deponun adresi / repository URL (https://github.com/KULLANICI/DEPO.git): "
if not defined REPO_URL (
  echo [HATA] Adres bos. / URL is empty.
  pause
  exit /b 1
)

if not exist ".git" git init -b main

git add -A

> "%TEMP%\ppr_commit_msg.txt" (
  echo PPR Improved Edition v3.2.0
  echo.
  echo Turkish / English edition of the Pirate Perfection Reborn trainer for PAYDAY 2,
  echo checked against the current game: key bindings, teleport points, cheat profiles,
  echo auto-skip intro and 20 fixes. See CHANGELOG.md.
)
git commit -F "%TEMP%\ppr_commit_msg.txt"
del "%TEMP%\ppr_commit_msg.txt" >nul 2>nul

git branch -M main
git remote remove origin >nul 2>nul
git remote add origin "%REPO_URL%"

echo.
echo Yukleniyor... (GitHub giris penceresi acilirsa giris yap / sign in if a GitHub window opens)
git push -u origin main
if errorlevel 1 (
  echo [HATA] Yukleme basarisiz. Depo bos mu, adres dogru mu? / Push failed: is the repository empty and the URL right?
  pause
  exit /b 1
)

git tag v3.2.0 >nul 2>nul
git push origin v3.2.0

echo.
echo TAMAM! Birkac dakika icinde depondaki "Releases" bolumunde kurulum zip'i hazir olur.
echo DONE! In a few minutes the install zip appears under "Releases" in your repository.
pause
