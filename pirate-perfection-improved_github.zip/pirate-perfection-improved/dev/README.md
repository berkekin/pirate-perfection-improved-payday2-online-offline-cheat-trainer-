# dev/ – checks and tests

Everything here runs on Linux / macOS / Windows with [LuaJIT](https://luajit.org/) (the game uses LuaJIT too).
Run the commands from the repository root. GitHub Actions runs the same commands on every push
(`.github/workflows/checks.yml`).

```sh
MOD="mods/[MOD] Pirate Perfection Reborn Trainer! Patron Edition"

# 1. Syntax of every Lua file (LuaJIT; the CI also checks Lua 5.1 with luac5.1 -p)
find "$MOD" -name '*.lua' ! -name 'waypoints_config.lua' -print0 | xargs -0 luajit dev/syncheck.lua

# 2. English / Turkish translations: same keys, same %s / %d placeholders
luajit dev/check_tr.lua "$MOD/Trainer/translations/English.txt" "$MOD/Trainer/translations/Turkish.txt"

# 3. Tests that load the real trainer files in a simulated game
luajit dev/harness.lua "$MOD/"           # menus, translations, key bindings, teleports, profiles, ...
luajit dev/harness_menu.lua "$MOD/"      # the real menu code with a fake GUI
luajit dev/harness_autoinit.lua "$MOD/"  # one broken feature must not stop the others
```

`Trainer/configs/waypoints/waypoints_config.lua` is a plain list read line by line, not Lua code,
so it is skipped by the syntax check.

## Review tools (optional)

These compare the trainer with PAYDAY 2's own Lua code. They need a copy of the game's
decompiled Lua source, e.g. <https://github.com/steam-test1/Payday-2-LuaJIT-Complete>:

```sh
git clone --depth 1 https://github.com/steam-test1/Payday-2-LuaJIT-Complete game-src
python3 dev/api_review.py game-src "$MOD/Trainer"       # hooks, overrides, manager calls, undefined globals
python3 dev/override_review.py game-src "$MOD/Trainer"  # trainer functions that replace game functions
python3 dev/tweak_review.py game-src "$MOD/Trainer"     # tweak_data fields the game no longer has
python3 dev/find_hardcoded.py "$MOD/Trainer"            # visible text that skips the translations
```

The reports are hints, not verdicts: read each finding in the code before changing anything.

## Translations

`Trainer/translations/English.txt` and `Turkish.txt` are the source of truth (UTF-8, no BOM).
Every key must exist in both files with the same placeholders; `check_tr.lua` verifies it.
