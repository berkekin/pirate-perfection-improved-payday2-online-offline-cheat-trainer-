#!/usr/bin/env python3
"""Static review of the trainer against the decompiled PAYDAY 2 Lua source.

Usage: api_review.py <game_src_root> <trainer_root> [report_path]

Reports:
  1. backuper hijack/backup/add_clbk targets that do not exist in the game
  2. trainer method overrides on game classes whose method no longer exists
  3. managers.X:Y() calls where Y is not defined on X's class chain
  4. method names called by the trainer that the game neither defines nor calls
  5. undefined global reads (luajit -bl GGET) per file
"""
import os, re, subprocess, sys, collections

game_root, trainer_root = sys.argv[1], sys.argv[2]
report_path = sys.argv[3] if len(sys.argv) > 3 else None

def lua_files(root):
    for d, _, fs in os.walk(root, followlinks=True):
        for f in fs:
            if f.endswith('.lua'):
                yield os.path.join(d, f)

def read(p):
    with open(p, 'rb') as fh:
        return fh.read().decode('utf-8', 'replace')

RE_CLASS = re.compile(r'^\s*(?:local\s+)?([A-Za-z_]\w*)\s*=\s*(?:\1\s+or\s+)?(?:CoreClass\.)?class\(\s*([A-Za-z_][\w.]*)?', re.M)
RE_METHOD = re.compile(r'function\s+([A-Za-z_]\w*)[:.]([A-Za-z_]\w*)\s*\(')
RE_METHOD2 = re.compile(r'^\s*([A-Za-z_]\w*)\.([A-Za-z_]\w*)\s*=\s*(?:function|[A-Za-z_][\w.:]*)', re.M)
RE_MGR = re.compile(r'managers\.([a-z_]\w*)\s*=\s*(?:[A-Za-z_]\w*\.)?([A-Z]\w*)[:.]new\(')
RE_CALL = re.compile(r':([A-Za-z_]\w*)\s*\(')
RE_GFUNC = re.compile(r'^function\s+([A-Za-z_]\w*)\s*\(', re.M)
RE_GASSIGN = re.compile(r'^([A-Za-z_]\w*)\s*=', re.M)

classes = {}            # name -> parent
methods = collections.defaultdict(set)
game_called = set()
game_defined_names = set()
mgr_class = {}
game_globals = set()

for p in lua_files(game_root):
    s = read(p)
    for m in RE_CLASS.finditer(s):
        name, parent = m.group(1), m.group(2)
        if parent:
            parent = parent.split('.')[-1]
        classes.setdefault(name, parent)
        game_globals.add(name)
    for m in RE_METHOD.finditer(s):
        methods[m.group(1)].add(m.group(2)); game_defined_names.add(m.group(2))
    for m in RE_METHOD2.finditer(s):
        methods[m.group(1)].add(m.group(2)); game_defined_names.add(m.group(2))
    for m in RE_MGR.finditer(s):
        mgr_class.setdefault(m.group(1), m.group(2))
    for m in RE_CALL.finditer(s):
        game_called.add(m.group(1))
    for m in RE_GFUNC.finditer(s):
        game_globals.add(m.group(1))
    for m in RE_GASSIGN.finditer(s):
        game_globals.add(m.group(1))

def has_method(cls, meth, depth=0):
    while cls and depth < 40:
        if meth in methods.get(cls, ()):
            return True
        cls = classes.get(cls)
        depth += 1
    return False

out = []
def section(t):
    out.append('\n== ' + t + ' ==')

tfiles = sorted(lua_files(trainer_root))
rel = lambda p: os.path.relpath(p, trainer_root)
trainer_defined = set()
for p in tfiles:
    s = read(p)
    for m in RE_METHOD.finditer(s):
        trainer_defined.add(m.group(2))
    for m in re.finditer(r'(?:^|[\s,{])([A-Za-z_]\w*)\s*=\s*function', s, re.M):
        trainer_defined.add(m.group(1))

# 1. backuper targets
section('1. backuper targets missing in game')
RE_BK = re.compile(r'backuper:\w+\(\s*["\']([A-Za-z_]\w*)\.([A-Za-z_]\w*)["\']')
for p in tfiles:
    for m in RE_BK.finditer(read(p)):
        c, f = m.group(1), m.group(2)
        if c in classes and not has_method(c, f):
            out.append('%s: %s.%s' % (rel(p), c, f))
        elif c not in classes:
            out.append('%s: %s.%s (class unknown)' % (rel(p), c, f))

# 2. overrides of missing methods
section('2. trainer defines method on game class, game has no such method')
for p in tfiles:
    s = read(p)
    for m in RE_METHOD.finditer(s):
        c, f = m.group(1), m.group(2)
        if c in classes and not has_method(c, f):
            out.append('%s: %s:%s' % (rel(p), c, f))

# 3. managers calls
section('3. managers.X:Y() with Y missing on class chain')
RE_MCALL = re.compile(r'managers\.([a-z_]\w*)\s*:\s*([A-Za-z_]\w*)\s*\(')
seen = set()
for p in tfiles:
    for m in RE_MCALL.finditer(read(p)):
        mg, f = m.group(1), m.group(2)
        key = (rel(p), mg, f)
        if key in seen:
            continue
        seen.add(key)
        cls = mgr_class.get(mg)
        if not cls:
            out.append('%s: managers.%s (manager unknown) :%s' % key)
        elif not has_method(cls, f) and f not in trainer_defined:
            out.append('%s: managers.%s:%s  [%s]' % (rel(p), mg, f, cls))

# 4. unknown method names
section('4. methods neither defined nor called by game nor trainer-defined')
unk = collections.defaultdict(set)
for p in tfiles:
    for m in RE_CALL.finditer(read(p)):
        f = m.group(1)
        if f not in game_called and f not in game_defined_names and f not in trainer_defined:
            unk[f].add(rel(p))
for f in sorted(unk):
    files = sorted(unk[f])
    out.append('%s  <- %s%s' % (f, ', '.join(files[:3]), ' (+%d)' % (len(files) - 3) if len(files) > 3 else ''))

# 5. undefined globals
section('5. undefined global reads')
STD = set('''_G _VERSION assert collectgarbage dofile error getfenv getmetatable ipairs load loadfile loadstring
module next pairs pcall print rawequal rawget rawset require select setfenv setmetatable tonumber tostring
type unpack xpcall coroutine debug io math os package string table bit jit gcinfo newproxy arg'''.split())
ENGINE = set('''Application World Idstring Vector3 Rotation Color Draw Input Network Steam SystemInfo DB PackageManager
Global TimerManager managers tweak_data Overlay SoundDevice MenuBackdropGUI Localizer Util CoreSerialize
mvector3 mrotation math Polyline Brush Pen Dir Thread SystemFS ModPath ModInstance BLT Hooks MenuHelper
LuaNetworking LuaModManager BLTMenu Utils NetworkHelper MenuCallbackHandler json Messages DelayedCalls
QuickMenu Global SimpleMenu CoreTable CoreEvent CoreDebug Telemetry Session ScriptSerializer _M
alive Application VRManager PackageManager Steam AnimatedValue Draw PlayerAction Keyboard Mouse
Vector3Box RotationBox CoreSessionResponse cat_print cat_error Profiler ElementSpawnEnemyDummy deep_clone
clone table_print inspect BLTKeybind RenderSettings RequiredScript core utf8 CoreClass'''.split())
tglobals = set()
gget = {}
for p in tfiles:
    try:
        bl = subprocess.run(['luajit', '-bl', p], capture_output=True, text=True, errors='replace').stdout
    except Exception as e:
        continue
    gs = set(re.findall(r'GSET .*?; "([^"]+)"', bl))
    tglobals |= gs
    gget[p] = set(re.findall(r'GGET .*?; "([^"]+)"', bl))
    src = read(p)
    for m in re.finditer(r'rawset\(\s*_G\s*,\s*["\'](\w+)["\']', src):
        tglobals.add(m.group(1))
    for m in re.finditer(r'(?<![\w.])G\.(\w+)\s*=[^=]', src):
        tglobals.add(m.group(1))
    for m in re.finditer(r'_G\.(\w+)\s*=[^=]', src):
        tglobals.add(m.group(1))
    for m in re.finditer(r'_G\[\s*["\'](\w+)["\']\s*\]\s*=[^=]', src):
        tglobals.add(m.group(1))
known = STD | ENGINE | tglobals | game_globals
for p in tfiles:
    bad = sorted(gget.get(p, set()) - known)
    if bad:
        out.append('%s: %s' % (rel(p), ' '.join(bad)))

text = '\n'.join(out)
print('classes=%d methods=%d managers=%d' % (len(classes), sum(len(v) for v in methods.values()), len(mgr_class)))
if report_path:
    with open(report_path, 'w') as fh:
        fh.write(text)
    print('lines=%d -> %s' % (len(out), report_path))
else:
    print(text)
