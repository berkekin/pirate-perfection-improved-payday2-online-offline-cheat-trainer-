-- usage: luajit check_tr.lua English.txt Turkish.txt
local function load(path)
  local f = assert(io.open(path, "rb")); local s = f:read("*a"); f:close()
  assert(s:sub(1,3) ~= "\239\187\191", "BOM in " .. path)
  local fn, err = loadstring("return " .. s, path); assert(fn, err)
  setfenv(fn, {}); return fn()
end
local en, tr = load(arg[1]), load(arg[2])
local n, bad = 0, 0
local function specs(s) local t = {} for spec in s:gmatch("%%[%d%.%-]*[sdqfx%%]") do t[#t+1] = spec end return table.concat(t, ",") end
for k, v in pairs(en) do
  n = n + 1
  if tr[k] == nil then print("MISSING IN TR: " .. k); bad = bad + 1
  elseif type(v) == "string" and specs(v) ~= specs(tr[k]) then print("FORMAT MISMATCH: " .. k .. " en=[" .. specs(v) .. "] tr=[" .. specs(tr[k]) .. "]"); bad = bad + 1 end
  -- every format string must actually format
  if type(v) == "string" and v:find("%%s") then
    local args = {}
    for spec in v:gmatch("%%[%d%.%-]*([sdqfx])") do args[#args + 1] = (spec == "s" or spec == "q") and "a" or 1 end
    local ok1 = pcall(string.format, v, unpack(args))
    local ok2 = pcall(string.format, tr[k] or "", unpack(args))
    if not (ok1 and ok2) then print("FORMAT ERROR: " .. k); bad = bad + 1 end
  end
end
for k in pairs(tr) do if en[k] == nil then print("EXTRA IN TR: " .. k); bad = bad + 1 end end
print(("keys: %d, problems: %d"):format(n, bad))
os.exit(bad == 0 and 0 or 1)
