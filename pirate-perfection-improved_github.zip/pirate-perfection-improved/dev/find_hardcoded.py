#!/usr/bin/env python3
"""Find user-visible English text in the trainer that bypasses the translation system.

Usage: find_hardcoded.py <trainer_root> [out]
Heuristic: string literals with letters and a space (or a capitalised word) used in
UI-ish contexts: text/title/description/hint fields, show_hint/show_mid_text/chat
messages, ppr_obj:text, QuickMenu/SimpleMenu, managers.hud:show_hint, etc.
"""
import os, re, sys

root = sys.argv[1]
out = sys.argv[2] if len(sys.argv) > 2 else None

CTX = re.compile(r'''(?x)
    (?:\b(?:text|title|description|desc|hint|message|msg|name_text|label|button_text|help)\s*=\s*)
  | (?:\b(?:show_hint|show_mid_text|show_text|ShowHint|ShowMidText|hint_text|present_mid_text|_receive_message|receive_message|
        send_message|chat_message|ChatMessage|SystemMessage|system_message|show_popup|show_message|show_msg|
        m_log_v|managers\.chat:\w+|managers\.hud:show_hint|managers\.hud:present_mid_text|QuickMenu:new|SimpleMenu:new|
        SimpleMenuV2:new|ppr_obj:text|:set_text|text_box|alert|notify)\s*\(\s*(?:[^,()]*,\s*){0,3})
''')
STR = re.compile(r'''("(?:[^"\\\n]|\\.)*"|'(?:[^'\\\n]|\\.)*')''')
SKIP_FILES = ('translations', 'configs', 'experimental/dev', 'tools/menu.lua', 'tools/sorteddialog.lua')

def looks_human(s):
    s = s[1:-1]
    if len(s) < 3 or not re.search(r'[A-Za-z]{2}', s):
        return False
    if re.fullmatch(r'[a-z0-9_./\-]+', s):          # ids, paths
        return False
    if re.fullmatch(r'%[a-z]|[%\d\s.,:+\-]+', s):
        return False
    if s.startswith(('units/', 'Trainer/', 'guis/', 'fonts/', 'textures/', 'effects/', 'settings/')):
        return False
    if re.fullmatch(r'[A-Z0-9_]+', s):                # CONSTANTS
        return False
    return bool(re.search(r'[A-Za-z]+[ !?.:]', s) or re.search(r'^[A-Z][a-z]+', s))

rows = []
for d, _, fs in os.walk(root, followlinks=True):
    for f in fs:
        if not f.endswith('.lua'):
            continue
        p = os.path.join(d, f)
        rel = os.path.relpath(p, root)
        if any(x in rel for x in SKIP_FILES):
            continue
        for i, line in enumerate(open(p, encoding='utf-8', errors='replace'), 1):
            code = line.split('--')[0] if '--' in line and not re.search(r'["\'][^"\']*--', line) else line
            if not CTX.search(code):
                continue
            for m in STR.finditer(code):
                if looks_human(m.group(1)):
                    rows.append('%s:%d: %s' % (rel, i, line.strip()[:150]))
                    break
text = '\n'.join(rows)
if out:
    open(out, 'w').write(text)
print(len(rows))
