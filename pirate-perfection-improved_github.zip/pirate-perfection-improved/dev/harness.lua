-- Mock test harness for PPR Improved Edition (runs outside PAYDAY 2).
-- usage: luajit harness.lua <mod_root_dir>
-- It stubs the game API, loads the trainer's new/changed modules and exercises them.
local MOD = arg[1]:gsub("/?$", "/")
local failures, checks = 0, 0
local function ok(cond, msg)
	checks = checks + 1
	if not cond then failures = failures + 1; print("FAIL: " .. msg) end
end
local function section(name) print("== " .. name) end

-- ---------- generic stubs ----------
function class(super)
	local c = {}
	c.__index = c
	if super then setmetatable(c, { __index = super }) end
	c.new = function(self, ...)
		local o = setmetatable({}, c)
		if o.init then o:init(...) end
		return o
	end
	return c
end
function callback(o, base, name, param)
	return function(...) return base[name](o, param, ...) end
end
function clone(t) local r = {} for k, v in pairs(t) do r[k] = v end return r end
deep_clone = function(t) if type(t) ~= "table" then return t end local r = {} for k, v in pairs(t) do r[k] = deep_clone(v) end return r end
function string.split(s, sep) local t = {} for p in (s .. sep):gmatch("(.-)" .. sep) do t[#t + 1] = p end return t end
function table.size(t) local n = 0 for _ in pairs(t) do n = n + 1 end return n end
void = function() end
LOG = {}
function m_log_error(...) LOG[#LOG + 1] = table.concat({ tostring(select(1, ...)), tostring(select(2, ...)), tostring(select(3, ...)) }, " ") end
function m_log_vs() end
function safecall(f, ...) return select(2, xpcall(function(...) return f(...) end, debug.traceback, ...)) end
HINTS = {}
function show_hint(msg) HINTS[#HINTS + 1] = msg end
function show_mid_text(msg, title) HINTS[#HINTS + 1] = tostring(title) .. ": " .. tostring(msg) end
function loadstring_execute(input, sandbox, dbg)
	local l, err = loadstring(input, dbg)
	if l then if sandbox then setfenv(l, sandbox) end return l() end
	m_log_error("loadstring_execute()", err)
end

ppr_io = {
	open = function(file, mode) return io.open(MOD .. file, mode) end,
	lines = function(file) return io.lines(MOD .. file) end,
}
local cache = {}
local function find_file(path)
	for _, ext in ipairs({ "", ".lua", ".LUA" }) do
		local f = io.open(MOD .. path .. ext, "rb")
		if f then local s = f:read("*a"); f:close(); return s, path .. ext end
	end
	-- case-insensitive fallback (Windows behaviour)
	local dir, base = path:match("^(.*)/([^/]+)$")
	local p = io.popen('ls "' .. MOD .. dir .. '" 2>/dev/null')
	if p then
		for name in p:lines() do
			local n = name:lower()
			if n == base:lower() or n == base:lower() .. ".lua" then
				p:close()
				local f = io.open(MOD .. dir .. "/" .. name, "rb"); local s = f:read("*a"); f:close()
				return s, dir .. "/" .. name
			end
		end
		p:close()
	end
end
PRELOAD = {}
function ppr_dofile(path)
	local src, real = find_file(path)
	if not src then error("ppr_dofile: not found " .. path) end
	local fn = assert(loadstring(src, "@" .. real))
	return fn()
end
function ppr_require(path)
	local key = path:lower()
	if PRELOAD[key] then return PRELOAD[key]() end
	if cache[key] ~= nil then return unpack(cache[key]) end
	local res = { ppr_dofile(path) }
	cache[key] = res
	return unpack(res)
end

-- game stubs
Color = setmetatable({}, { __call = function(_, ...) return { ... } end })
Color.Patron = "patron"; Color.red = "red"; Color.white = "white"
Application = { time = function() return os.clock() end, version = function() return "1.143.240" end }
Network = { is_server = function() return IS_SERVER end, is_client = function() return not IS_SERVER end }
IS_SERVER = true
function is_server() return IS_SERVER end
function is_client() return not IS_SERVER end
Steam = { current_language = function() return "english" end }
local custom_loc = {}
managers = {
	localization = {
		add_localized_strings = function(self, t) for k, v in pairs(t) do custom_loc[k] = v end end,
		text = function(self, id) return custom_loc[id] or ("GAME:" .. tostring(id)) end,
		exists = function(self, id) return custom_loc[id] ~= nil end,
	},
	experience = { cash_string = function(self, v) return "$" .. tostring(v) end },
	network = { session = function() return nil end },
}
tweak_data = { difficulty_name_ids = { normal = "a", hard = "b", overkill = "c", overkill_145 = "d", easy_wish = "e", overkill_290 = "f", sm_wish = "g" } }
backuper = { add_clbk = function(self, fname, f, id) BACKUP_CLBKS[id] = f end, hijack = function() end, backup = function() end, restore = function() end }
BACKUP_CLBKS = {}
togg_vars = {}

-- config
ppr_config = ppr_dofile("Trainer/config")
SAVES = 0
setmetatable(ppr_config, { __call = function() SAVES = SAVES + 1 end })
ppr_config.const_version = "v3.0.0"; ppr_config.const_edition = "Improved Edition"

-- fake Menu
OPENED = {}
PRELOAD["trainer/tools/new_menu/menu"] = function()
	if not Menu then
		Menu = {}
		function Menu.open(_, data) OPENED[#OPENED + 1] = data; return { close_clbks = {} } end
	end
	return Menu
end
local function last() return OPENED[#OPENED] end
local function texts(data)
	local t = {}
	for _, b in ipairs(data.button_list or {}) do if b.text then t[#t + 1] = b.text end end
	return t
end
local function no_raw_ids(data, where)
	for _, txt in ipairs(texts(data)) do
		ok(type(txt) == "string" and txt ~= "" , where .. ": empty button text")
		ok(not tostring(txt):match("^%l[%w]*_[%w_]+$") or txt == "default_config", where .. ": raw id shown as text: " .. tostring(txt))
		ok(not tostring(txt):find("%f[%w]nil%f[%W]"), where .. ": nil in text: " .. tostring(txt))
	end
	ok(type(data.title) == "string" and not data.title:match("^%l[%w]*_[%w_]+$"), where .. ": bad title " .. tostring(data.title))
end

-- ---------- tests ----------
section("localizator")
local localizator = ppr_dofile("Trainer/setup/localizator")
Localization = localizator:new(ppr_config.Language)
local tr = Localization.translate
local L = Localization
ok(Localization:current() == "turkish", "default language should be turkish, got " .. tostring(Localization:current()))
ok(tr.hub_title == "PPR Ana Menü", "turkish hub title: " .. tostring(tr.hub_title))
ok(not tr.lang_charmode_desc:find("\196\159") and not tr.lang_charmode_desc:find("\197\159") and not tr.lang_charmode_desc:find("\196\177"), "safe mode must remove g-breve/s-cedilla/dotless i")
ok(tr.base_character_sub == "Karakter", "safe mode keeps plain text")
ok(tr.save == "Kaydet", "save")
ok(tr.help_desc:find("Hos geldin") == nil and tr.help_desc:find("ho\195\167") == nil, "sanity")
ok(tr.inv_spec_masks == "Maskeler", "masks")
ok(tr.config_menu == "Ayarlar", "config")
local tr_ref = tr
Localization:change_language("english", true)
ok(Localization.translate == tr_ref, "translate table must stay the same object")
ok(tr.hub_title == "PPR Hub", "english hub title after switch: " .. tostring(tr.hub_title))
ok(SAVES >= 1 and ppr_config.Language == "english", "language choice saved")
ok(tr.this_key_does_not_exist == "this_key_does_not_exist", "unknown key returns id")
ok(Localization:text("job_menu_day", 3) == "Day 3", "text() formatting")
ok(Localization:text("job_menu_diff_c") ~= nil, "text() without args does not crash")
Localization:change_language("turkish", true)
ok(tr.job_menu_day == "%s. gün" or tr.job_menu_day == "%s. g\195\188n", "turkish day")
ppr_config.TurkishCharMode = "full"; Localization:reload()
ok(tr.lang_charmode_desc:find("\197\159") ~= nil, "full mode keeps s-cedilla")
ppr_config.TurkishCharMode = "ascii"; Localization:reload()
ok(not tr.config_menu:find("[\128-\255]") and not tr.inv_title:find("[\128-\255]"), "ascii mode has no non-ASCII bytes: " .. tr.inv_title)
ppr_config.TurkishCharMode = "safe"; Localization:reload()
ok(custom_loc.ppr_kb_hub ~= nil and custom_loc.ppr_kb_god_desc ~= nil, "BLT keybind strings registered in game localization")
ok(Localization:language_name("turkish") == "T\195\188rk\195\167e", "native name")
local langs = Localization:available_languages()
ok(#langs >= 2 and langs[1].id == "english" and langs[2].id == "turkish", "language list order")
-- BOM robustness
do
	local f = io.open(MOD .. "Trainer/translations/English.txt", "rb"); local s = f:read("*a"); f:close()
	ok(s:sub(1, 3) ~= "\239\187\191", "English.txt has no BOM")
end

section("keyconfig + key names")
local keyconf = ppr_dofile("Trainer/keyconfig")
KeyInput = { keys = {}, filenames = {} }
for key, value in pairs(keyconf) do
	local path = value.script or value.handled_callback
	ok(find_file((path:gsub("%.lua$", ""))) ~= nil, "keyconfig path exists: " .. path)
	local parts = path:split("/")
	local fname = parts[#parts]:gsub(".lua", "")
	KeyInput.filenames[fname] = key
	KeyInput.keys[key] = value
	if value.handled_callback then value.callback = function() CALLED = fname end end
	local letter_like = key:match("^%w$") or key == "end" or key == "home" or key == "delete" or key == "insert" or key:match("^page")
	if letter_like then ok(value.ig_chat == false, "key '" .. key .. "' must not work while typing in chat") end
end
local keys = ppr_require("Trainer/tools/keynames")
ok(keys.display("f5") == "F5", "F5 display")
ok(keys.display("page up") == "Page Up", "Page Up display: " .. tostring(keys.display("page up")))
ok(keys.display("x_button_1") == tr.key_mouse4, "mouse 4 display")
ok(keys.key_for("hub") == "f5", "hub bound to f5")
ok(keys.prefix("help") == "[F1]  ", "prefix")

section("hub")
GameSetup = nil
local hub = ppr_require("Trainer/menu/hub")
ok(type(hub) == "function", "hub returns function")
hub()
local hd = last()
no_raw_ids(hd, "hub(menu)")
ok(#texts(hd) >= 9, "hub has entries in menu state")
for _, t in ipairs(texts(hd)) do ok(not t:find(tr.intm_title, 1, true), "in-game menus hidden in main menu") end
-- click "help" entry -> uses KeyInput callback
CALLED = nil
for _, b in ipairs(hd.button_list) do if b.text and b.text:find("F1") then b.callback(unpack(b.data)) end end
ok(CALLED == "help", "hub help entry uses the F1 callback")
PRELOAD["trainer/addons/main_menu/unlock_items"] = function() unlock_items = function(t) UNLOCKED = t end return true end
hub()
for _, b in ipairs(last().button_list) do if b.text == tr.hub_unlock_weapon_mods then b.callback(unpack(b.data)) end end
ok(UNLOCKED == "weapon_mods", "one-click weapon mod unlock calls unlock_items('weapon_mods'), got " .. tostring(UNLOCKED))
ok(last().title == tr.hub_done_title and last().description == tr.hub_unlocked_weapon_mods, "unlock confirmation shown")
hub()
for _, b in ipairs(last().button_list) do if b.text == tr.hub_unlock_all then b.callback(unpack(b.data)) end end
ok(UNLOCKED == "all", "one-click unlock all")
GameSetup = {}
hub()
local hg = last()
local found = false
for _, t in ipairs(texts(hg)) do if t:find(tr.intm_title, 1, true) then found = true end end
ok(found, "in-game menus shown in game")
no_raw_ids(hg, "hub(game)")
for _, t in ipairs(texts(hg)) do ok(t ~= tr.hub_unlock_weapon_mods, "lobby-only unlock hidden in game") end
PANIC = 0
ppr_normalize = function() PANIC = PANIC + 1 end
for _, b in ipairs(hg.button_list) do if b.text == tr.hub_panic then b.callback(unpack(b.data)) end end
ok(PANIC == 1, "panic button calls ppr_normalize")
local hud_btn
for _, b in ipairs(hg.button_list) do if b.text == tr.hub_active_hud then hud_btn = b end end
ok(hud_btn and hud_btn.type == "toggle" and hud_btn.toggle() == true, "active HUD toggle present and on")
hud_btn.callback()
ok(ppr_config.HUD_ActiveCheats == false and hud_btn.toggle() == false, "HUD toggle switches off")
hud_btn.callback()
ok(ppr_config.HUD_ActiveCheats == true, "HUD toggle switches on")
PPR_FAILED_FEATURES = { "FreeBlackMarket" }
hub()
ok(last().description:find("FreeBlackMarket", 1, true) ~= nil, "failed features listed in hub")
PPR_FAILED_FEATURES = nil
for _, b in ipairs(hg.button_list) do if b.text == tr.hub_quick then b.callback(unpack(b.data)) end end
local qm = last()
ok(qm.title == tr.hub_quick and qm.plugin_path == "Trainer/addons/charmenu/", "quick cheats menu opened")
no_raw_ids(qm, "quick cheats")
local plug_ok = true
for _, b in ipairs(qm.button_list) do
	if b.plugin then
		local f = io.open(MOD .. (b.plugin_path or "Trainer/addons/charmenu/") .. b.plugin .. ".lua", "rb")
		if f then f:close() else plug_ok = false print("missing plugin " .. b.plugin) end
	end
end
ok(plug_ok, "quick cheat plugins exist")
GameSetup = nil

section("help")
local help = ppr_require("Trainer/menu/help")
help()
local hp = last()
no_raw_ids(hp, "help")
for _, b in ipairs(hp.button_list) do if b.text == tr.help_keybinds then b.callback() end end
local kb = last()
ok(kb.description:find("F1   =   " .. tr.hub_help, 1, true) ~= nil, "key list contains F1 = help")
ok(kb.description:find("F5   =   " .. tr.hub_title, 1, true) ~= nil, "key list contains F5 = hub")
ok(kb.description:find(tr.key_mouse3, 1, true) ~= nil, "key list contains middle mouse")
for _, name in ipairs({ "help_whatsnew", "help_cheatertag", "help_credits" }) do
	for _, b in ipairs(hp.button_list) do if b.text == tr[name] then b.callback() end end
	ok(last().title == tr[name] and #last().description > 20, "help page " .. name)
end

section("language menu")
local lm = ppr_require("Trainer/menu/language_menu")
lm()
local ld = last()
no_raw_ids(ld, "language menu")
local saves_before = SAVES
for _, b in ipairs(ld.button_list) do if b.text and b.text:find("English") then b.callback(unpack(b.data)) end end
ok(Localization:current() == "english" and SAVES > saves_before, "language switched to English from menu and saved")
ok(last().title == "Language / Dil", "language menu reopened in English")
for _, b in ipairs(last().button_list) do if b.text and b.text:find("T\195\188rk\195\167e") then b.callback(unpack(b.data)) end end
ok(Localization:current() == "turkish", "switched back to Turkish")
for _, b in ipairs(last().button_list) do if b.text == tr.lang_charmode then b.callback() end end
no_raw_ids(last(), "charmode menu")
for _, b in ipairs(last().button_list) do if b.text and b.text:find(tr.lang_charmode_ascii, 1, true) then b.callback(unpack({ b.data })) end end
ok(ppr_config.TurkishCharMode == "ascii", "charmode set")
ppr_config.TurkishCharMode = "safe"; Localization:reload()

section("config menu")
rlist_files = function() return { "default_config", "blank", "menu_config", "skills_config", "my_cheats", "preset_stealth", "preset_loud" } end
local cm = ppr_require("Trainer/menu/config_menu")
cm()
no_raw_ids(last(), "config menu")
for _, b in ipairs(last().button_list) do if b.text == tr.config_load then b.callback() end end
local loadlist = texts(last())
ok(#loadlist == 4, "load list hides system files: " .. table.concat(loadlist, ", "))
local has_nice = false
for _, t in ipairs(loadlist) do if t:find(tr.config_name_preset_stealth, 1, true) then has_nice = true end end
ok(has_nice, "preset shown with a friendly name")

section("PPR setup (base_menu)")
ppr_dofile("Trainer/menu/pre-game/base_menu")
local root = last()
no_raw_ids(root, "base_menu root")
local visited = 0
local function walk(data, depth)
	for _, b in ipairs(data.button_list) do
		if b.menu and b.callback and depth < 4 then
			local n_before = #OPENED
			local okc, err = pcall(b.callback, unpack(type(b.data) == "table" and b.data or { b.data }))
			ok(okc, "base_menu callback error: " .. tostring(err))
			if okc and #OPENED > n_before then
				visited = visited + 1
				local sub = last()
				no_raw_ids(sub, "base_menu:" .. tostring(b.text))
				if sub ~= data then walk(sub, depth + 1) end
			end
		end
	end
end
walk(root, 1)
ok(visited >= 15, "visited setup submenus: " .. visited)

section("job menu difficulty normalization")
do
	local legacy = { ["One Down"] = "sm_wish", ["Overkill"] = "overkill_145", ["Very Hard"] = "overkill" }
	for name, id in pairs(legacy) do
		local src = io.open(MOD .. "Trainer/menu/pre-game/jobmenu.lua"):read("*a")
		local block = src:match("local def_difficulty = ppr_config.jobmenu_def_difficulty\n(do.-\nend)\n")
		ok(block ~= nil, "found normalization block")
		local env = setmetatable({ ppr_config = { jobmenu_def_difficulty = name }, tweak_data = tweak_data, type = type }, { __index = _G })
		local fn = assert(loadstring("local def_difficulty = ppr_config.jobmenu_def_difficulty\n" .. block .. "\nreturn def_difficulty"))
		setfenv(fn, env)
		ok(fn() == id, "legacy difficulty " .. name .. " -> " .. id)
	end
end

section("first launch")
os.remove(MOD .. "Trainer/configs/checks/First Launch v3.Check")
ppr_dofile("Trainer/menu/firstlaunch")
ok(type(BACKUP_CLBKS.first_time) == "function", "first launch callback registered")
BACKUP_CLBKS.first_time()
ok(last().title == tr.welcome_title, "welcome shown")
os.remove(MOD .. "Trainer/configs/checks/First Launch v3.Check")

section("active cheats HUD")
do
	local obj = { shown = false }
	function obj:set_text(t) self.text = t end
	function obj:text_rect() return 0, 0, 200, 80 end
	function obj:set_size() end
	function obj:set_x(x) self.x = x end
	function obj:set_y(y) self.y = y end
	function obj:set_color(c) self.color = c end
	function obj:show() self.shown = true end
	function obj:hide() self.shown = false end
	ppr_obj = { __elements = {}, panel = { w = function() return 1920 end }, text = function() return obj end }
	plugins = { plugins = { god_mode = { loaded = true }, infinite_ammo = { loaded = true }, equipment_control = { loaded = true }, no_recoil = { loaded = false } } }
	RenderSettings = { resolution = { x = 1920, y = 1080 } }
	local loop
	RunNewLoopIdent = function(id, f) loop = f end
	local t = 0
	Application.time = function() t = t + 1 return t end
	GameSetup = {}
	IS_SERVER = false
	ppr_dofile("Trainer/hud/active_cheats")
	ok(type(loop) == "function", "HUD loop registered")
	loop()
	ok(obj.shown and obj.text:find(tr.togg_godmode, 1, true) and obj.text:find(tr.togg_ammo, 1, true), "HUD lists active cheats: " .. tostring(obj.text))
	ok(not obj.text:find("equipment_control", 1, true) and not obj.text:find(tr.togg_recoil, 1, true), "HUD hides helpers and inactive cheats")
	ok(obj.text:find(tr.hud_active_title_client, 1, true) ~= nil, "client title used when not host")
	ok(type(obj.color) == "table" and obj.color[1] == 1, "red color as client")
	ok(obj.x == 1920 - 200 - 20, "right aligned")
	plugins.plugins.god_mode.loaded = false; plugins.plugins.infinite_ammo.loaded = false
	loop()
	ok(obj.shown == false, "HUD hidden when nothing is active")
	IS_SERVER = true
	GameSetup = nil
end

section("slowmo protect")
UnitNetworkHandler = { start_timespeed_effect = function() APPLIED = true end, _verify_sender = function(s) return s end }
local hijacked
backuper.hijack = function(self, name, f) hijacked = f end
Global = { game_settings = { level_id = "branchbank" } }
managers.chat = { _receive_message = function(_, _, title, msg) CHAT = title .. msg end }
ppr_dofile("Trainer/addons/slowmo_protect")
ok(type(hijacked) == "function", "slowmo hook installed")
APPLIED = false
hijacked(UnitNetworkHandler.start_timespeed_effect, UnitNetworkHandler, "pause", "pausable", "player;", 0.1, 1, 60, 1, { id = function() return 2 end, name = function() return "Griefer" end })
ok(APPLIED == false and CHAT and CHAT:find("Griefer"), "forced slow-mo blocked and reported")

-------------------------------------------------------------------------------
section("v3.2 datastore")
local ds = ppr_require("Trainer/tools/datastore")
local enc = ds.encode({ b = true, a = "x\"y\n", n = 1.5, list = { "p", "q" }, ["weird key"] = 3, nested = { deep = { v = false } }, f = print })
local back = ds.decode(enc)
ok(back and back.a == "x\"y\n" and back.b == true and back.n == 1.5 and back.list[2] == "q" and back["weird key"] == 3 and back.nested.deep.v == false and back.f == nil, "datastore round trip")
ok(ds.decode("return 5") == nil and ds.decode("garbage {") == nil and ds.decode("") == nil, "datastore rejects bad text")
ok(ds.decode("return { x = io.open('/etc/hostname') }") == nil, "datastore sandbox has no io")
ok(ds.decode("\239\187\191return { y = 2 }").y == 2, "datastore strips BOM")
local TMPF = "Trainer/configs/__harness_tmp.lua"
ok(ds.save(TMPF, { k = "v" }) and ds.load(TMPF).k == "v", "datastore save/load file")
os.remove(MOD .. TMPF)
ok(ds.load(TMPF) == nil, "datastore missing file -> nil")

section("v3.2 quick cheats")
IN_GAME = true
function inGame() return IN_GAME end
function isHost() return IS_SERVER end
plugins = { plugins = {} }
LOADS = {}
function load_plugin(path)
	return function(name)
		LOADS[#LOADS + 1] = path .. name
		local p = plugins.plugins[name] or {}
		p.loaded = not p.loaded
		plugins.plugins[name] = p
	end
end
local quick = ppr_require("Trainer/tools/quickcheats")
for _, q in ipairs(quick.LIST) do
	if q then
		local f = io.open(MOD .. q.path .. q.id .. ".lua", "rb")
		ok(f ~= nil, "quick cheat plugin exists: " .. q.id)
		if f then f:close() end
		ok(tr[q.label] and not tr[q.label]:find("^%[?" .. q.label), "quick cheat label translated: " .. q.label)
	end
end
HINTS = {}
ok(quick.set("god_mode", true) == true and quick.is_on("god_mode"), "quick on")
ok(quick.set("god_mode", true) == true and #LOADS == 1, "quick on again does nothing")
ok(quick.toggle("god_mode") == false and #LOADS == 2, "quick toggle off")
ok(HINTS[#HINTS] and HINTS[#HINTS]:find(tr.state_off, 1, true), "quick shows state hint")
IS_SERVER = false
ok(quick.set("invisible_player", true) == false and HINTS[#HINTS] == tr.kb_host_only, "host-only cheat blocked for client")
IS_SERVER = true
ok(quick.set("nope", true) == nil, "unknown quick id")
IN_GAME = false
ok(quick.set("no_recoil", true) == false and #LOADS == 2, "quick does nothing outside a heist")
IN_GAME = true

section("v3.2 key bindings (real kbinput)")
os.remove(MOD .. "Trainer/configs/user_keybinds.lua")
local PRESSED = {}
local KB = {
	down = function(_, k) return false end,
	pressed = function(_, k) return false end,
	pressed_list = function() return PRESSED end,
	button_name_str = function(_, k) return k end,
}
local MOUSE = { button_name = function(_, i) return "mouse" .. i end, down = function() return false end, pressed = function() return false end }
Input = { keyboard = function() return KB end, mouse = function() return MOUSE end }
Idstring = Idstring or function(s) return s end
local LOOPS = {}
local loop_n = 0
RunNewLoop = function(f, ...) loop_n = loop_n + 1; local a = { ... }; LOOPS[loop_n] = function() return f(unpack(a)) end; return loop_n end
RunNewLoopIdent = function(id, f, ...) local a = { ... }; LOOPS[id] = function() return f(unpack(a)) end end
StopLoopIdent = function(id) LOOPS[id] = nil end
void = function() end
in_chat = function() return false end
local KI_cls = ppr_dofile("Trainer/experimental/kbinput")
-- keyconfig menus need the real game; stub them while key bindings are tested
local STUBBED = {}
local function stub_keyconfig_modules()
	for _, v in pairs(ppr_dofile("Trainer/keyconfig")) do
		local p = v.handled_callback
		if p then
			for _, variant in ipairs({ p:lower(), (p:gsub("%.lua$", "")):lower() }) do
				if not PRELOAD[variant] then
					PRELOAD[variant] = function() return function() CALLED = p end end
					STUBBED[#STUBBED + 1] = variant
				end
			end
		end
	end
end
local function unstub_keyconfig_modules()
	for _, k in ipairs(STUBBED) do PRELOAD[k] = nil end
	STUBBED = {}
end
stub_keyconfig_modules()
KeyInput = KI_cls:new()
KeyInput:run_updating(true)
KeyInput.keys = ppr_dofile("Trainer/keyconfig")
KeyInput:help_setup()
ok(KeyInput.filenames.hub == "f5" and KeyInput.keys.f5.id == "hub", "help_setup sets ids")
KeyInput:help_setup()
ok(KeyInput.filenames.hub == "f5" and KeyInput.filenames.xray == "x", "help_setup can run twice")
local ub = ppr_require("Trainer/tools/userbinds")
ub.apply(KeyInput)
ok(ub.defaults.hub == "f5" and ub.key_of("hub") == "f5", "defaults recorded")
ok(KeyInput.unbound.teleport_menu and KeyInput.unbound.tp_save, "extra actions available unbound")
ok(ub.bind_action("hub", "f9") and KeyInput.keys.f9.id == "hub" and KeyInput.keys.f5 == nil, "rebind hub to f9")
ok(KeyInput.filenames.hub == "f9" and keys.key_for("hub") == "f9", "key names follow the change")
ok(ub.bind_action("xray", "f9") and KeyInput.keys.f9.id == "xray" and KeyInput.unbound.hub and ub.last_displaced == "hub", "binding a used key unbinds the old action")
local saved = ds.load(ub.FILE)
ok(saved and saved.actions.hub == "none" and saved.actions.xray == "f9", "changes saved")
ok(ub.bind_quick("god_mode", "num 1") and KeyInput.keys["num 1"].quick == "god_mode", "quick cheat bound")
LOADS = {}
KeyInput.keys["num 1"].callback()
ok(#LOADS == 1 and quick.is_on("god_mode"), "quick key toggles the cheat")
ok(ub.bind_action("tp_save", "num 2") and type(KeyInput.keys["num 2"].callback) == "function", "extra action bindable")
ok(ub.bind_action("teleport_menu", "num 3") and type(KeyInput.keys["num 3"].callback) == "function", "menu action gets its callback")
-- restart: a new KeyInput gets the saved changes
local K2 = KI_cls:new()
K2.keys = ppr_dofile("Trainer/keyconfig")
K2:help_setup()
local saved_ki = KeyInput
KeyInput = K2
ub.defaults = {}
ub.data = ds.load(ub.FILE)
ub.apply(K2)
ok(K2.keys.f9 and K2.keys.f9.id == "xray" and K2.keys.f5 == nil and K2.keys["num 1"] and K2.keys["num 1"].quick == "god_mode", "saved bindings applied at start")
ok(K2.unbound.hub ~= nil and K2.keys["num 2"] and K2.keys["num 2"].id == "tp_save", "unbound + extra bindings restored")
ok(ub.reset_action("hub") and K2.keys.f5 and K2.keys.f5.id == "hub", "reset one action")
ub.bind_quick("god_mode", "none")
ok(K2.keys["num 1"] == nil and ds.load(ub.FILE).quick.god_mode == nil, "quick key removed")
ub.reset_all()
ok(K2.keys.f5.id == "hub" and K2.keys.x.id == "xray" and K2.keys.f9 == nil and next(ds.load(ub.FILE).actions) == nil, "reset all")
-- capture
local got = "unset"
ub.capture(function(k) got = k end)
ok(LOOPS.ppr_key_capture ~= nil, "capture loop started")
local t0 = Application.time
local fake_t = 100
Application.time = function() return fake_t end
ub.capture(function(k) got = k end)
fake_t = 100.1; PRESSED = { "f7" }; LOOPS.ppr_key_capture()
ok(got == "unset", "capture ignores the first moment")
fake_t = 101; PRESSED = { "enter" }; LOOPS.ppr_key_capture()
ok(got == "unset", "enter is not captured")
PRESSED = { "f7" }; LOOPS.ppr_key_capture()
ok(got == "f7" and LOOPS.ppr_key_capture == nil, "capture returns key and stops")
ub.capture(function(k) got = k end)
fake_t = 102; PRESSED = { "esc" }; LOOPS.ppr_key_capture()
ok(got == nil, "esc cancels capture")
PRESSED = {}
Application.time = t0
KeyInput = K2

section("v3.2 key bindings menu")
OPENED = {}
local kbm = ppr_require("Trainer/menu/keybinds_menu")
kbm()
local m = last()
ok(m and m.title == tr.kbm_title, "key bindings menu opens")
no_raw_ids(m, "key bindings menu")
local found_hub, found_quick
for _, b in ipairs(m.button_list) do
	if b.data == "hub" then found_hub = b end
	if b.data == "god_mode" then found_quick = b end
end
ok(found_hub and found_hub.text:find("F5", 1, true), "hub line shows its key")
ok(found_quick and found_quick.text:find(tr.kbm_no_key, 1, true), "quick line shows no key")
found_hub.callback(found_hub.data)
local am = last()
ok(am.title == tr.hub_title and #am.button_list == 3, "action submenu")
no_raw_ids(am, "action submenu")
fake_t = 200; Application.time = function() return fake_t end
am.button_list[1].callback()
ok(LOOPS.ppr_key_capture ~= nil and HINTS[#HINTS]:find(tr.hub_title, 1, true), "change key starts capture with hint")
fake_t = 201; PRESSED = { "f8" }; LOOPS.ppr_key_capture(); PRESSED = {}
Application.time = t0
ok(KeyInput.keys.f8 and KeyInput.keys.f8.id == "hub" and last().title == tr.hub_title, "captured key bound and submenu reopened")
ub.reset_all()
unstub_keyconfig_modules()

section("v3.2 teleport points")
os.remove(MOD .. "Trainer/configs/teleports.lua")
Vector3 = Vector3 or function(x, y, z) return { x = x, y = y, z = z } end
Rotation = Rotation or function(y, p, r) return { yaw = function() return y end, pitch = function() return p end } end
alive = function(u) return u ~= nil end
local PPOS = { x = 1, y = 2, z = 3 }
local WARPS = {}
local PLAYER = {
	position = function() return PPOS end,
	camera = function() return { rotation = function() return Rotation(90, 10, 0) end } end,
	rotation = function() return Rotation(0, 0, 0) end,
}
managers.player = { player_unit = function() return PLAYER end, warp_to = function(_, pos, rot) WARPS[#WARPS + 1] = pos; PPOS = pos end }
managers.job = { current_level_id = function() return "branchbank" end }
tweak_data.levels = { branchbank = { name_id = "heist_branchbank" } }
local tpm = ppr_require("Trainer/menu/ingame/teleport_menu")
local TP = PPR_Teleports
tpm()
ok(last().title == tr.tp_title, "teleport menu opens")
no_raw_ids(last(), "teleport menu")
local s1 = TP.save_here()
ok(s1 and s1.name == L:text("tp_point_name", 1) and s1.yaw == 90, "point saved")
PPOS = { x = 50, y = 60, z = 70 }
TP.save_here()
local stored = ds.load("Trainer/configs/teleports.lua")
ok(stored and #stored.branchbank == 2 and stored.branchbank[2].x == 50, "points stored per map")
TP.go(1)
ok(#WARPS == 1 and PPOS.x == 1, "teleport to point 1")
TP.undo()
ok(#WARPS == 2 and PPOS.x == 50, "undo goes back")
TP.undo()
ok(#WARPS == 2 and HINTS[#HINTS] == tr.tp_no_history, "nothing more to undo")
tpm()
local pm = last()
local pt
for _, b in ipairs(pm.button_list) do if b.data == 2 then pt = b end end
ok(pt and pt.alt_callback, "point has right-click menu")
pt.alt_callback(2)
ok(#last().button_list == 4, "point submenu")
no_raw_ids(last(), "point submenu")
last().button_list[3].callback() -- move up
stored = ds.load("Trainer/configs/teleports.lua")
ok(stored.branchbank[1].x == 50, "move up")
last().button_list[4].callback() -- delete
stored = ds.load("Trainer/configs/teleports.lua")
ok(#stored.branchbank == 1 and stored.branchbank[1].x == 1, "delete")
managers.job.current_level_id = function() return "four_stores" end
tpm()
local cnt = 0
for _, b in ipairs(last().button_list) do if type(b.data) == "number" then cnt = cnt + 1 end end
ok(cnt == 0, "other map has its own list")
-- crew + waypoints
local function V(x, y, z)
	local v = { x = x, y = y, z = z }
	return setmetatable(v, { __sub = function(a, b) return V(a.x - b.x, a.y - b.y, a.z - b.z) end,
		__add = function(a, b) return V(a.x + b.x, a.y + b.y, a.z + b.z) end,
		__mul = function(a, k) return V(a.x * k, a.y * k, a.z * k) end,
		__index = { length = function(a) return math.sqrt(a.x * a.x + a.y * a.y + a.z * a.z) end } })
end
PPOS = V(0, 0, 0)
local function unit_at(x) return { position = function() return V(x, 0, 0) end, rotation = function() return { y = function() return V(0, 1, 0) end, yaw = function() return 0 end } end } end
local BOT, MATE = unit_at(500), unit_at(900)
managers.criminals = { characters = function() return {
	{ name = "russian", taken = true, unit = BOT, data = { ai = true } },
	{ name = "german", taken = true, unit = MATE, peer_id = 2, data = {} },
	{ name = "spanish", taken = true, unit = PLAYER, peer_id = 1, data = {} },
	{ name = "american", taken = false, data = {} },
} end }
managers.network = { session = function() return { peer = function(_, id) return { name = function() return "Mate" .. id end } end } end }
local crew = TP.crew_list()
ok(#crew == 2 and crew[1].name:find("menu_russian", 1, true) and crew[2].name == "Mate2", "crew list (bots + players, not me): " .. tostring(crew[1] and crew[1].name) .. " / " .. tostring(crew[2] and crew[2].name) .. " #" .. #crew)
managers.hud = managers.hud or {}
managers.hud._hud = { waypoints = { far = { position = V(3000, 0, 0) }, near = { init_data = { position = V(200, 0, 0) } }, broken = {} } }
local wps = TP.waypoint_list()
ok(#wps == 2 and wps[1].id == "near" and math.abs(wps[1].dist - 2) < 0.01, "waypoints sorted by distance")
tpm()
local crew_btn, wp_btn
for _, b in ipairs(last().button_list) do
	if b.text == tr.tp_crew then crew_btn = b end
	if b.text == tr.tp_waypoints then wp_btn = b end
end
crew_btn.callback()
no_raw_ids(last(), "crew menu")
local nwarps = #WARPS
last().button_list[2].callback()
ok(#WARPS == nwarps + 1 and math.abs(WARPS[#WARPS].x - 900) < 0.01, "teleport to crew member")
wp_btn.callback()
no_raw_ids(last(), "waypoint menu")
last().button_list[1].callback()
ok(#WARPS == nwarps + 2 and WARPS[#WARPS].x == 200, "teleport to nearest waypoint")
managers.hud._hud = nil

IN_GAME = false
OPENED = {}
tpm()
ok(#OPENED == 0 and HINTS[#HINTS] == tr.tp_need_game, "teleport menu needs a heist")
IN_GAME = true
os.remove(MOD .. "Trainer/configs/teleports.lua")

section("v3.2 cheat profiles")
os.remove(MOD .. "Trainer/configs/cheat_profiles.lua")
plugins.plugins = {}
local prm = ppr_require("Trainer/menu/profiles_menu")
local PR = PPR_Profiles
prm()
ok(last().title == tr.prof_title, "profiles menu opens")
no_raw_ids(last(), "profiles menu")
last().button_list[1].callback()
ok(HINTS[#HINTS] == tr.prof_nothing_on, "no profile without active cheats")
quick.set("god_mode", true, true); quick.set("no_recoil", true, true)
prm(); last().button_list[1].callback()
local name1 = L:text("prof_default_name", 1)
local pd = ds.load("Trainer/configs/cheat_profiles.lua")
ok(pd and pd.profiles[name1] and #pd.profiles[name1].cheats == 2, "profile saved with active cheats")
ok(last().title == name1, "profile submenu opened")
no_raw_ids(last(), "profile submenu")
quick.set("god_mode", false, true); quick.set("no_recoil", false, true); quick.set("infinite_ammo", true, true)
PR.apply(name1, true, true)
ok(quick.is_on("god_mode") and quick.is_on("no_recoil") and not quick.is_on("infinite_ammo"), "apply exclusive")
quick.set("infinite_ammo", true, true)
PR.apply(name1, false, true)
ok(quick.is_on("infinite_ammo") and quick.is_on("god_mode"), "apply additive keeps others")
-- mark automatic
prm(); 
local pb
for _, b in ipairs(last().button_list) do if b.data == name1 then pb = b end end
pb.callback(pb.data)
local auto_btn
for _, b in ipairs(last().button_list) do if b.text == tr.prof_auto_on then auto_btn = b end end
auto_btn.callback()
ok(ds.load("Trainer/configs/cheat_profiles.lua").auto == name1, "auto profile saved")
plugins.plugins = {}
PR.apply_auto()
ok(quick.is_on("god_mode") and quick.is_on("no_recoil"), "auto profile applied at heist start")
for _, b in ipairs(last().button_list) do if b.text == tr.prof_delete then b.callback() end end
pd = ds.load("Trainer/configs/cheat_profiles.lua")
ok(next(pd.profiles) == nil and pd.auto == nil, "profile deleted (and auto cleared)")
os.remove(MOD .. "Trainer/configs/cheat_profiles.lua")
os.remove(MOD .. "Trainer/configs/user_keybinds.lua")

section("v3.2 hub entries")
GameSetup = {}
OPENED = {}
local hub = ppr_require("Trainer/menu/hub")
hub()
local hm = last()
local want = { [tr.kbm_title] = false, [tr.prof_title] = false, [tr.tp_title] = false }
for _, b in ipairs(hm.button_list) do
	for t in pairs(want) do if b.text and b.text:find(t, 1, true) then want[t] = true end end
end
for t, v in pairs(want) do ok(v, "hub has entry: " .. t) end
GameSetup = nil

print(("\n%d checks, %d failures"):format(checks, failures))
if #LOG > 0 then print("logged errors (first 10):"); for i = 1, math.min(10, #LOG) do print("  " .. LOG[i]) end end
os.exit(failures == 0 and 0 or 1)
