-- Runs Trainer/setup/auto_init.lua and auto_ingame.lua in a permissive auto-mocked environment.
-- Goal: a feature that throws must be recorded in PPR_FAILED_FEATURES and must NOT stop the rest.
-- usage: luajit harness_autoinit.lua <mod_root>
local MOD = arg[1]:gsub("/?$", "/")
local failures, checks = 0, 0
local function ok(c, m) checks = checks + 1 if not c then failures = failures + 1 print("FAIL: " .. m) end end

local function automock(name)
	return setmetatable({ __name = name }, {
		__index = function(t, k) local v = automock(name .. "." .. tostring(k)) rawset(t, k, v) return v end,
		__call = function() return automock(name .. "()") end,
		__concat = function(a, b) return tostring(a) .. tostring(b) end,
		__tostring = function() return name end,
	})
end

local function run(file, cfg, opts)
	local REQUIRED, FAILED_PATHS = {}, {}
	local env = {}
	env._G = env
	setmetatable(env, { __index = function(t, k)
		local real = _G[k]
		if real ~= nil and k ~= "update" then return real end
		local v = automock(k) rawset(t, k, v) return v
	end })
	env.ppr_config = cfg
	env.togg_vars = {}
	env.m_log_error = function(...) end
	env.is_server = function() return true end
	env.is_client = function() return false end
	env.backuper = { backup = function() end, hijack = function() end, add_clbk = function() end }
	env.ppr_io = { open = function(f, m) return io.open(MOD .. f, m) end }
	env.ppr_dofile = function() return nil end
	env.load_plugin = function() return function() end end
	env.plugins = { ppr_require = function() end }
	env.query_execution_testfunc = function() end
	env.Global = { game_settings = { level_id = "branchbank" } }
	env.ppr_require = function(path)
		REQUIRED[#REQUIRED + 1] = path
		if opts.fail_paths[path] then error("simulated crash in " .. path) end
		return true
	end
	local src = assert(io.open(MOD .. file)):read("*a")
	local fn = assert(loadstring(src, "@" .. file))
	setfenv(fn, env)
	local okrun, err = pcall(fn)
	return okrun, err, env, REQUIRED
end

-- auto_init: make FreeBlackMarket crash, check that later features still load
local cfg = setmetatable({ FreeBlackMarket = true, FreePreplanning = true, NoDropinPause = true, CrewUnlocker = true,
	FreeAssets = true, NoStatsSynced = true, DebugConsole = true, NoSkinMods = true, slowmo_protect = true }, { __call = function() end })
local okrun, err, env, req = run("Trainer/setup/auto_init.lua", cfg, { fail_paths = { ["Trainer/addons/FreeBlackMarket"] = true } })
ok(okrun, "auto_init runs to the end even with a crashing feature: " .. tostring(err))
local failed = rawget(env, "PPR_FAILED_FEATURES") or {}
local has = {}
for _, v in ipairs(failed) do has[v] = true end
ok(has.FreeBlackMarket, "crashing feature recorded: " .. table.concat(failed, ","))
local later = {}
for _, p in ipairs(req) do later[p] = true end
ok(later["Trainer/addons/freepreplanning"] and later["Trainer/addons/nopause"] and later["Trainer/addons/crew_unlocker"], "features after the crash still loaded")
ok(later["Trainer/menu/firstlaunch"] and later["Trainer/custom_auto"], "first launch + user scripts still loaded")
ok(later["Trainer/addons/slowmo_protect"], "slowmo protection loaded")
print("  recorded failures: " .. table.concat(failed, ", "))

-- auto_ingame
local cfg2 = setmetatable({ NoEscapeTimer = true, DontFreezeRagdolls = true, DontDisposeRagdolls = true, NoCivilianPenality = true,
	LaserColorR = 1, Crosshair = true, HUD = true, ControlCheats = 1, far_placements = true }, { __call = function() end })
local okrun2, err2, env2, req2 = run("Trainer/setup/auto_ingame.lua", cfg2, { fail_paths = { ["Trainer/addons/freecivilians"] = true } })
ok(okrun2, "auto_ingame runs to the end: " .. tostring(err2))
local later2 = {}
for _, p in ipairs(req2) do later2[p] = true end
ok(later2["Trainer/addons/crosshair"] and later2["Trainer/custom_game"], "features after a crash still load in game")
print(("%d checks, %d failures"):format(checks, failures))
os.exit(failures == 0 and 0 or 1)
