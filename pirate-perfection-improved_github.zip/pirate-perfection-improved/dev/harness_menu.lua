-- Runs the REAL Trainer/tools/new_menu/menu.lua against an auto-mocked GUI to catch runtime errors
-- usage: luajit harness_menu.lua <mod_root_dir>
local MOD = arg[1]:gsub("/?$", "/")
local failures, checks = 0, 0
local function ok(c, m) checks = checks + 1 if not c then failures = failures + 1 print("FAIL: " .. m) end end

-- auto mock: any method returns another mock; numeric getters return numbers
local NUM = { w = 400, h = 20, x = 0, y = 0, left = 0, right = 400, top = 0, bottom = 20, center_x = 200, center_y = 10, font_size = 20, alpha = 1 }
local function automock(name)
	local m = { __name = name, __children = {} }
	return setmetatable(m, { __index = function(t, k)
		local f
		if NUM[k] then f = function() return NUM[k] end
		elseif k == "text_rect" then f = function() return 0, 0, 120, 20 end
		elseif k == "children" then f = function(self) return self.__children end
		elseif k == "inside" then f = function() return false end
		elseif k == "child" then f = function(self, n) for _, c in ipairs(self.__children) do if c.__cname == n then return c end end return nil end
		elseif k == "panel" or k == "text" or k == "rect" or k == "bitmap" then
			f = function(self, cfg) local c = automock(name .. "." .. k); c.__cname = cfg and cfg.name; table.insert(self.__children, c); return c end
		elseif k == "set_name" then f = function(self, n) self.__cname = n end
		elseif k == "name" then f = function(self) return self.__cname end
		elseif k:match("^set_") or k == "show" or k == "hide" then f = function() end
		else f = function() return automock(name .. ":" .. k) end end
		rawset(t, k, f)
		return f
	end })
end

function class() local c = {} c.__index = c c.new = function(self, ...) local o = setmetatable({}, c) if o.init then o:init(...) end return o end return c end
function callback(o, base, name, param) if param ~= nil then return function(...) return base[name](o, param, ...) end end return function(...) return base[name](o, ...) end end
function clone(t) local r = {} for k, v in pairs(t) do r[k] = v end return r end
void = function() end
function safecall(f, ...) local r = { pcall(f, ...) } if not r[1] then print("safecall error: " .. tostring(r[2])) failures = failures + 1 end return unpack(r, 2) end
function m_log_error(...) print("m_log_error", ...) end
function m_log_vs() end
function is_client() return false end
LOOPS = {}
function RunNewLoopIdent(id, f, a) LOOPS[id] = { f, a } end
function StopLoopIdent(id) LOOPS[id] = nil end
function executewithdelay() end
function load_plugin() return function() end end
Idstring = function(s) return s end
Color = setmetatable({}, { __call = function() return automock("color") end, __index = function() return automock("color") end })
ppr_io = { open = function(f, m) return io.open(MOD .. f, m) end }
local reqcache = {}
function ppr_require(path)
	local key = path:lower()
	if key:find("pluginmanager") then return true end
	if reqcache[key] then return unpack(reqcache[key]) end
	local p = MOD .. path
	local f = io.open(p, "rb") or io.open(p .. ".lua", "rb")
	local src = f:read("*a") f:close()
	local r = { assert(loadstring(src, "@" .. path))() }
	reqcache[key] = r
	return unpack(r)
end
plugins = { pre_require = function() return true end, required = {}, g_loaded = function() return false end }
togg_vars = {}
backuper = { restore = function() end, backup = function() end }
Localization = { translate = setmetatable({ prev_page = "< Önceki sayfa", next_page = "Sonraki sayfa >", back = "Geri", exit = "Kapat", host_only = "[ Sadece Kurucu ]" }, { __index = function(_, k) return k end }) }
TRIGGERS = {}
local controller = {
	enable = function() end, disable = function() end,
	add_trigger = function(self, conn, f) if conn == "menu_up" or conn == "menu_down" or conn == "cancel" or conn == "confirm" then TRIGGERS[conn] = f else error("no connection " .. conn) end end,
	remove_trigger = function(self, conn) TRIGGERS[conn] = nil end,
}
Input = { mouse = function() return { pressed = function() return false end } end }
Overlay = { gui = function() return { create_screen_workspace = function() return automock("ws") end, destroy_workspace = function() end } end }
managers = {
	mouse_pointer = { get_id = function() return 1 end, use_mouse = function() end, remove_mouse = function() end, set_pointer_image = function() end, _mouse = { x = function() return 0 end, y = function() return 0 end } },
	controller = { get_controller_by_name = function() return controller end, create_controller = function() return controller end, get_default_wrapper_index = function() return 1 end },
	gui_data = { layout_1280_workspace = function() end, scaled_size = function() return { width = 1280, height = 720 } end },
}
tweak_data = { menu = { pd2_large_font = "f", pd2_medium_font = "f" }, gui = { DIALOG_LAYER = 1 } }
SystemMenuManager = { GenericSystemMenuManager = { is_active = function() return false end } }
-- new_menu components (tickbox etc.) are required by menu.lua: provide light stubs
for _, n in ipairs({ "Tickbox", "Slider", "MultiChoice", "TextInput", "SaveButton" }) do
	_G[n] = { new = function() return { toggle = function() end, close = function() end, save = function() end } end }
end
local real_require = ppr_require
ppr_require = function(path)
	local l = path:lower()
	if l:find("new_menu/tickbox") or l:find("new_menu/slider") or l:find("new_menu/multi_choice") or l:find("new_menu/text_input") or l:find("new_menu/save_button") then return true end
	return real_require(path)
end

local Menu = ppr_require("Trainer/tools/new_menu/menu")
ok(type(Menu) == "table" and type(Menu.open) == "function", "menu module loads")

-- 1) small menu
local clicked = 0
local m = Menu.open(Menu, { title = "Test", description = "desc", button_list = {
	{ text = "A", callback = function() clicked = clicked + 1 end },
	{},
	{ text = "B", callback = function() clicked = clicked + 10 end, switch_back = true },
}, back = function() end })
ok(m and m._ws ~= nil, "menu opened")
ok(TRIGGERS.menu_up and TRIGGERS.menu_down, "keyboard nav triggers registered")
TRIGGERS.menu_down()
ok(m._focus_button == 1, "down -> first button, got " .. tostring(m._focus_button))
TRIGGERS.menu_down()
ok(m._focus_button == 3, "down skips spacer -> 3, got " .. tostring(m._focus_button))
TRIGGERS.menu_down()
ok(m._focus_button == 1, "wraps to 1")
TRIGGERS.menu_up()
ok(m._focus_button == 3, "up wraps to 3")
TRIGGERS.confirm()
ok(clicked == 10, "enter activates focused (switch_back keeps menu open)")
local nav = m.navigation_panel.__children
local back_label
for _, c in ipairs(nav) do if c.__cname == "previous_page" then back_label = true end end
ok(back_label, "back button exists")
m:close()
ok(TRIGGERS.menu_up == nil and TRIGGERS.menu_down == nil, "nav triggers removed on close")

-- 2) long menu -> pages
local list = {}
for i = 1, 50 do list[i] = { text = "Item " .. i, callback = function() end } end
local p1 = Menu.open(Menu, { title = "Long", button_list = list })
ok(p1._data.title == "Long  (1/3)", "page indicator: " .. tostring(p1._data.title))
ok(type(p1._data.next) == "function", "next page available")
p1._data.next()
local p2 = tweak_data.menu_active
ok(p2 and p2._data.title == "Long  (2/3)", "page 2 title: " .. tostring(p2 and p2._data.title))
ok(p2._data._back_is_page == true, "page 2 back is 'previous page'")
p2:close()

print(("%d checks, %d failures"):format(checks, failures))
os.exit(failures == 0 and 0 or 1)
