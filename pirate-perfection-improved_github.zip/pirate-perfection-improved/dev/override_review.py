#!/usr/bin/env python3
"""List trainer functions that replace a game method with a copied body.

Usage: override_review.py <game_src_root> <trainer_root>
Prints: similarity  trainer_lines/game_lines  Class:method  file
Low similarity on a long body = old copy of a game function (risky).
"""
import os, re, sys, difflib

game_root, trainer_root = sys.argv[1], sys.argv[2]
RE_DEF = re.compile(r'^([ \t]*)function\s+([A-Za-z_]\w*)[:.]([A-Za-z_]\w*)\s*\(', re.M)

def bodies(path):
    s = open(path, 'rb').read().decode('utf-8', 'replace')
    lines = s.split('\n')
    res = {}
    for i, line in enumerate(lines):
        m = RE_DEF.match(line)
        if not m:
            continue
        indent = m.group(1)
        body = [line]
        for j in range(i + 1, min(len(lines), i + 800)):
            body.append(lines[j])
            if re.match(r'^' + re.escape(indent) + r'end\b', lines[j]):
                break
        res[(m.group(2), m.group(3))] = body
    return res

game = {}
for d, _, fs in os.walk(game_root):
    for f in fs:
        if f.endswith('.lua'):
            for k, v in bodies(os.path.join(d, f)).items():
                game.setdefault(k, v)

norm = lambda b: [re.sub(r'\s+', ' ', l).strip() for l in b if l.strip() and not l.strip().startswith('--')]
rows = []
for d, _, fs in os.walk(trainer_root, followlinks=True):
    for f in fs:
        if not f.endswith('.lua'):
            continue
        p = os.path.join(d, f)
        for k, v in bodies(p).items():
            if k in game:
                tb, gb = norm(v), norm(game[k])
                if len(tb) < 12:
                    continue
                r = difflib.SequenceMatcher(None, tb, gb).ratio()
                rows.append((r, len(tb), len(gb), '%s:%s' % k, os.path.relpath(p, trainer_root)))
rows.sort()
for r in rows:
    print('%.2f  %3d/%-3d  %-55s %s' % r)
