-- Usage: luajit syncheck.lua <file1> <file2> ...
-- Compiles (does not run) each file; prints errors. Strips UTF-8 BOM like a tolerant loader would NOT (reports it).
local bad = 0
for i = 1, #arg do
  local path = arg[i]
  local f = io.open(path, "rb")
  if not f then
    print("CANNOT OPEN: " .. path); bad = bad + 1
  else
    local src = f:read("*a"); f:close()
    if src:sub(1,3) == "\239\187\191" then
      print("BOM: " .. path)
      src = src:sub(4)
    end
    local fn, err = loadstring(src, "@" .. path)
    if not fn then print("SYNTAX: " .. err); bad = bad + 1 end
  end
end
print(("checked %d files, %d errors"):format(#arg, bad))
os.exit(bad == 0 and 0 or 1)
