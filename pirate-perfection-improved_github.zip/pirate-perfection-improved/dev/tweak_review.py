#!/usr/bin/env python3
"""tweak_data.<a>.<b> chains used by the trainer that the current game does not define.
Usage: tweak_review.py <game_root> <trainer_root>"""
import os, re, sys, collections
G, T = sys.argv[1], sys.argv[2]
def walk(root):
    for d, _, fs in os.walk(root, followlinks=True):
        for f in fs:
            if f.endswith('.lua'):
                p = os.path.join(d, f)
                yield p, open(p, encoding='utf-8', errors='replace').read()
game = dict(walk(G))
td = game[os.path.join(G, 'lib/tweak_data/tweakdata.lua')]
first = set(re.findall(r'self\.(\w+)\s*=', td)) | set(re.findall(r'tweak_data\.(\w+)\s*=', '\n'.join(game.values())))
cls_of = dict(re.findall(r'self\.(\w+)\s*=\s*(\w+TweakData)\s*:\s*new', td))
second = collections.defaultdict(set)
for p, s in game.items():
    for a, b in re.findall(r'tweak_data\.(\w+)\.(\w+)\s*=', s):
        second[a].add(b)
    for a, b in re.findall(r'self\.(\w+)\.(\w+)\s*=', s) if p.endswith('tweakdata.lua') else []:
        second[a].add(b)
cls_fields = collections.defaultdict(set)
for p, s in game.items():
    if '/tweak_data/' in p:
        for c in set(re.findall(r'function (\w+TweakData)[:.]', s)):
            cls_fields[c] |= set(re.findall(r'self\.(\w+)\s*=', s))
            cls_fields[c] |= set(re.findall(r'\bself\.(\w+)\s*\[', s))
for a, c in cls_of.items():
    second[a] |= cls_fields.get(c, set())
used = collections.defaultdict(set)
for p, s in walk(T):
    if '/experimental/dev' in p:
        continue
    for a, b in re.findall(r'tweak_data\.(\w+)\.(\w+)', s):
        used[(a, b)].add(os.path.relpath(p, T))
    for a in re.findall(r'tweak_data\.(\w+)', s):
        used[(a, None)].add(os.path.relpath(p, T))
for (a, b), files in sorted(used.items(), key=lambda x: (x[0][0], x[0][1] or '')):
    fl = ', '.join(sorted(files)[:3])
    if a not in first and a not in second:
        if b is None:
            print('MISSING tweak_data.%s  <- %s' % (a, fl))
    elif b and second.get(a) and b not in second[a] and not re.match(r'^[a-z_]+\d', b):
        print('missing? tweak_data.%s.%s  <- %s' % (a, b, fl))
