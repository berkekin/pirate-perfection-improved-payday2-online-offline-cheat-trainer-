-- EXTEND INVENTORY SLOTS
-- Author: Baddog-11
-- v3.2: the game now has 320 weapon/mask slots by default and counts the total in
-- MAX_WEAPON_SLOTS / MAX_MASK_SLOTS. The old values (6x6 grid, 12 pages) gave only
-- 432 slots in the menu while the game still limited itself to 320, so slots past 320
-- did not work properly. Now the game's grid is kept and pages are added, and the
-- totals are updated too. Values are never lowered below the game's own.
-- Note: if you switch this off later, items stored past the normal slots may not show.

local gui = tweak_data and tweak_data.gui
if not gui then
	return
end

local WANTED_PAGES = 30	-- 30 pages x 16 slots = 480 slots

local function extend(rows_key, cols_key, pages_key, slots_key)
	local rows = gui[rows_key] or 4
	local cols = gui[cols_key] or 4
	local pages = math.max(gui[pages_key] or 0, WANTED_PAGES)
	gui[pages_key] = pages
	gui[slots_key] = math.max(gui[slots_key] or 0, pages * rows * cols)
end

extend('MASK_ROWS_PER_PAGE', 'MASK_COLUMNS_PER_PAGE', 'MAX_MASK_PAGES', 'MAX_MASK_SLOTS')
extend('WEAPON_ROWS_PER_PAGE', 'WEAPON_COLUMNS_PER_PAGE', 'MAX_WEAPON_PAGES', 'MAX_WEAPON_SLOTS')
