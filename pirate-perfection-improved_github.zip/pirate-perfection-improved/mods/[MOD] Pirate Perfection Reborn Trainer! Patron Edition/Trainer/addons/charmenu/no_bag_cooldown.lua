-- No bag cooldown
-- Author: Simplity
-- v3.2: the cooldown lives in PlayerManager (not PlayerMovement) since newer game
-- versions, so backup/restore now target the right function and turning it off works.

plugins:new_plugin('no_bag_cooldown')

VERSION = '1.1'

CATEGORY = 'character'

function MAIN()
	backuper:hijack('PlayerManager.carry_blocked_by_cooldown', function() return false end)
end

function UNLOAD()
	backuper:restore('PlayerManager.carry_blocked_by_cooldown')
end

FINALIZE()
