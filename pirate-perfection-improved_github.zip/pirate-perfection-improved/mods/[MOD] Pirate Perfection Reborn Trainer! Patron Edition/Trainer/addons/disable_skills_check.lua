-- Disable skills check
-- v3.2: the old version replaced SkillTreeManager:_verify_loaded_data with a copy
-- from an old game version. That copy skipped newer game code (for example perk
-- decks with multiple-choice cards such as Copycat). Now the game's current
-- function runs unchanged; only its "reset everything" step is switched off.

if not SkillTreeManager or not SkillTreeManager._verify_loaded_data then
	return
end

local orig_verify = SkillTreeManager._verify_loaded_data
local noop = function() end

function SkillTreeManager:_verify_loaded_data(...)
	local had_own = rawget(self, 'reset_specializations')
	self.reset_specializations = noop
	local res = { pcall(orig_verify, self, ...) }
	self.reset_specializations = had_own
	if not res[1] then
		error(res[2], 0)
	end
	return unpack(res, 2, table.maxn(res))
end
