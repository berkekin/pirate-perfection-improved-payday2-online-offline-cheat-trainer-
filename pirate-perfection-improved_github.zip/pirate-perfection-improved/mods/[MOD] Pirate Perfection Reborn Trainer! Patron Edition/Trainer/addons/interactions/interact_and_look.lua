-- Interact and look around
-- v3.2: rewritten for the current game. The old version replaced the whole
-- PlayerStandard:_check_action_interact with a copy from an old game version.
-- Now the game's own code runs; we only keep the interaction target locked
-- while the timer runs, so looking away no longer cancels it.

plugins:new_plugin('interact_and_look')

CATEGORY = 'interaction'

VERSION = '1.1'

function MAIN()
	backuper:hijack('PlayerStandard._update_interaction_timers', function(o, self, t, ...)
		local params = self._interact_expire_t and self._interact_params
		local im = self._interaction
		if params and im and alive(params.object) and im._active_unit ~= params.object then
			im._active_unit = params.object
		end
		return o(self, t, ...)
	end)
end

function UNLOAD()
	backuper:restore('PlayerStandard._update_interaction_timers')
end

FINALIZE()
