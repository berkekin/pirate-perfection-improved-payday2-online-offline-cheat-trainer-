-- Auto-skip the heist intro (host only) - PPR Improved Edition v3.2
-- Skips the intro exactly like holding the skip key: as soon as the game allows it
-- (all players finished loading). The old version used managers.network:game(),
-- which no longer exists, so it never did anything.
if not IngameWaitingForPlayersState or not IngameWaitingForPlayersState._chk_show_skip_prompt then
	return
end

-- after-callbacks receive (results, self, ...)
backuper:add_clbk('IngameWaitingForPlayersState._chk_show_skip_prompt', function(_, self)
	if self._skip_promt_shown and self._audio_started and not self._skipped and Network:is_server() then
		self:_skip()
	end
end, 'ppr_auto_skip_intro', 2)
