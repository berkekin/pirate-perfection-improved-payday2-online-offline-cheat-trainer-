--Purpose: Protection against forced slow-motion / time-stop sent by other players.
--Based on the "Slow-mo Protection" by Davy Jones (was part of disable_anticheat.lua).
--PPR Improved Edition: protection only (no "reverse to sender"), message spam is rate-limited.

if not UnitNetworkHandler or not UnitNetworkHandler.start_timespeed_effect then
	return
end

local Global = Global
local Color = Color
local Application = Application
local backuper = backuper
local tr = Localization.translate

local current_level = Global.game_settings and Global.game_settings.level_id
--The only vanilla heist that uses a network time effect is Hotline Miami day 2 (scripted slow-mo once).
local heist_lock = true
local last_warning = {}
local WARN_COOLDOWN = 10

backuper:hijack('UnitNetworkHandler.start_timespeed_effect', function(o, self, effect_id, timer_name, affect_timer_names_str, speed, fade_in, sustain, fade_out, sender)
	if heist_lock and current_level == 'mia_2' and (sustain or 0) <= 5 and (affect_timer_names_str == nil or affect_timer_names_str == "player;") then
		heist_lock = false
		return o(self, effect_id, timer_name, affect_timer_names_str, speed, fade_in, sustain, fade_out, sender)
	end

	local chat = managers.chat
	local peer = self._verify_sender and self._verify_sender(sender)
	local now = Application:time()
	local id = peer and peer:id() or 0
	if chat and (not last_warning[id] or now - last_warning[id] > WARN_COOLDOWN) then
		last_warning[id] = now
		local who = peer and peer:name() or "?"
		chat:_receive_message(1, tr.slowmo_protect_title, who .. tr.slowmo_protect_blocked, Color.red)
	end
	--Blocked: the effect is not applied.
end)
