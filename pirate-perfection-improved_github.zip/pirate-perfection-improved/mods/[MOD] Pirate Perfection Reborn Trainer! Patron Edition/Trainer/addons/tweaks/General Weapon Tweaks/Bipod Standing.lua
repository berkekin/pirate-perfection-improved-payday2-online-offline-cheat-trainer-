-- Bipod Standing: deploy the bipod anywhere, also while standing.
-- v3.2: the old version replaced WeaponLionGadget1:_shoot_bipod_rays with a copy
-- from an old game version (it used fields the game no longer has). Now the game's
-- current function runs with a longer bipod ray, which was the only real change.

if not WeaponLionGadget1 or not WeaponLionGadget1._shoot_bipod_rays then
	return
end

local orig_rays = WeaponLionGadget1._shoot_bipod_rays
local LONG_REACH = 9000

function WeaponLionGadget1:_shoot_bipod_rays(...)
	local old_length = WeaponLionGadget1.bipod_length
	if not self._bipod_offsets and self.get_offsets then
		pcall(self.get_offsets, self)
	end
	-- Keep the bipod's own position where the game would put it.
	if self._bipod_offsets and not self._bipod_offsets.distance then
		self._bipod_offsets.distance = old_length or 90
	end
	WeaponLionGadget1.bipod_length = LONG_REACH
	local res = { pcall(orig_rays, self, ...) }
	WeaponLionGadget1.bipod_length = old_length
	if not res[1] then
		return orig_rays(self, ...)
	end
	return unpack(res, 2, table.maxn(res))
end
