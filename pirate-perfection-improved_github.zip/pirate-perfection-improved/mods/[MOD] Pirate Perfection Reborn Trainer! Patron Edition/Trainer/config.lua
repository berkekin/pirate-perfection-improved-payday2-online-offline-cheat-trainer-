-- Pirate Perfection Reborn Trainer - Improved Edition - Main configuration file
-- EN: true = ON, false = OFF. Most options can also be changed in game: F3 (main menu) -> "PPR Setup Menu", or F5 -> Settings.
-- TR: true = AÇIK, false = KAPALI. Çoğu ayarı oyun içinden de değiştirebilirsin: F3 (ana menü) -> "PPR Kurulum Menüsü" veya F5.
-- Changes made from the menus are saved into Trainer/configs/menu_config.lua (this file is not touched).

return {
-- Trainer
 -- Keybinds
	DisableBindings = false,						-- true: disables all trainer hotkeys (F1-F12 etc.)
	keyconfig = 'Trainer/keyconfig.lua',			-- Key bindings file

 -- Language / Dil
	Language = 'turkish',							-- 'turkish' (Türkçe) or 'english'. Old community translations: 'german', 'french', 'italian', 'spanish', 'portuguese', 'russian', 'korean', 'chinese-simplified', 'chinese-traditional'
	TurkishCharMode = 'safe',						-- 'safe': ç ö ü kept, ğ ş ı İ written as g s i I (PAYDAY 2 fonts have no glyphs for them)
													-- 'full': all Turkish letters (only with a font mod) / 'ascii': no special letters at all
	DefaultConfig = 'default_config',				-- Cheat config file loaded automatically (Trainer/configs/<name>.lua)

 -- HUD Texts
	HUD = true,										-- false: disables ALL trainer HUD elements
	HUD_VersionText = true,							-- Trainer version text in the main menu
	HUD_MovingText = true,							-- Moving tips text in the main menu / in game (local texts, no internet)
	HUD_ActiveCheats = true,						-- In game: list of active cheats in the top right corner (red on someone else's lobby)

 -- Logging
	LogErrorsToFile = true,							-- Also write trainer errors into the error log file

-- General
	NoStatsSynced = true,							-- Don't publish statistics to Steam (keeps cheated numbers off your Steam profile)
	AllPerks = false,								-- Bonuses from all perk decks at once (can be unstable when changing armor)
	Extend_Inventory_Slots = false,					-- Extend inventory slots
	DisableSkillsCheck = true,						-- Stops the game from resetting edited skills / perk points / infamy on load
	NoSmallLootCap = true,							-- Removes the small loot value cap

 -- Unlocker (progress based items only)
	NoSkinMods = false,								-- Weapon skins you own don't force their own weapon mods
	unlocked_hoxton = false,						-- Old Hoxton without the requirement
	unlocked_arbiter = false,						-- Arbiter grenade launcher without collecting the Gage spec ops cases
	unlocked_aldstone_items = false,				-- All Aldstone's Heritage items
	CrewUnlocker = false,							-- All crew (AI) abilities and boosts

 -- Lobby
	StraightToMainMenu = false,						-- Skip intro screens
	DisableAutoKick = true,							-- Your own lobby does not auto-kick cheaters
	NoDropinPause = false,							-- No drop-in pause
	HostMatters = true,								-- Host's preplanning choice wins the vote
	FreeBlackMarket = false,						-- Black market purchases cost nothing
	FreeAssets = false,								-- Assets cost nothing
	FreePreplanning = false,						-- Preplanning costs nothing (no favors used)
	FreeCrimeSpree = false,							-- Crime Spree start/continue/reroll costs nothing
	ReduceDetectionLevel = false,					-- Lowest possible detection risk

 -- Exceptions
	ExceptionsEnabled = true,						-- Warning dialogs before risky equipment actions
	ExceptionsCrashDetect = false,					-- Try to detect a previous crash (requires ExceptionsEnabled)

 -- Cheater-tag safety / Hileci etiketi güvenliği
	ControlCheats = 1,								-- false = off, 1 = only when you're a client on someone else's lobby, 2 = always.
													-- Blocks equipment/grenade actions that would get you tagged as a cheater.
	slowmo_protect = true,							-- Blocks forced slow-motion / time-stop sent to you by other players

 -- Equipment placement
	far_placements = true,							-- Place equipment at any distance
	equipment_place_key = '4',						-- Key used by the equipment placement menu

 -- Main options
	NoCivilianPenality = true,						-- No penalty for killing civilians
	NoInvisibleWalls = false,						-- Removes invisible walls (host only)
	RestartProMissions = true,						-- Allow restarting pro jobs (host only)
	RestartJobs = true,								-- "Restart" button when hosting
	AutoSkipIntro = false,							-- Skip the heist intro as soon as everyone loaded (host only) / Herkes yüklenince girişi otomatik geç (sadece host)
	NoEscapeTimer = false,							-- No escape timer (host only)
	Crosshair = true,								-- Crosshair on all weapons
	LaserColorR = 125,								-- Laser color (Red, Green, Blue 0-255). Set to false to disable.
	LaserColorG = 75,
	LaserColorB = 205,
	DontFreezeRagdolls = false,						-- Corpses never freeze (may cost FPS)
	DontDisposeRagdolls = false,					-- Corpses never disappear (may cost FPS)
	SecureAll = false,								-- Secure any bag on any map

 -- Fly / Noclip
	FreeFlightTeleport = false,						-- Leaving free-flight drops you at the camera position
	NoClipSpeed = 1,								-- Noclip speed (default 1)

 -- Kill all
	KillAllIgnoreTied = true,						-- Kill all: ignore tied hostages
	KillAllIgnoreCivilians = true,					-- Kill all: ignore civilians
	KillAllIgnoreEnemies = false,					-- Kill all: ignore enemies
	KillAllTouchCameras = true,						-- Kill all: destroy cameras too

 -- Character
	JumpHeightMultiplier = 5,						-- Jump height multiplier (default 5)
	RunSpeed = 115,									-- Max run speed (default 115)

 -- Job menu
	jobmenu_def_difficulty = 'overkill_145',		-- Default difficulty id: normal, hard, overkill (Very Hard), overkill_145 (Overkill), easy_wish (Mayhem), overkill_290 (Death Wish), sm_wish (Death Sentence)
	jobmenu_singleplayer = false,					-- Job menu hosts single player games by default

 -- Game fixes
	DisableBulletFix = false,						-- Disable the delayed bullet effect fix
	DisableInvFix = false,							-- Disable the crash fix when another player changes weapon
	EnableJobFix = true,							-- See lobbies with jobs the game thinks are "too hard"

 -- Spawn menu
	SpawnUnitsAmount = 1,							-- Units spawned per click
	SpawnPos = 'ray',								-- 'ray' (crosshair), 'spawn_point', 'random_spawn_point'
	SpawnCivsAnim = 'cm_sp_stand_idle',				-- Default civilian animation
	SpawnEnemyAnim = 'idle',						-- Default enemy animation
	SpawnUnitKey = "7",								-- Spawn unit key

 -- Inventory menu
	rain_bags_amount = 100,							-- Bags spawned by "bag rain"
	SpawnBagsAmount = 1,							-- Bags spawned per click
	SpawnBagKey = "8",								-- Spawn bag key

 -- Slow motion
	SmSpeed = 20,									-- Slow motion speed (%)
	SmSlowPlayer = true,							-- Slow motion also slows the player

 -- X-Ray (colors are Red, Green, Blue 0-255)
	xray_Cams = true,
	xray_CamsColR = 255,
	xray_CamsColG = 50,
	xray_CamsColB = 0,

	xray_Civ = true,
	xray_CivColR = 0,
	xray_CivColG = 0,
	xray_CivColB = 255,

	xray_CivKeyColR = 255,
	xray_CivKeyColG = 255,
	xray_CivKeyColB = 0,

	xray_Cops = true,
	xray_CopsColR = 255,
	xray_CopsColG = 0,
	xray_CopsColB = 0,

	xray_CopsKeyColR = 255,
	xray_CopsKeyColG = 100,
	xray_CopsKeyColB = 0,

	xray_SpecialColR = 150,
	xray_SpecialColG = 50,
	xray_SpecialColB = 205,

	xray_SniperColR = 0,
	xray_SniperColG = 125,
	xray_SniperColB = 0,

	xray_FriendlyR = 50,
	xray_FriendlyG = 205,
	xray_FriendlyB = 255,

	xray_Items = true,								-- Highlight objective items (keycards etc.)

 -- Teleport
	TeleportPenetrate = true,						-- Teleport can go through walls

 -- AimBot (works on AI enemies)
	ShootThroughWalls = false,
	MaxAimDist = 8000,
	AimbotInfAmmo = false,
	AimbotDamageMul = 2,							-- false = default weapon damage
	AimMode = 2,									-- 1 = only auto shoot, 2 = only aim, 3 = aim and shoot
	RightClick = true,								-- Only works while right mouse button is held

 -- Lego
	LegoFile = 'default',
	LegoDeleteKey = 'h',
	LegoSpawnKey = '6',
	LegoPrevKey = '7',
	LegoNextKey = '8',

 -- Debug HUD
	DebugDramaDraw = false,
	DebugStateDraw = false,
	DebugConsole = false,
	DebugNavDraw = false,
	DebugAdditionalEsp = false,
	DebugMissionElements = false,
	DebugElementsAdditional	= false,
	EnableDebug = false,							-- Debug menu + free-flight
	LegacyMenu = false,								-- Show config names instead of texts in the PPR Setup menu

-- Fixes
	CrashFixer = false,
	LoopFireSounds = false,
	SentryIgnoresShields = false,
	CheckGhostBonus = false,
	CheckLobbyHandler = false,
	CheckMeleeAttack = false,
	CheckMissionDoorDevicePlaced = false,

-- Tweaks (advanced: values are in the .lua files in Trainer/addons/tweaks)
	armor_tweaks = false,
	vehicle_tweaks = false,
	iceaxe_tweaks = false,
	CAR4_tweaks = false,
	M79_tweaks = false,
	Bernetti9mm_tweaks = false,
	ChinaPuff_tweaks = false,
	Glock18c_tweaks = false,
	Ace_tweaks = false,
	Frag_Grenade_tweaks = false,
	Bipod_Freelook = false,
	Bipod_Standing = false,
	Bullet_Penetration = false,
	Drum_Magazine_Mod = false,
	Gadget_Always_On = false,
	Improved_Tripmine = false,
	Increased_Pickup_Ammo = false,
	LMG_Scopes = false,
	projectiles_Tweaks = false,
	Rocket_Jump = false,
	Sentry_Gun_Tweaks = false,
	Shotgun_Physics = false,
	Weapon_Parts_Tweaks = false,
	Weapon_Tweaks = false,

 -- Custom Safehouse
	SafeHouseDoors = true,							-- Doors in the safehouse actually open
	SafeHouseInvest = false,						-- Offshore investment mini game
	SafeHouseInvestAmt = 500,						-- Investment amount
	SafeHouseLego = false,							-- Load the 'custom_safehouse' lego file in the safehouse

-- Internal: sub menu ids of the PPR Setup menu (avoids "key not defined" log spam)
	Language_Sub = nil,
	HUD_Sub = nil,
	General_Sub = nil,
	Unlocker_Sub = nil,
	Safety_Sub = nil,
	Equipment_Sub = nil,
	Misc_Sub = nil,
	flying_sub = nil,
	KillAll_sub = nil,
	character_sub = nil,
	job_sub = nil,
	Spawn_sub = nil,
	inventory_sub = nil,
	slow_sub = nil,
	xray_sub = nil,
	aimbot_sub = nil,
	Lego_sub = nil,
	Lasercolor = nil,
	xray_CamsCol = nil,
	xray_CivCol = nil,
	xray_CopsCol = nil,
	xray_SpecialCol = nil,
	xray_SniperCol = nil,
	xray_Friendly = nil,
}
