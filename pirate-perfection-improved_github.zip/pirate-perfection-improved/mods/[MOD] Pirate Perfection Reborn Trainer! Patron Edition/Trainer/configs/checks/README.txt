PPR Improved Edition: this folder stores small check files (first launch, crash detection).
Bu klasör küçük kontrol dosyalarını tutar.
