return function( cfg )
	-- Settings you change in the trainer menus are saved here automatically.
	-- Trainer menülerinde değiştirdiğin ayarlar buraya otomatik kaydedilir.
end
