-- PPR Improved Edition - preset profile: LOUD / ÇATIŞMA
-- Load it from F2 > Load configuration file. (Host-only options only work when you host.)
-- F2 > Ayar dosyası yükle ile açılır. (Kurucu seçenekleri sadece oyunu sen kurduğunda çalışır.)
return function( cfg )
	cfg.god_mode = true
	cfg.infinite_ammo = true
	cfg.no_recoil = true
	cfg.max_accurate = true
	cfg.no_hit = true
	cfg.no_flash_bangs = true
	cfg.no_fall_damage = true
	cfg.infinite_stamina = true
	cfg.increase_speed = true
	cfg.inf_equipments = true
	cfg.instant_deployments = true
	cfg.drill_auto_service = true
	cfg.invulnerable_sentry = true
	cfg.sentry_infinite_ammo = true
end
