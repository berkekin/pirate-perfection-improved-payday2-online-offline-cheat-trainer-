-- PPR Improved Edition - preset profile: STEALTH / GIZLILIK
-- Load it from F2 > Load configuration file. (Host-only options only work when you host.)
-- F2 > Ayar dosyası yükle ile açılır. (Kurucu seçenekleri sadece oyunu sen kurduğunda çalışır.)
return function( cfg )
	cfg.dont_call_police = true
	cfg.prevent_panic_buttons = true
	cfg.disable_pagers = true
	cfg.disable_cams = true
	cfg.inf_pager_answers = true
	cfg.inf_cable_activated = true
	cfg.inf_body_bags = true
	cfg.inf_follow_hostages = true
	cfg.steal_pagers_on_melee = true
	cfg.fast_interaction = true
	cfg.instant_intimidation = true
	cfg.no_fall_damage = true
	cfg.infinite_stamina = true
end
