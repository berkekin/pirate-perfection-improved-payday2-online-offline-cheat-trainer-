--Purpose: small on-screen list of the trainer cheats that are currently ON (in game only).
--PPR Improved Edition v3.1. The list turns red when you are a client on someone else's lobby,
--as a reminder that cheats there can get you tagged as a cheater.
--Turn it off: F3 > PPR Setup > HUD Texts, or F5 hub.

if not GameSetup then
	return
end
local ppr_obj = rawget(_G, 'ppr_obj')
if not ppr_obj then
	return
end

local pairs = pairs
local type = type
local pcall = pcall
local rawget = rawget
local math_min = math.min
local tab_insert = table.insert
local tab_concat = table.concat
local tab_sort = table.sort
local Application = Application
local Color = Color
local L = Localization
local tr = L.translate

--Plugin name -> translation id (unknown plugins are shown with their own name)
local LABELS = {
	god_mode = 'togg_godmode', buddha_mode = 'buddha_mode', less_damage = 'reduce_damage', no_hit = 'togg_no_hit',
	no_fall_damage = 'togg_no_fall_damage', no_flash_bangs = 'togg_no_flash_bangs', infinite_stamina = 'togg_infinite_stamina',
	inf_ammo_reload = 'inf_ammo_reload', infinite_ammo = 'togg_ammo', no_headbob = 'no_headbob',
	increase_standard_speed = 'increase_standard_speed', no_bag_cooldown = 'togg_no_bag_cooldown', high_jump = 'togg_jumping',
	increase_speed = 'togg_speed', kill_in_one_hit = 'togg_kill_in_one_hit', increase_melee_dmg = 'togg_increase_melee_dmg',
	explosive_bullets = 'togg_bullets', shoot_through_walls = 'togg_shoot_through_walls', extreme_firerate = 'togg_crazyness',
	no_recoil = 'togg_recoil', max_accurate = 'togg_accurate', long_melee_range = 'togg_melee_range',
	instant_melee = 'togg_melee_charge', no_delay_melee = 'togg_melee_no_delay', grenade_weapon = 'grenade_bullets',
	nodelaytalk2 = 'annoyer_mode',
	noclip = 'mod_noclip', aimbot = 'mod_aimbot', driver = 'mod_driver', helicopter = 'mod_helicopter',
	wavehouse = 'mod_wavehouse', Terminator_HUD = 'mod_TerminatorHUD',
	invisible_player = 'invisible_player', lobotomize_ai = 'lobotomize_ai', cops_dont_shoot = 'cops_dont_shoot',
	dont_call_police = 'people_dont_call_police', disable_cams = 'dis_cams', disable_pagers = 'dis_pagers',
	prevent_panic_buttons = 'prevent_panic_buttons', inf_cable_activated = 'inf_cable', inf_battery_activated = 'inf_ecm_battery',
	inf_body_bags = 'inf_body_bags', inf_pager_answers = 'inf_pager_answ', inf_converts = 'inf_converts',
	inf_follow_hostages = 'inf_follow_hostages', steal_pagers_on_melee = 'steal_pagers', change_fov = 'change_fov',
	interact_with_all = 'patch_int_all', infinite_distance = 'patch_int_distance', ignore_walls = 'patch_int_nowalls',
	instant_intimidation = 'patch_instant_intimidation', instant_lootpile = 'patch_instant_lootpile', reboard = 'patch_int_reboard',
	interact_team = 'patch_int_team', interact_and_look = 'patch_interact_and_look', noone_shall_down = 'patch_noone_downs',
	interactions_speed_modifier = 'patch_int_speed',
	waypoints = 'way_pointing', debug_hud = 'debug_hud', intimidator = 'intimidator', shutdown_dialogs = 'shutdown_dialogs',
	reduce_ai_health = 'reduce_ai_health', increase_ai_amount = 'increase_ai_amount', pointless_medics = 'pointless_medics',
	Auto_counter_Cloakers = 'Auto_counter_Cloakers', autocooker = 'auto_cooker',
	bag_throw_force = 'bag_throw_force', sync_bag_throw_force = 'sync_bag_throw_force', bag_no_penalty = 'bag_no_speed_penalty',
	explosive_bags = 'explosive_bags',
	invulnerable_sentry = 'equip_sentry_inv', sentry_infinite_ammo = 'equip_sentry_infammo', drill_auto_service = 'equip_drill_service',
	instant_deployments = 'equip_instant_deployments', non_consumable_equipments = 'equip_infinite_bags', inf_equipments = 'equip_inf_equipments',
	instantdrills = 'equip_drill_instant', sentry_nades = 'equip_sentry_ammo_toggle',
	always_dismember = 'always_dismember', spoof_detection_lvl = 'spoof_detection_lvl', ReduceDetectionLevel = 'spoof_detection_lvl',
	level_revolver = 'level_revolver', no_weap_mod_limit = 'no_weap_mod_limit', armor_tweaks = 'base_armor_tweaks',
}
--Automatic helpers, not cheats you switched on
local HIDDEN = { equipment_control = true, long_placement = true }

local MAX_LINES = 10
local INTERVAL = 0.5

local tobj = ppr_obj:text('ppr_active_cheats', ' ', 0, 0, 18, Color(0.85, 0.85, 0.85), nil, 6)
ppr_obj.__elements.ppr_active_cheats = tobj
tobj:hide()

local last_t = 0
local last_text

--Returns sorted list of active cheat names
function PPR_ActiveCheats()
	local list, seen = {}, {}
	local function add( label )
		if label and not seen[label] then
			seen[label] = true
			tab_insert(list, label)
		end
	end
	local pm = rawget(_G, 'plugins')
	local reg = pm and pm.plugins
	if type(reg) == 'table' then
		for name, p in pairs(reg) do
			if type(p) == 'table' and p.loaded and not HIDDEN[name] then
				local key = LABELS[name]
				add(key and tr[key] or tostring(name))
			end
		end
	end
	local xr = rawget(_G, 'gxray_Toggle')
	if type(xr) == 'function' then
		local ok, _, state = pcall(xr)
		if ok and state then
			add(tr.base_xray_sub)
		end
	end
	if rawget(_G, '_godLike') then
		add(tr.togg_godmode)
	end
	tab_sort(list)
	return list
end

local function update()
	if ppr_config.HUD_ActiveCheats == false then
		if last_text then
			tobj:hide()
			last_text = nil
		end
		return
	end
	local now = Application:time()
	if now - last_t < INTERVAL then
		return
	end
	last_t = now

	local list = PPR_ActiveCheats()
	if #list == 0 then
		if last_text then
			tobj:hide()
			last_text = nil
		end
		return
	end

	local client = is_client and is_client()
	local lines = { client and tr.hud_active_title_client or tr.hud_active_title }
	for i = 1, math_min(#list, MAX_LINES) do
		lines[#lines + 1] = "- " .. list[i]
	end
	if #list > MAX_LINES then
		lines[#lines + 1] = L:text('hud_active_more', #list - MAX_LINES)
	end
	local text = tab_concat(lines, "\n")
	if text ~= last_text then
		last_text = text
		tobj:set_text(text)
		local _, _, w, h = tobj:text_rect()
		tobj:set_size(w, h)
		local pw = ppr_obj.panel and ppr_obj.panel:w() or RenderSettings.resolution.x
		tobj:set_x(pw - w - 20)
		tobj:set_y(70)
	end
	tobj:set_color(client and Color(1, 0.35, 0.35) or Color(0.85, 0.85, 0.85))
	tobj:show()
end

RunNewLoopIdent('ppr_active_cheats', update)
