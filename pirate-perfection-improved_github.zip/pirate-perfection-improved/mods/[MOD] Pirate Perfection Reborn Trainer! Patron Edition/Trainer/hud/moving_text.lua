--Purpose: moving tip text at the top of the screen (main menu / in game).
--Improved Edition: texts come from the translation files (moving_1 ... moving_N), no internet download.
--(The old version downloaded the texts from a Bitbucket page that no longer exists and crashed
-- with "interval is empty" when the download failed.)

local speed = 100
local dist_mul = GameSetup and 2 or 1 --Rarer text in game, more frequent in the menu

local ppr_obj = ppr_obj
local math_rand = math.random
local Color = Color
local RenderSettings = RenderSettings
local max_x = RenderSettings.resolution.x
local tr = Localization.translate

local function get_texts()
	local list = {}
	for i = 1, 20 do
		local key = 'moving_' .. i
		local s = rawget(tr, key) or (Localization.default_lan and Localization.default_lan[key])
		if type(s) ~= 'string' then
			break
		end
		list[#list + 1] = s
	end
	if #list == 0 then
		list[1] = "Pirate Perfection Reborn - " .. tr.moving_edition .. " | F5"
	end
	return list
end

local function random_text()
	local list = get_texts() --read every time, so a language change is picked up
	return list[math_rand(1, #list)]
end

local tobj = ppr_obj:text('moving_text', random_text(), max_x, 0, nil, Color(math_rand(), math_rand(), math_rand()), nil, 0)
ppr_obj.__elements.moving_text = tobj

local main_timer = TimerManager:main()
local get_delta_time = main_timer.delta_time

local function update()
	tobj:set_x(tobj:x() - (get_delta_time(main_timer) * speed))
	if tobj:x() < -max_x * dist_mul then
		tobj:hide()
		tobj:set_text(random_text())
		do
			local _, _, w, h = tobj:text_rect()
			tobj:set_size(w, h)
		end
		tobj:set_x(max_x + tobj:w() * dist_mul)
		--Light colors only, so the text is always readable
		tobj:set_color(Color(0.5 + math_rand() * 0.5, 0.5 + math_rand() * 0.5, 0.5 + math_rand() * 0.5))
		tobj:show()
	end
end

RunNewLoopIdent('moving_text', update)
