--Purpose: shows the trainer version in the main menu (Improved Edition: localized, fixed nil arguments)

backuper:hijack('MenuNodeMainGui._add_version_string', function(o, self, ...)
	local r = o(self, ...)
	local vs = self._version_string
	if vs then
		vs:set_text(Localization:text('version_text',
			ppr_config.const_version or '?',
			ppr_config.const_edition or '',
			tostring(Application:version()),
			Localization:language_name()))
		vs:set_align("center")
		vs:set_vertical("bottom")
		vs:set_color(Color.Patron)
		vs:set_font_size(20)
		vs:set_alpha(1)
		vs:set_w(1234)
		vs:set_h(666)
	end
	return r
end)
