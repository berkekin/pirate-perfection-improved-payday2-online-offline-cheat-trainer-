-- Ammo and health refill + reset own state (SuperBLT keybind) - PPR Improved Edition
if inGame() and isPlaying() and not inChat() and not InOverlay() then
	local player = managers.player:player_unit()
	if alive(player) then
		player:base():replenish()
		managers.player:set_player_state("standard")
		local tr = Localization.translate
		show_mid_text(tr.kb_refill_text, tr.kb_refill_title, 1.5)
	end
end
