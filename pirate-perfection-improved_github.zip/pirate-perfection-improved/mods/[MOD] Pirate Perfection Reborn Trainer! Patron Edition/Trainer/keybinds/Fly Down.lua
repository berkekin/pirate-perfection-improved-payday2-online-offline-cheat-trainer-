-- Fly down / normal gravity (SuperBLT keybind) - PPR Improved Edition
if inGame() and isPlaying() and not inChat() then
	local unit = managers.player:player_unit()
	if alive(unit) then
		local mover = unit:mover()
		mover:set_velocity(Vector3(0, 0, 0))
		mover:set_gravity(Vector3(0, 0, -400))
		mover:jump()
	end
end
