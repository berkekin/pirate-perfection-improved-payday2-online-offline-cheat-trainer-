-- Hover: stop falling (SuperBLT keybind) - PPR Improved Edition
-- (the old version overwrote the global show_mid_text with swapped arguments)
if inGame() and isPlaying() and not inChat() then
	local unit = managers.player:player_unit()
	if alive(unit) then
		local mover = unit:mover()
		mover:set_velocity(Vector3(0, 0, 0))
		mover:set_gravity(Vector3(0, 0, 0))
		mover:jump()
	end
end
