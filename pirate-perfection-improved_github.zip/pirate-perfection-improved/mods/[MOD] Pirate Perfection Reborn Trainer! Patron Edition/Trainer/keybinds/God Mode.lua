-- God mode toggle (SuperBLT keybind) - PPR Improved Edition
if inGame() and isPlaying() and not inChat() then
	local tr = Localization.translate
	local unit = managers.player:player_unit()
	if alive(unit) then
		_godLike = not _godLike
		unit:character_damage():set_god_mode(_godLike and true or false)
		if _godLike then
			show_mid_text(tr.kb_god_on_text, tr.kb_god_on, 1.0)
		else
			show_mid_text(tr.kb_god_off_text, tr.kb_god_off, 1.0)
		end
	end
end
