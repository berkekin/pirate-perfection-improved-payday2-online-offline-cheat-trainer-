-- Place a "lego" block (grenade crate) where you look (SuperBLT keybind, host only) - PPR Improved Edition
if inGame() and isPlaying() and not inChat() then
	if not isHost() then
		show_hint(Localization.translate.kb_host_only)
		return
	end
	local camera = managers.player:player_unit():movement()._current_state._ext_camera
	local mvec_to = Vector3()
	local from_pos = camera:position()
	mvector3.set(mvec_to, camera:forward())
	mvector3.multiply(mvec_to, 20000)
	mvector3.add(mvec_to, from_pos)
	local col_ray = World:raycast("ray", from_pos, mvec_to, "slot_mask", managers.slot:get_mask("bullet_impact_targets"))
	if col_ray then
		GrenadeCrateBase.spawn(col_ray.position, managers.player:player_unit():rotation())
		local Lego = rawget(_G, "Lego")
		if Lego and Lego.record then
			local fh = ppr_io.open("Trainer/addons/lego/save.lua", "a")
			if fh then
				fh:write("GrenadeCrateBase.spawn( ", tostring(col_ray.position), " , managers.player:player_unit():rotation()) \n")
				fh:close()
			end
		end
	end
end
