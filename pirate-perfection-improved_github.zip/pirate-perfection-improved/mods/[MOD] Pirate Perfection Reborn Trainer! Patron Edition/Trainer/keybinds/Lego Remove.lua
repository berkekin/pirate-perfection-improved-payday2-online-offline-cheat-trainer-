-- Remove the "lego" block (grenade crate) you look at (SuperBLT keybind, host only) - PPR Improved Edition
if inGame() and isPlaying() and not inChat() then
	if not isHost() then
		show_hint(Localization.translate.kb_host_only)
		return
	end
	local camera = managers.player:player_unit():movement()._current_state._ext_camera
	local mvec_to = Vector3()
	local from_pos = camera:position()
	mvector3.set(mvec_to, camera:forward())
	mvector3.multiply(mvec_to, 20000)
	mvector3.add(mvec_to, from_pos)
	local col_ray = World:raycast("ray", from_pos, mvec_to, "slot_mask", managers.slot:get_mask("bullet_impact_targets"))
	if col_ray and col_ray.unit:name() == Idstring("units/payday2/equipment/gen_equipment_grenade_crate/gen_equipment_grenade_crate") then
		--Remove the saved line of this block (if it was recorded)
		local path = "Trainer/addons/lego/save.lua"
		local fh = ppr_io.open(path, "r")
		if fh then
			local b = fh:read("*all") or ""
			fh:close()
			local a = tostring(col_ray.unit:position())
			a = a:gsub("[%(%)%.%-%+%[%]%*%?%^%$%%]", "%%%0")
			b = b:gsub("GrenadeCrateBase%.spawn%( " .. a .. " , managers%.player:player_unit%(%):rotation%(%)%) \n", "")
			local out = ppr_io.open(path, "w")
			if out then
				out:write(b)
				out:close()
			end
		end
		World:delete_unit(col_ray.unit)
	end
end
