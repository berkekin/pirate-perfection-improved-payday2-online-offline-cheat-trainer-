-- Opens the music menu (SuperBLT keybind) - PPR Improved Edition
-- The old file was a copy of music_menu.lua that only returned the menu function, so the keybind did nothing.
local open = ppr_require('Trainer/keybinds/music_menu')
if type(open) == 'function' then
	open()
end
