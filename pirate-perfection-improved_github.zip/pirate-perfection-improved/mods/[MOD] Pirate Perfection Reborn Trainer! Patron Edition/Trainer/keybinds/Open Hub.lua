-- Opens the PPR hub menu (SuperBLT keybind) - PPR Improved Edition
local open = ppr_require('Trainer/menu/hub')
if type(open) == 'function' then
	open()
end
