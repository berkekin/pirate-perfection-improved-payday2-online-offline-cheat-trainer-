-- Spawn an ammo bag where you look (SuperBLT keybind, host only) - PPR Improved Edition
if inGame() and isPlaying() and not inChat() then
	local tr = Localization.translate
	local player = managers.player:player_unit()
	if not isHost() then
		show_hint(tr.kb_host_only)
	elseif alive(player) then
		local from = player:movement():m_head_pos()
		local to = from + player:movement():m_head_rot():y() * 200
		local ray = player:raycast("ray", from, to, "slot_mask", managers.slot:get_mask("trip_mine_placeables"), "ignore_unit", {})
		if ray then
			local rot = player:movement():m_head_rot()
			AmmoBagBase.spawn(ray.position, Rotation(rot:yaw(), 0, 0), managers.player:upgrade_level("ammo_bag", "ammo_increase"))
		end
	end
end
