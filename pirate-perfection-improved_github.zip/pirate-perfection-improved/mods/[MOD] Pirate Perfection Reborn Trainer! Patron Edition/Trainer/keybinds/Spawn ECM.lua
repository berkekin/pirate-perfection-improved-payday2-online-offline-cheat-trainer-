-- Spawn an ECM jammer where you look (SuperBLT keybind, host only) - PPR Improved Edition
if inGame() and isPlaying() and not inChat() then
	local tr = Localization.translate
	local player = managers.player:player_unit()
	if not isHost() then
		show_hint(tr.kb_host_only)
	elseif alive(player) then
		local from = player:movement():m_head_pos()
		local to = from + player:movement():m_head_rot():y() * 200
		local ray = player:raycast("ray", from, to, "slot_mask", managers.slot:get_mask("trip_mine_placeables"), "ignore_unit", {})
		if ray then
			local duration_multiplier = managers.player:upgrade_value("ecm_jammer", "duration_multiplier", 1) * managers.player:upgrade_value("ecm_jammer", "duration_multiplier_2", 1)
			local unit = ECMJammerBase.spawn(ray.position, Rotation(ray.normal, math.UP), duration_multiplier, player)
			if unit then
				unit:base():set_active(true)
			end
		end
	end
end
