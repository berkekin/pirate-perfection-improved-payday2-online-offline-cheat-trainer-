-- Spawn a sentry gun where you look (SuperBLT keybind, host only) - PPR Improved Edition
if inGame() and isPlaying() and not inChat() then
	local tr = Localization.translate
	local player = managers.player:player_unit()
	if not isHost() then
		show_hint(tr.kb_host_only)
	elseif alive(player) then
		local M_player = managers.player
		local ammo_multiplier = M_player:upgrade_value("sentry_gun", "extra_ammo_multiplier", 1)
		local armor_multiplier = M_player:upgrade_value("sentry_gun", "armor_multiplier", 1)
		local damage_multiplier = M_player:upgrade_value("sentry_gun", "damage_multiplier", 1)
		local from = player:movement():m_head_pos()
		local to = from + player:movement():m_head_rot():y() * 200
		local ray = player:raycast("ray", from, to, "slot_mask", managers.slot:get_mask("trip_mine_placeables"), "ignore_unit", {})
		if ray then
			local rot = player:movement():m_head_rot()
			local shield = M_player:has_category_upgrade("sentry_gun", "shield")
			local sentry_gun_unit = SentryGunBase.spawn(player, ray.position, Rotation(rot:yaw(), 0, 0), ammo_multiplier, armor_multiplier, damage_multiplier)
			if sentry_gun_unit then
				local session = managers.network:session()
				session:send_to_peers_synched("from_server_sentry_gun_place_result", session:local_peer():id(), nil, sentry_gun_unit, sentry_gun_unit:movement()._rot_speed_mul, sentry_gun_unit:weapon()._setup.spread_mul, shield)
			end
		end
	end
end
