-- Spawn a trip mine where you look (SuperBLT keybind, host only) - PPR Improved Edition
if inGame() and isPlaying() and not inChat() then
	local tr = Localization.translate
	local player = managers.player:player_unit()
	if not isHost() then
		show_hint(tr.kb_host_only)
	elseif alive(player) then
		local from = player:movement():m_head_pos()
		local to = from + player:movement():m_head_rot():y() * 200
		local ray = player:raycast("ray", from, to, "slot_mask", managers.slot:get_mask("trip_mine_placeables"), "ignore_unit", {})
		if ray then
			local sensor_upgrade = managers.player:has_category_upgrade("trip_mine", "sensor_toggle")
			local unit = TripMineBase.spawn(ray.position, Rotation(ray.normal, math.UP), sensor_upgrade)
			if unit then
				unit:base():set_active(true, player)
			end
		end
	end
end
