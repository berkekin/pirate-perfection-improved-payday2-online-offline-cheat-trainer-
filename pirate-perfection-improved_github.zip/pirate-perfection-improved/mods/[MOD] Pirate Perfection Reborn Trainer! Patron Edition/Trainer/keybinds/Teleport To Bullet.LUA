-- Teleport to the position of your last bullet (SuperBLT keybind) - PPR Improved Edition
if inGame() and isPlaying() and not inChat() and not InOverlay() then
	local tr = Localization.translate
	if _lastBullet then
		managers.player:warp_to(_lastBullet, managers.player:player_unit():camera():rotation(), 1) --keeps your view direction
		show_mid_text(tr.kb_teleport_bullet, tr.kb_teleport_title, 0.25)
		beep()
	else
		show_hint(tr.kb_teleport_no_bullet)
	end
	if not _bulletCollision then
		_bulletCollision = InstantBulletBase.on_collision
		function InstantBulletBase:on_collision( col_ray, weapon_unit, user_unit, damage, blank, ... )
			if user_unit == managers.player:player_unit() and col_ray then
				_lastBullet = col_ray.hit_position
			end
			return _bulletCollision(self, col_ray, weapon_unit, user_unit, damage, blank, ...)
		end
	end
end
