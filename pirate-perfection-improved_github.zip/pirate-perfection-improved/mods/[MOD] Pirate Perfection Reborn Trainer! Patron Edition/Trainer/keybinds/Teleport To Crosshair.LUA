-- Teleport to crosshair (SuperBLT keybind) - PPR Improved Edition
if inGame() and isPlaying() and not inChat() and not InOverlay() then
	local ray = get_ray(ppr_config.TeleportPenetrate)
	if ray then
		managers.player:warp_to(ray.hit_position, managers.player:player_unit():camera():rotation(), 1) --keeps your view direction
		local tr = Localization.translate
		show_mid_text(tr.kb_teleport_crosshair, tr.kb_teleport_title, 0.25)
		beep()
	end
end
