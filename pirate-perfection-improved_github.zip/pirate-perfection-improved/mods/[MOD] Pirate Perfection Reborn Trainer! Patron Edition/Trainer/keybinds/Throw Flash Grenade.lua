-- Throw your equipped grenade without using one (SuperBLT keybind, host only) - PPR Improved Edition v3.2
-- The old version spawned a police flashbang (it only blinds players, i.e. you and
-- your crew) and redefined the game's QuickFlashGrenade class with an outdated copy,
-- which broke police flashbangs until the game restarted. Now it throws the grenade
-- you have equipped through the game's own code (synced, normal effects).
if inGame() and isPlaying() and not inChat() then
	local tr = Localization.translate
	local player = managers.player:player_unit()
	if not isHost() then
		show_hint(tr.kb_host_only)
	elseif alive(player) and player:equipment() and player:equipment().throw_projectile then
		player:equipment():throw_projectile()
	end
end
