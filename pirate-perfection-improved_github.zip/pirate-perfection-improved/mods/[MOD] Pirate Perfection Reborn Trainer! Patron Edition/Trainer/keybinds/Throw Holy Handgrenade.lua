-- HOLY HANDGRENADE v3 - throws three of your equipped grenades at once - PPR Improved Edition v3.2
-- The old version permanently redefined FragGrenade:init and PlayerEquipment:throw_grenade
-- (every later grenade throw changed, and as host it crashed because the game now
-- expects a grenade name instead of a number). Now it only throws, through the game's code.
if inGame() and isPlaying() and not inChat() then
	local player = managers.player:player_unit()
	local session = managers.network:session()
	local grenade = managers.blackmarket:equipped_grenade()
	local tweak = grenade and tweak_data.blackmarket.projectiles[grenade]
	if alive(player) and session and tweak and tweak.unit then
		local movement = player:movement()
		local dir = movement:m_head_rot():y()
		local pos = movement:m_head_pos() + dir * 50
		local index = tweak_data.blackmarket:get_index_from_projectile_id(grenade)
		local local_peer_id = session:local_peer():id()
		for i = 1, 3 do
			local spread = Vector3(math.rand(-0.06, 0.06), math.rand(-0.06, 0.06), 0)
			local throw_dir = (dir + spread):normalized()
			if Network:is_client() and not tweak.client_authoritative then
				session:send_to_host("request_throw_projectile", index, pos, throw_dir)
			else
				ProjectileBase.throw_projectile(grenade, pos, throw_dir, local_peer_id)
			end
		end
	end
end
