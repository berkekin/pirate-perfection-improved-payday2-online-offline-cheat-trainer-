-- Throw a smoke grenade where you look (SuperBLT keybind, host only) - PPR Improved Edition v3.2
-- The old version redefined the game's QuickSmokeGrenade class with a copy from an
-- old game version, which could break every smoke grenade until the game restarted.
-- Now it uses the game's own synced smoke grenade (everyone in the lobby sees it).
if inGame() and isPlaying() and not inChat() then
	local tr = Localization.translate
	local player = managers.player:player_unit()
	local state = managers.groupai and managers.groupai:state()
	if not isHost() then
		show_hint(tr.kb_host_only)
	elseif alive(player) and state and state.detonate_smoke_grenade then
		local from = player:movement():m_head_pos()
		local to = from + player:movement():m_head_rot():y() * 3000
		local ray = World:raycast("ray", from, to, "slot_mask", managers.slot:get_mask("bullet_impact_targets"), "ignore_unit", { player })
		local pos = ray and ray.position or to
		local duration = tweak_data.group_ai and tweak_data.group_ai.smoke_grenade_lifetime or 15
		state:detonate_smoke_grenade(pos + math.UP * 10, from, duration, false)
	end
end
