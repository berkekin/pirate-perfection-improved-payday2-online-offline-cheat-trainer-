--[[	PPR Improved Edition - Key bindings / Tuş atamaları

	EN: Edit the keys below (left side) to your liking. Save the file and restart the heist/game.
	TR: Soldaki tuşları istediğin gibi değiştirebilirsin. Dosyayı kaydet, oyunu/soygunu yeniden başlat.

	Possible keys / Kullanılabilir tuşlar:
		Keyboard: a-z (lowercase), 0-9, left shift, right shift, left ctrl, right ctrl, space, f1-f12,
		          num 0-9, num +, num -, num ., num *, num enter, num lock, num /,
		          insert, delete, home, end, page up, page down
		Mouse:    left_button, right_button, middle_button, x_button_1 ... x_button_5, wheel_up, wheel_down

	Entry fields / Alanlar:
		handled_callback = 'path'	-- script that returns a function (menus use this)
		script = 'path'				-- script executed on every key press
		ig_chat = true/false		-- true: also works while typing in chat. Keep it FALSE for letters,
									--       numbers, Delete/End/Home/Insert/Page keys, otherwise typing
									--       in chat triggers cheats (bug of the old version).
		no_stuck = true/false		-- true: holding the key does not repeat it

	Every menu is also reachable from the F5 hub menu (Ana Menü).
]]

--Return format: key table
return {
	-- Work in main menu & in game / Ana menüde ve oyunda çalışır
	['f1']				= { handled_callback	= 'Trainer/menu/help.lua',							ig_chat = true,		no_stuck = true		},	-- Help / Yardım
	['f2']				= { handled_callback	= 'Trainer/menu/config_menu.lua',					ig_chat = true,		no_stuck = true		},	-- Configuration / Ayarlar
	['f3']				= { handled_callback	= 'Trainer/menu/main_menu-charmenu.lua',			ig_chat = true,		no_stuck = true		},	-- Main menu / Character menu
	['f4']				= { handled_callback	= 'Trainer/menu/jobmenu-stealthmenu.lua',			ig_chat = true,		no_stuck = true		},	-- Job menu / Stealth menu
	['f5']				= { handled_callback	= 'Trainer/menu/hub.lua',							ig_chat = true,		no_stuck = true		},	-- Hub (all menus) / Ana Menü
	['page up']			= { handled_callback	= 'Trainer/menu/ingame/tools.lua',					ig_chat = false,	no_stuck = true		},	-- Tools / Araçlar
	['page down']		= { handled_callback	= 'Trainer/keybinds/music_menu.lua',				ig_chat = false,	no_stuck = true		},	-- Music / Müzik
	['home']			= { handled_callback	= 'Trainer/addons/normalizer.lua',					ig_chat = false,	no_stuck = true		},	-- Normalizer / Normalleştirici
	['delete']			= { script				= 'Trainer/user_script.lua',						ig_chat = false,	no_stuck = false	},	-- Your own script / Kendi betiğin

	-- Work only in game / Sadece oyun içinde
	['f6']				= { handled_callback	= 'Trainer/menu/ingame/interactions.lua',			ig_chat = true,		no_stuck = true		},	-- Interactions / Etkileşim
	['f7']				= { handled_callback	= 'Trainer/menu/ingame/inventory_menu.lua',			ig_chat = true,		no_stuck = true		},	-- Inventory / Envanter
	['f8']				= { handled_callback	= 'Trainer/menu/ingame/equipment_menu.lua',			ig_chat = true,		no_stuck = true		},	-- Equipment / Ekipman
	['f10']				= { handled_callback	= 'Trainer/menu/ingame/missionmenu.lua',			ig_chat = true,		no_stuck = true		},	-- Mission / Görev
	['f11']				= { handled_callback	= 'Trainer/menu/ingame/mod_menu.lua',				ig_chat = true,		no_stuck = true		},	-- Mods / Modlar
	['f12']				= { handled_callback	= 'Trainer/menu/ingame/spawn_menu.lua',				ig_chat = true,		no_stuck = true		},	-- Spawn / Oluşturma
	['insert']			= { script				= 'Trainer/addons/carrystacker.lua',				ig_chat = false,	no_stuck = false	},	-- Carry stacker / Çanta yığıcı
	['end']				= { handled_callback	= 'Trainer/keybinds/instant_win.lua',				ig_chat = false,	no_stuck = true		},	-- Instant win (host) / Anında kazan (kurucu)
	['x']				= { handled_callback	= 'Trainer/keybinds/xray.lua',						ig_chat = false,	no_stuck = true		},	-- X-Ray
	['z']				= { handled_callback	= 'Trainer/keybinds/replenish.lua',					ig_chat = false,	no_stuck = false	},	-- Replenish / Yenile
	['5']				= { handled_callback	= 'Trainer/equipment_stuff/place_equipment.lua',	ig_chat = false,	no_stuck = true		},	-- Equipment placing / Ekipman yerleştirme
	['x_button_1']		= { handled_callback	= 'Trainer/keybinds/slowmotion.lua',				ig_chat = false,	no_stuck = true		},	-- Slow motion / Ağır çekim
	['middle_button']	= { handled_callback	= 'Trainer/keybinds/teleport.lua',					ig_chat = false,	no_stuck = false	},	-- Teleport / Işınlanma
--	['c']				= { handled_callback	= 'Trainer/addons/spawngagepackage.lua',			ig_chat = false,	no_stuck = true		},	-- (crashes on Green Bridge)
}
