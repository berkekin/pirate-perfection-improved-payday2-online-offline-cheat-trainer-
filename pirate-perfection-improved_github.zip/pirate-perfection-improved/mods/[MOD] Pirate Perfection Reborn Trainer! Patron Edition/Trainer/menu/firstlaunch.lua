--Purpose: First launch greeting message (shown once per installed version).
--PPR Improved Edition: lets the player choose English / Türkçe right away.

local ppr_require = ppr_require
local backuper = backuper
local io_open = ppr_io.open
local L = Localization
local tr = L.translate

local CHECK_FILE = 'Trainer/configs/checks/First Launch v3.Check'

local main
main = function()
	ppr_require 'Trainer/tools/new_menu/menu'

	local f = io_open(CHECK_FILE, 'rb')
	if f then
		f:close()
		return
	end

	local function pick( lang )
		L:change_language(lang, true)
		main() --show the greeting again in the chosen language
	end

	local function done()
		local w = io_open(CHECK_FILE, 'w')
		if w then
			w:write('1')
			w:close()
		end
	end

	local data = {
		{ text = "Türkçe", callback = pick, data = 'turkish', switch_back = false },
		{ text = "English", callback = pick, data = 'english', switch_back = false },
		{},
		{ text = tr.welcome_ok, callback = done },
	}

	local M = Menu:open({ title = tr.welcome_title, description = tr.welcome_message, button_list = data, w_mul = 2.0 })
	if M and M.close_clbks then
		M.close_clbks.first_launch_done = done --closing the window with Esc also counts
	end
end

backuper:add_clbk('MenuMainState.at_enter', main, 'first_time', 2)
