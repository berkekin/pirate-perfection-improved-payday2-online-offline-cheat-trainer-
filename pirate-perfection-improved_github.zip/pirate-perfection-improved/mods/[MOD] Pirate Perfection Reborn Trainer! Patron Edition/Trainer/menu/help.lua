--Purpose: F1 help menu. PPR Improved Edition: the key list is generated from keyconfig.lua
--(so it is always correct) and every text is translated (English / Türkçe).

local ppr_require = ppr_require
ppr_require 'Trainer/tools/new_menu/menu'
local keys = ppr_require 'Trainer/tools/keynames'

local L = Localization
local tr = L.translate
local ipairs = ipairs
local type = type
local tab_insert = table.insert
local tab_concat = table.concat

local open_menu
do
	local Menu = Menu
	local open = Menu.open
	open_menu = function( ... )
		return open(Menu, ...)
	end
end

local main, keybinds, cheatertag, credits, whatsnew

--Order of the key list: { script file name, text id }
local KEY_LIST_BOTH = {
	{ 'help',					'hub_help' },
	{ 'config_menu',			'hub_config' },
	{ 'main_menu-charmenu',		'help_key_f3' },
	{ 'jobmenu-stealthmenu',	'help_key_f4' },
	{ 'hub',					'hub_title' },
	{ 'tools',					'tools_menu' },
	{ 'music_menu',				'music_menu_title' },
	{ 'normalizer',				'Normalizer' },
	{ 'user_script',			'help_user_script' },
}
local KEY_LIST_GAME = {
	{ 'interactions',			'intm_title' },
	{ 'inventory_menu',			'inventory_menu' },
	{ 'equipment_menu',			'equip_menu_title' },
	{ 'missionmenu',			'mission_menu_title' },
	{ 'mod_menu',				'mod_menu' },
	{ 'spawn_menu',				'spawn_menu' },
	{ 'carrystacker',			'help_carrystacker' },
	{ 'instant_win',			'help_instant_win' },
	{ 'xray',					'base_xray_sub' },
	{ 'replenish',				'help_replenish' },
	{ 'place_equipment',		'help_place_equipment' },
	{ 'slowmotion',				'base_slow_sub' },
	{ 'teleport',				'help_teleport' },
}

local function key_lines( list )
	local lines = {}
	for _, e in ipairs(list) do
		local key = keys.display(keys.key_for(e[1]))
		if key then
			tab_insert(lines, key .. "   =   " .. tr[e[2]])
		end
	end
	if #lines == 0 then
		tab_insert(lines, tr.help_nokey)
	end
	return tab_concat(lines, "\n")
end

local function nav( current )
	return {
		{ text = tr.help_keybinds, callback = keybinds },
		{ text = tr.help_whatsnew, callback = whatsnew },
		{ text = tr.help_cheatertag, callback = cheatertag },
		{ text = tr.help_credits, callback = credits },
		{},
		{ text = tr.hub_title, callback = function()
				local hub = keys.callback_for('hub') or ppr_require('Trainer/menu/hub')
				if type(hub) == 'function' then hub() end
			end, menu = true },
		{ text = tr.hub_language, callback = function() ppr_require('Trainer/menu/language_menu')() end, menu = true },
	}
end

main = function()
	open_menu({
		title = tr.help_title,
		description = tr.help_desc .. "\n\n" .. L:text('help_version', ppr_config.const_version or '', ppr_config.const_edition or '', L:language_name()),
		button_list = nav('main'),
		w_mul = 2.0,
	})
end

keybinds = function()
	local desc = "-- " .. tr.help_keys_both .. " --\n" .. key_lines(KEY_LIST_BOTH)
		.. "\n\n-- " .. tr.help_keys_game .. " --\n" .. key_lines(KEY_LIST_GAME)
		.. "\n\n" .. tr.help_keys_note
	open_menu({ title = tr.help_keybinds, description = desc, button_list = nav('keys'), back = main, w_mul = 1.8, h_mul = 1.5 })
end

cheatertag = function()
	open_menu({ title = tr.help_cheatertag, description = tr.help_cheatertag_desc, button_list = nav('tag'), back = main, w_mul = 1.6, h_mul = 1.5 })
end

whatsnew = function()
	open_menu({ title = tr.help_whatsnew, description = tr.help_whatsnew_desc, button_list = nav('new'), back = main, w_mul = 1.6, h_mul = 1.5 })
end

credits = function()
	open_menu({ title = tr.help_credits, description = tr.help_credits_desc, button_list = nav('credits'), back = main, w_mul = 1.8, h_mul = 1.5 })
end

return main
