--Purpose: PPR hub - every trainer menu in one place (default key: F5).
--PPR Improved Edition. F5 used to open the "Spoof Name" / "Troll" menus (removed in this edition).

local ppr_require = ppr_require
local ppr_dofile = ppr_dofile
ppr_require 'Trainer/tools/new_menu/menu'
local keys = ppr_require 'Trainer/tools/keynames'

local Menu = Menu
local Menu_open = Menu.open
local L = Localization
local tr = L.translate
local ipairs = ipairs
local type = type
local pcall = pcall
local rawget = rawget

--Forward declarations (used by ENTRIES below)
local unlock, panic

--id: script file name used in keyconfig.lua (to show/find its key); path: module that returns the menu function
local ENTRIES = {
	{ id = 'help',					path = 'Trainer/menu/help',						label = 'hub_help' },
	{ id = 'config_menu',			path = 'Trainer/menu/config_menu',				label = 'hub_config' },
	{ id = 'base_menu',				dofile = 'Trainer/menu/pre-game/base_menu',		label = 'base_menu' },
	{ id = 'language_menu',			path = 'Trainer/menu/language_menu',			label = 'hub_language' },
	{ id = 'keybinds_menu',			path = 'Trainer/menu/keybinds_menu',			label = 'kbm_title' },
	{ id = 'profiles_menu',			path = 'Trainer/menu/profiles_menu',			label = 'prof_title' },
	{},
	{ id = 'main_menu-charmenu',	path = 'Trainer/menu/main_menu-charmenu',		label = 'main_menu_title',	label_game = 'char_menu' },
	{ id = 'jobmenu-stealthmenu',	path = 'Trainer/menu/jobmenu-stealthmenu',		label = 'job_menu_title',	label_game = 'stealth_menu' },
	{ id = 'tools',					path = 'Trainer/menu/ingame/tools',				label = 'tools_menu' },
	{ id = 'music_menu',			path = 'Trainer/keybinds/music_menu',			label = 'music_menu_title' },
	{ id = 'normalizer',			path = 'Trainer/addons/normalizer',				label = 'Normalizer' },
	{ id = 'unlock_weapon_mods',	action = function() unlock('weapon_mods', 'hub_unlocked_weapon_mods') end,	label = 'hub_unlock_weapon_mods',	lobby = true },
	{ id = 'unlock_all_items',		action = function() unlock('all', 'hub_unlocked_all') end,			label = 'hub_unlock_all',			lobby = true },
	{ ingame_separator = true },
	{ id = 'quick_cheats',			quick = true,									label = 'hub_quick',			ingame = true },
	{ id = 'panic',					action = function() panic() end,				label = 'hub_panic',			ingame = true },
	{ id = 'teleport_menu',			path = 'Trainer/menu/ingame/teleport_menu',		label = 'tp_title',				ingame = true },
	{ id = 'interactions',			path = 'Trainer/menu/ingame/interactions',		label = 'intm_title',			ingame = true },
	{ id = 'inventory_menu',		path = 'Trainer/menu/ingame/inventory_menu',	label = 'inventory_menu',		ingame = true },
	{ id = 'equipment_menu',		path = 'Trainer/menu/ingame/equipment_menu',	label = 'equip_menu_title',		ingame = true },
	{ id = 'weaponlistmenu',		path = 'Trainer/menu/ingame/weaponlistmenu',	label = 'weapon_menu_title',	ingame = true },
	{ id = 'missionmenu',			path = 'Trainer/menu/ingame/missionmenu',		label = 'mission_menu_title',	ingame = true },
	{ id = 'mod_menu',				path = 'Trainer/menu/ingame/mod_menu',			label = 'mod_menu',				ingame = true },
	{ id = 'spawn_menu',			path = 'Trainer/menu/ingame/spawn_menu',		label = 'spawn_menu',			ingame = true },
}

--Most used cheats in one list (v3.2: shared with key bindings and cheat profiles).
local quick = ppr_require 'Trainer/tools/quickcheats'

local main
local function quick_menu()
	local data = {}
	for _, q in ipairs(quick.LIST) do
		if q then
			data[#data + 1] = { text = tr[q.label], plugin = q.id, plugin_path = q.path, host_only = q.host_only, switch_back = true }
		else
			data[#data + 1] = {}
		end
	end
	data[#data + 1] = {}
	local xray = keys.callback_for('xray')
	if xray then
		data[#data + 1] = { text = keys.prefix('xray') .. tr.base_xray_sub, callback = xray, switch_back = true }
	end
	local refill = keys.callback_for('replenish')
	if refill then
		data[#data + 1] = { text = keys.prefix('replenish') .. tr.help_replenish, callback = refill, switch_back = true }
	end
	Menu_open(Menu, { title = tr.hub_quick, description = tr.hub_quick_desc, button_list = data, plugin_path = 'Trainer/addons/charmenu/', back = main })
end

--Turn every cheat off (uses the Normalizer)
panic = function()
	local f = rawget(_G, 'ppr_normalize')
	if type(f) ~= 'function' then
		--Normalizer not loaded yet (key unbound): load it, it registers ppr_normalize
		ppr_require('Trainer/addons/normalizer')
		f = rawget(_G, 'ppr_normalize')
	end
	if type(f) == 'function' then
		local ok = pcall(f)
		pcall(show_hint, ok and tr.hub_panic_done or tr.hub_unavailable)
	end
end

local function toggle_active_hud()
	ppr_config.HUD_ActiveCheats = (ppr_config.HUD_ActiveCheats == false)
	pcall(ppr_config) --save
end

local function done( text )
	Menu_open(Menu, { title = tr.hub_done_title, description = text, button_list = {}, back = main })
end

--Lobby only: unlock every (non-DLC) weapon mod / every item in one click
unlock = function( item_type, text_id )
	ppr_require('Trainer/addons/main_menu/unlock_items')
	local f = rawget(_G, 'unlock_items')
	if type(f) == 'function' then
		local ok, err = pcall(f, item_type)
		if not ok then
			m_log_error('{hub.lua}', 'unlock_items failed', err)
		end
		done(ok and tr[text_id] or tr.hub_unavailable)
	end
end

local function open_entry( entry )
	if entry.quick then
		quick_menu()
		return
	end
	if entry.action then
		entry.action()
		return
	end
	if entry.dofile then
		ppr_dofile(entry.dofile)
		return
	end
	local f = keys.callback_for(entry.id)
	if not f and entry.path then
		f = ppr_require(entry.path)
	end
	if type(f) == 'function' then
		f()
	else
		show_hint(tr.hub_unavailable)
	end
end

main = function()
	local in_game = GameSetup and true or false
	local data = {}
	for _, entry in ipairs(ENTRIES) do
		if entry.ingame_separator then
			if in_game then
				data[#data + 1] = {}
			end
		elseif not entry.id then
			data[#data + 1] = {}
		elseif (in_game or not entry.ingame) and not (in_game and entry.lobby) then
			local label = tr[(in_game and entry.label_game) or entry.label]
			data[#data + 1] = {
				text = keys.prefix(entry.id) .. label,
				callback = open_entry,
				data = { entry },
				menu = not entry.action or nil,
			}
		end
	end
	if in_game then
		data[#data + 1] = {}
		data[#data + 1] = { text = tr.hub_active_hud, type = "toggle", toggle = function() return ppr_config.HUD_ActiveCheats ~= false end, callback = toggle_active_hud, switch_back = true }
	end

	local desc = L:text('hub_desc', ppr_config.const_version or '', L:language_name())
	if not in_game then
		desc = desc .. "\n" .. tr.hub_ingame_hint
	else
		local active = rawget(_G, 'PPR_ActiveCheats')
		if type(active) == 'function' then
			local ok, list = pcall(active)
			if ok and type(list) == 'table' then
				desc = desc .. "\n" .. L:text('hub_active_count', #list)
			end
		end
	end
	local failed = rawget(_G, 'PPR_FAILED_FEATURES')
	if type(failed) == 'table' and #failed > 0 then
		desc = desc .. "\n" .. L:text('hub_failed_features', #failed, table.concat(failed, ", "))
	end
	Menu_open(Menu, { title = tr.hub_title, description = desc, button_list = data })
end

return main
