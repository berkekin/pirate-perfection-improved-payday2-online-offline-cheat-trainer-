--Purpose: save positions on every map and teleport back to them (Hub > Teleport points).
--PPR Improved Edition v3.2. Saved per map in Trainer/configs/teleports.lua.

ppr_require 'Trainer/tools/new_menu/menu'
local datastore = ppr_require 'Trainer/tools/datastore'

local Menu = Menu
local Menu_open = Menu.open
local L = Localization
local tr = L.translate
local ipairs = ipairs
local pairs = pairs
local pcall = pcall
local type = type
local tostring = tostring
local format = string.format
local tab_remove = table.remove

local FILE = 'Trainer/configs/teleports.lua'
local MAX_POINTS = 30

local M = rawget(_G, 'PPR_Teleports')
if type(M) ~= 'table' then
	M = {}
	rawset(_G, 'PPR_Teleports', M)
end
M.history = M.history or {}

local function level_id()
	local id = managers.job and managers.job.current_level_id and managers.job:current_level_id()
	return id or (Global.level_data and Global.level_data.level_id) or 'unknown'
end

local function level_name()
	local id = level_id()
	local lvl = tweak_data.levels and tweak_data.levels[id]
	local name = lvl and lvl.name_id and managers.localization:text(lvl.name_id)
	return name or tostring(id)
end

local function load_all()
	local data = datastore.load(FILE)
	return type(data) == 'table' and data or {}
end

local function points_here(all)
	local id = level_id()
	all[id] = type(all[id]) == 'table' and all[id] or {}
	return all[id], id
end

local function player()
	local p = managers.player and managers.player:player_unit()
	return alive(p) and p or nil
end

local function current_spot(p)
	local pos = p:position()
	local rot = p:camera() and p:camera():rotation() or p:rotation()
	return { x = pos.x, y = pos.y, z = pos.z, yaw = rot:yaw(), pitch = rot:pitch() }
end

local function warp(spot, keep_history)
	local p = player()
	if not p or type(spot) ~= 'table' then
		return false
	end
	if keep_history ~= false then
		M.history[#M.history + 1] = current_spot(p)
		if #M.history > 10 then
			tab_remove(M.history, 1)
		end
	end
	local pos = Vector3(spot.x or 0, spot.y or 0, spot.z or 0)
	local rot = Rotation(spot.yaw or 0, spot.pitch or 0, 0)
	managers.player:warp_to(pos, rot)
	return true
end

--Save where you stand now (also usable from a key, see Hub > Key bindings)
function M.save_here()
	local p = player()
	if not inGame() or not p then
		pcall(show_hint, tr.tp_need_game)
		return
	end
	local all = load_all()
	local list = points_here(all)
	if #list >= MAX_POINTS then
		pcall(show_hint, L:text('tp_full', MAX_POINTS))
		return
	end
	local spot = current_spot(p)
	spot.name = L:text('tp_point_name', #list + 1)
	list[#list + 1] = spot
	datastore.save(FILE, all)
	pcall(show_hint, L:text('tp_saved', spot.name))
	return spot
end

--Go back to where you were before the last teleport
function M.undo()
	local spot = tab_remove(M.history)
	if not spot then
		pcall(show_hint, tr.tp_no_history)
		return
	end
	warp(spot, false)
	pcall(show_hint, tr.tp_back_done)
end

--Teleport to saved point number n on this map
function M.go(n)
	local list = points_here(load_all())
	local spot = list[n]
	if spot and warp(spot) then
		pcall(show_hint, L:text('tp_went', spot.name or tostring(n)))
	end
end

local main, point_menu

local function warp_to_unit(unit)
	if not alive(unit) then
		return false
	end
	local behind = unit:rotation():y() * -80
	local pos = unit:position() + behind
	local rot = unit:rotation()
	return warp({ x = pos.x, y = pos.y, z = pos.z + 5, yaw = rot:yaw(), pitch = 0 })
end

--Crew members (players and bots) you can teleport to
function M.crew_list()
	local res = {}
	local me = player()
	local session = managers.network and managers.network:session()
	local ok, chars = pcall(function() return managers.criminals:characters() end)
	for _, c in ipairs(ok and chars or {}) do
		local unit = c.taken and c.unit or nil
		if unit and alive(unit) and unit ~= me then
			local name = c.name
			if c.data and c.data.ai then
				local loc_ok, loc = pcall(function() return managers.localization:text('menu_' .. c.name) end)
				name = L:text('tp_bot', loc_ok and loc or tostring(c.name))
			elseif session and c.peer_id then
				local peer = session:peer(c.peer_id)
				name = peer and peer:name() or name
			end
			res[#res + 1] = { name = tostring(name), unit = unit }
		end
	end
	return res
end

--Waypoints on the HUD (objectives and others), nearest first
function M.waypoint_list()
	local res = {}
	local me = player()
	local hud = managers.hud and managers.hud._hud
	if not me or not hud or type(hud.waypoints) ~= 'table' then
		return res
	end
	local my_pos = me:position()
	for id, wp in pairs(hud.waypoints) do
		local pos = wp.position or (wp.init_data and wp.init_data.position)
		if pos and pos.x then
			res[#res + 1] = { id = id, pos = pos, dist = (pos - my_pos):length() / 100 }
		end
	end
	table.sort(res, function(a, b) return a.dist < b.dist end)
	return res
end

local function crew_menu()
	local data = {}
	for _, c in ipairs(M.crew_list()) do
		data[#data + 1] = { text = c.name, callback = function()
			if warp_to_unit(c.unit) then
				pcall(show_hint, L:text('tp_went', c.name))
			end
		end }
	end
	if #data == 0 then
		data[1] = { text = tr.tp_nobody, callback = function() main() end }
	end
	Menu_open(Menu, { title = tr.tp_crew, description = tr.tp_crew_desc, button_list = data, back = main })
end

local function waypoint_menu()
	local data = {}
	for i, wp in ipairs(M.waypoint_list()) do
		if i > 15 then
			break
		end
		local label = L:text('tp_waypoint_line', i, wp.dist)
		data[#data + 1] = { text = label, callback = function()
			if warp({ x = wp.pos.x, y = wp.pos.y, z = wp.pos.z + 5 }) then
				pcall(show_hint, L:text('tp_went', label))
			end
		end }
	end
	if #data == 0 then
		data[1] = { text = tr.tp_no_waypoints, callback = function() main() end }
	end
	Menu_open(Menu, { title = tr.tp_waypoints, description = tr.tp_waypoints_desc, button_list = data, back = main })
end

point_menu = function(n)
	local all = load_all()
	local list = points_here(all)
	local spot = list[n]
	if not spot then
		return main()
	end
	local data = {
		{ text = tr.tp_go, callback = function() M.go(n) end },
		{ text = tr.tp_overwrite, callback = function()
			local p = player()
			if p then
				local fresh = current_spot(p)
				fresh.name = spot.name
				list[n] = fresh
				datastore.save(FILE, all)
				pcall(show_hint, L:text('tp_saved', fresh.name))
			end
			point_menu(n)
		end },
		{ text = tr.tp_move_up, callback = function()
			if n > 1 then
				list[n], list[n - 1] = list[n - 1], list[n]
				datastore.save(FILE, all)
				return point_menu(n - 1)
			end
			point_menu(n)
		end },
		{ text = tr.tp_delete, callback = function()
			tab_remove(list, n)
			datastore.save(FILE, all)
			pcall(show_hint, L:text('tp_deleted', spot.name or tostring(n)))
			main()
		end },
	}
	local desc = format('%s\nX %.0f   Y %.0f   Z %.0f', level_name(), spot.x or 0, spot.y or 0, spot.z or 0)
	Menu_open(Menu, { title = spot.name or tostring(n), description = desc, button_list = data, back = main })
end

main = function()
	if not inGame() or not player() then
		pcall(show_hint, tr.tp_need_game)
		return
	end
	local list = points_here(load_all())
	local data = {
		{ text = tr.tp_save_here, callback = function() M.save_here() main() end },
		{ text = tr.tp_undo, callback = function() M.undo() end },
		{ text = tr.tp_crew, callback = crew_menu, menu = true },
		{ text = tr.tp_waypoints, callback = waypoint_menu, menu = true },
		{},
	}
	for i, spot in ipairs(list) do
		data[#data + 1] = { text = format('%d. %s', i, spot.name or '?'), callback = function() M.go(i) end, alt_callback = point_menu, data = i }
	end
	if #list == 0 then
		data[#data + 1] = { text = tr.tp_empty, callback = function() main() end }
	end
	local hub = function()
		local ok, f = pcall(ppr_require, 'Trainer/menu/hub')
		if ok and type(f) == 'function' then f() end
	end
	local desc = L:text('tp_desc', level_name(), #list, MAX_POINTS)
	Menu_open(Menu, { title = tr.tp_title, description = desc, button_list = data, back = hub })
end

M.menu = main
return main
