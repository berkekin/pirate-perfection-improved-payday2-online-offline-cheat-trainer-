--Purpose: change trainer keys in game and bind quick cheats to keys (Hub > Key bindings).
--PPR Improved Edition v3.2. Changes are saved in Trainer/configs/user_keybinds.lua.

ppr_require 'Trainer/tools/new_menu/menu'
local ub = ppr_require 'Trainer/tools/userbinds'
local quick = ppr_require 'Trainer/tools/quickcheats'
local keys = ppr_require 'Trainer/tools/keynames'

local Menu = Menu
local Menu_open = Menu.open
local L = Localization
local tr = L.translate
local ipairs = ipairs
local pcall = pcall
local format = string.format

--script id -> text id (same names as the F1 help)
local LABELS = {
	help = 'hub_help',							config_menu = 'hub_config',
	['main_menu-charmenu'] = 'help_key_f3',		['jobmenu-stealthmenu'] = 'help_key_f4',
	hub = 'hub_title',							tools = 'tools_menu',
	music_menu = 'music_menu_title',			normalizer = 'Normalizer',
	user_script = 'help_user_script',			interactions = 'intm_title',
	inventory_menu = 'inventory_menu',			equipment_menu = 'equip_menu_title',
	missionmenu = 'mission_menu_title',			mod_menu = 'mod_menu',
	spawn_menu = 'spawn_menu',					carrystacker = 'help_carrystacker',
	instant_win = 'help_instant_win',			xray = 'base_xray_sub',
	replenish = 'help_replenish',				place_equipment = 'help_place_equipment',
	slowmotion = 'base_slow_sub',				teleport = 'help_teleport',
	weaponlistmenu = 'weapon_menu_title',		lego_menu = 'lego_menu',
	keybinds_menu = 'kbm_title',				profiles_menu = 'prof_title',
	teleport_menu = 'tp_title',				tp_save = 'tp_save_here',
	tp_undo = 'tp_undo',
}

local main, action_menu, quick_menu_for

local function label_of(id)
	local t = LABELS[id]
	return t and tr[t] or id
end

local function key_text(key)
	return key and ('[' .. (keys.display(key) or key) .. ']') or ('[' .. tr.kbm_no_key .. ']')
end

local function line(text, key)
	return text .. '   ' .. key_text(key)
end

local function after_bind(name, key)
	local msg
	if key and key ~= 'none' then
		msg = L:text('kbm_bound', keys.display(key) or key, name)
		local other = ub.last_displaced
		if other then
			local pid = other:match('^quick:(.+)$')
			msg = msg .. '\n' .. L:text('kbm_displaced', pid and quick.label(pid) or label_of(other))
		end
	else
		msg = L:text('kbm_removed', name)
	end
	pcall(show_hint, msg)
end

local function capture(name, on_key, reopen)
	pcall(show_hint, L:text('kbm_press_key', name))
	ub.capture(function(key)
		if key then
			on_key(key)
			after_bind(name, key)
		else
			pcall(show_hint, tr.kbm_cancelled)
		end
		reopen()
	end)
end

action_menu = function(id)
	local name = label_of(id)
	local def = ub.defaults[id]
	local data = {
		{ text = tr.kbm_change, callback = function()
			capture(name, function(key) ub.bind_action(id, key) end, function() action_menu(id) end)
		end },
		{ text = tr.kbm_remove, callback = function()
			ub.bind_action(id, 'none')
			after_bind(name, nil)
			action_menu(id)
		end },
		{ text = L:text('kbm_default', def and (keys.display(def) or def) or tr.kbm_no_key), callback = function()
			ub.reset_action(id)
			after_bind(name, def)
			action_menu(id)
		end },
	}
	Menu_open(Menu, { title = name, description = L:text('kbm_current', key_text(ub.key_of(id))), button_list = data, back = main })
end

quick_menu_for = function(pid)
	local name = quick.label(pid)
	local data = {
		{ text = tr.kbm_change, callback = function()
			capture(name, function(key) ub.bind_quick(pid, key) end, function() quick_menu_for(pid) end)
		end },
		{ text = tr.kbm_remove, callback = function()
			ub.bind_quick(pid, 'none')
			after_bind(name, nil)
			quick_menu_for(pid)
		end },
	}
	Menu_open(Menu, { title = name, description = L:text('kbm_current', key_text(ub.key_of('quick:' .. pid))) .. '\n\n' .. tr.kbm_quick_note, button_list = data, back = main })
end

local function reset_all_menu()
	local data = {
		{ text = tr.kbm_reset_yes, callback = function()
			ub.reset_all()
			pcall(show_hint, tr.kbm_reset_done)
			main()
		end },
		{ text = tr.kbm_reset_no, callback = function() main() end },
	}
	Menu_open(Menu, { title = tr.kbm_reset_all, description = tr.kbm_reset_desc, button_list = data, back = main })
end

main = function()
	local data = {}
	local ids = ub.action_ids()
	table.sort(ids, function(a, b) return label_of(a) < label_of(b) end)
	for _, id in ipairs(ids) do
		data[#data + 1] = { text = line(label_of(id), ub.key_of(id)), callback = action_menu, data = id, menu = true }
	end
	data[#data + 1] = {}
	for _, q in ipairs(quick.LIST) do
		if q then
			data[#data + 1] = { text = line(tr[q.label], ub.key_of('quick:' .. q.id)), callback = quick_menu_for, data = q.id, menu = true }
		end
	end
	data[#data + 1] = {}
	data[#data + 1] = { text = tr.kbm_reset_all, callback = reset_all_menu, menu = true }
	local hub = function()
		local ok, f = pcall(ppr_require, 'Trainer/menu/hub')
		if ok and type(f) == 'function' then f() end
	end
	Menu_open(Menu, { title = tr.kbm_title, description = tr.kbm_desc, button_list = data, back = hub, w_mul = 1.4, h_mul = 1.3 })
end

return main
