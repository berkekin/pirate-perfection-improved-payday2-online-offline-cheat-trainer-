--Purpose: language selection (English / Türkçe) and Turkish character mode.
--PPR Improved Edition. Replaces the old loc_menu.lua which downloaded translations from a dead website.

local ppr_require = ppr_require
ppr_require 'Trainer/tools/new_menu/menu'

local Menu = Menu
local Menu_open = Menu.open
local L = Localization
local tr = L.translate
local ipairs = ipairs
local rawget = rawget
local pcall = pcall

local main_menu, other_menu, charmode_menu

local function mark( selected, text )
	return (selected and "> " or "") .. text
end

local function set_language( id, back_func )
	L:change_language(id, true)
	pcall(show_hint, L:text('lang_changed', L:language_name(id)))
	local reopen = back_func or main_menu
	reopen()
end

local function current_charmode()
	local mode = rawget(ppr_config, 'TurkishCharMode')
	if mode ~= 'full' and mode ~= 'ascii' then
		mode = 'safe'
	end
	return mode
end

local function set_charmode( mode )
	ppr_config.TurkishCharMode = mode
	pcall(ppr_config) --save
	L:reload()
	charmode_menu()
end

charmode_menu = function()
	local cur = current_charmode()
	local data = {
		{ text = mark(cur == 'safe', tr.lang_charmode_safe), callback = set_charmode, data = 'safe' },
		{ text = mark(cur == 'full', tr.lang_charmode_full), callback = set_charmode, data = 'full' },
		{ text = mark(cur == 'ascii', tr.lang_charmode_ascii), callback = set_charmode, data = 'ascii' },
	}
	Menu_open(Menu, { title = tr.lang_charmode, description = tr.lang_charmode_desc, button_list = data, back = main_menu })
end

other_menu = function()
	local cur = L:current()
	local data = {}
	for _, lang in ipairs(L:available_languages()) do
		if not lang.complete then
			data[#data + 1] = { text = mark(lang.id == cur, lang.name), callback = set_language, data = { lang.id, other_menu } }
		end
	end
	if #data == 0 then
		data[1] = { text = tr.lang_none_found }
	end
	Menu_open(Menu, { title = tr.lang_other, description = tr.lang_other_desc, button_list = data, back = main_menu })
end

main_menu = function()
	local cur = L:current()
	local data = {}
	for _, lang in ipairs(L:available_languages()) do
		if lang.complete then
			data[#data + 1] = { text = mark(lang.id == cur, lang.name), callback = set_language, data = { lang.id } }
		end
	end
	data[#data + 1] = {}
	data[#data + 1] = { text = tr.lang_charmode, callback = charmode_menu, menu = true }
	data[#data + 1] = { text = tr.lang_other, callback = other_menu, menu = true }
	Menu_open(Menu, {
		title = tr.lang_menu_title,
		description = L:text('lang_menu_desc', L:language_name(cur)),
		button_list = data,
	})
end

return main_menu
