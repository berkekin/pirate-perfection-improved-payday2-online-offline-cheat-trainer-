--Purpose: cheat profiles - save which quick cheats are on, switch them all with one click,
--and optionally switch a profile on automatically when a heist starts (Hub > Cheat profiles).
--PPR Improved Edition v3.2. Saved in Trainer/configs/cheat_profiles.lua.

ppr_require 'Trainer/tools/new_menu/menu'
local datastore = ppr_require 'Trainer/tools/datastore'
local quick = ppr_require 'Trainer/tools/quickcheats'

local Menu = Menu
local Menu_open = Menu.open
local L = Localization
local tr = L.translate
local ipairs = ipairs
local pairs = pairs
local pcall = pcall
local type = type
local tostring = tostring
local concat = table.concat
local sort = table.sort

local FILE = 'Trainer/configs/cheat_profiles.lua'
local MAX_PROFILES = 12

local P = rawget(_G, 'PPR_Profiles')
if type(P) ~= 'table' then
	P = {}
	rawset(_G, 'PPR_Profiles', P)
end

local function load_data()
	local d = datastore.load(FILE) or {}
	d.profiles = type(d.profiles) == 'table' and d.profiles or {}
	return d
end

local function save_data(d)
	return datastore.save(FILE, d)
end

local function names(d)
	local res = {}
	for name in pairs(d.profiles) do
		res[#res + 1] = name
	end
	sort(res)
	return res
end

local function cheat_names(list)
	local res = {}
	for _, id in ipairs(list or {}) do
		if quick.BY_ID[id] then
			res[#res + 1] = quick.label(id)
		end
	end
	return #res > 0 and concat(res, ', ') or tr.prof_none
end

--exclusive = true: cheats that are not in the profile are switched off
function P.apply(name, exclusive, silent)
	local d = load_data()
	local prof = d.profiles[name]
	if type(prof) ~= 'table' or not inGame() then
		return false
	end
	local want = {}
	for _, id in ipairs(prof.cheats or {}) do
		want[id] = true
	end
	for _, q in ipairs(quick.LIST) do
		if q then
			if want[q.id] then
				quick.set(q.id, true, true)
			elseif exclusive then
				quick.set(q.id, false, true)
			end
		end
	end
	if not silent then
		pcall(show_hint, L:text('prof_applied', name))
	end
	return true
end

--Called when a heist starts (setup/auto_ingame.lua)
function P.apply_auto()
	local d = load_data()
	if d.auto and d.profiles[d.auto] then
		return P.apply(d.auto, false, true)
	end
end

local main, profile_menu

profile_menu = function(name)
	local d = load_data()
	local prof = d.profiles[name]
	if not prof then
		return main()
	end
	local in_game = inGame()
	local data = {}
	if in_game then
		data[#data + 1] = { text = tr.prof_apply, callback = function() P.apply(name, true) end }
		data[#data + 1] = { text = tr.prof_add, callback = function() P.apply(name, false) end }
		data[#data + 1] = { text = tr.prof_overwrite, callback = function()
			prof.cheats = quick.active_ids()
			save_data(d)
			pcall(show_hint, L:text('prof_saved', name))
			profile_menu(name)
		end }
	end
	local is_auto = d.auto == name
	data[#data + 1] = { text = is_auto and tr.prof_auto_off or tr.prof_auto_on, callback = function()
		d.auto = (not is_auto) and name or nil
		save_data(d)
		profile_menu(name)
	end }
	data[#data + 1] = {}
	data[#data + 1] = { text = tr.prof_delete, callback = function()
		d.profiles[name] = nil
		if d.auto == name then
			d.auto = nil
		end
		save_data(d)
		pcall(show_hint, L:text('prof_deleted', name))
		main()
	end }
	local desc = L:text('prof_contains', cheat_names(prof.cheats))
	if is_auto then
		desc = desc .. '\n\n' .. tr.prof_is_auto
	end
	Menu_open(Menu, { title = name, description = desc, button_list = data, back = main })
end

local function new_profile()
	local d = load_data()
	local list = names(d)
	if #list >= MAX_PROFILES then
		pcall(show_hint, L:text('prof_full', MAX_PROFILES))
		return main()
	end
	local active = quick.active_ids()
	if #active == 0 then
		pcall(show_hint, tr.prof_nothing_on)
		return main()
	end
	local n = 1
	local name
	repeat
		name = L:text('prof_default_name', n)
		n = n + 1
	until not d.profiles[name]
	d.profiles[name] = { cheats = active }
	save_data(d)
	pcall(show_hint, L:text('prof_saved', name))
	profile_menu(name)
end

main = function()
	local d = load_data()
	local data = {}
	if inGame() then
		data[#data + 1] = { text = tr.prof_new, callback = new_profile, menu = true }
		data[#data + 1] = {}
	end
	for _, name in ipairs(names(d)) do
		local text = name
		if d.auto == name then
			text = text .. '   [' .. tr.prof_auto_tag .. ']'
		end
		data[#data + 1] = { text = text, callback = profile_menu, data = name, menu = true }
	end
	if #names(d) == 0 then
		data[#data + 1] = { text = tr.prof_empty, callback = function() main() end }
	end
	local hub = function()
		local ok, f = pcall(ppr_require, 'Trainer/menu/hub')
		if ok and type(f) == 'function' then f() end
	end
	Menu_open(Menu, { title = tr.prof_title, description = tr.prof_desc, button_list = data, back = hub })
end

P.menu = main
return main
