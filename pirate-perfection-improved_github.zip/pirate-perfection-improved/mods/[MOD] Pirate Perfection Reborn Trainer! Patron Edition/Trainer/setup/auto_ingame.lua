--Purpose: initiates autostart in game scripts here, depending on configuration.

local raw_ppr_require = ppr_require
--Improved Edition: one broken feature (for example after a game update) must not stop the rest of the
--trainer from loading. Failed features are logged and listed in the F5 hub.
local failed_features = rawget(_G, 'PPR_FAILED_FEATURES') or {}
rawset(_G, 'PPR_FAILED_FEATURES', failed_features)
local function feature_failed( name, err )
	m_log_error('{auto_ingame.lua}', 'Feature failed to load:', tostring(name), tostring(err))
	local short = tostring(name):match("([^/]+)$") or tostring(name)
	for _, v in ipairs(failed_features) do
		if v == short then
			return
		end
	end
	table.insert(failed_features, short)
end
local function ppr_require( path, ... )
	local res = { pcall(raw_ppr_require, path, ...) }
	if res[1] then
		return unpack(res, 2)
	end
	feature_failed(path, res[2])
end
local function try( name, func )
	local ok, err = pcall(func)
	if not ok then
		feature_failed(name, err)
	end
end
local ppr_dofile = ppr_dofile

local is_client = is_client()
local is_server = is_server()

local managers = managers
local M_player = managers.player
local M_blackmarket = managers.blackmarket

local level_id = Global.game_settings.level_id

local in_game = in_game
local is_playing = is_playing

local backuper = backuper
local backup = backuper.backup
local plugins = plugins
local plug_require = plugins.ppr_require

local query_execution_testfunc = query_execution_testfunc

local path = "Trainer/addons/"
local load_plugin = load_plugin( path )

local cfg = ppr_config

ppr_require("Trainer/addons/weap_fix1")

ppr_dofile('Trainer/Setup/auto_config')

--ppr_require depending on ppr_config scripts
if not cfg.DisableBulletFix then
	ppr_require('Trainer/addons/bulletfix')
end

local ControlLevel = cfg.ControlCheats
if ControlLevel and ((is_client and ControlLevel == 1) or ControlLevel >= 2) then --Autostart equipment control
	plug_require(plugins, 'Trainer/equipment_stuff/equipment_control', true)
end

if cfg.NoInvisibleWalls and is_server then -- No invisible walls (Host only)
	query_execution_testfunc(is_playing,{ f = function() ppr_dofile 'Trainer/addons/no_invisible_walls.lua' end })
end

if cfg.RestartProMissions and is_server then -- Restart pro missions (it also includes RestartJobs)
	ppr_require('Trainer/addons/restart_pro_missions.lua')
end

if cfg.RestartJobs and is_server then
	ppr_require('Trainer/addons/restart_jobs')
end

try('AutoSkipIntro', function()
if cfg.AutoSkipIntro and is_server then -- Skip the heist intro automatically (host only)
	ppr_require 'Trainer/addons/skip_intro'
end
end)

try('NoEscapeTimer', function()
if cfg.NoEscapeTimer and is_server then -- No escape timer (Host only) (By Harfatus)
	backup(backuper, 'ElementPointOfNoReturn.on_executed')
	function ElementPointOfNoReturn.on_executed() end
end
end)
if cfg.NoCivilianPenality then
	ppr_require('Trainer/addons/freecivilians')
end

try('DontFreezeRagdolls', function()
if cfg.DontFreezeRagdolls then
	backup(backuper, 'CopActionHurt._freeze_ragdoll')
	function CopActionHurt._freeze_ragdoll()end
end
end)
try('DontDisposeRagdolls', function()
if cfg.DontDisposeRagdolls then
	backup(backuper, 'EnemyManager._upd_corpse_disposal')
	function EnemyManager._upd_corpse_disposal()end
end
end)
if cfg.LaserColorR then
	ppr_require('Trainer/weapon_stuff/lasercolor')
end

if not cfg.DisableInvFix then
	ppr_require('Trainer/addons/invfix')
end


if cfg.ReduceDetectionLevel then
	load_plugin('tools/spoof_detection_lvl')
end

if cfg.far_placements then
	plug_require(plugins, 'Trainer/equipment_stuff/long_placement', true)
end

if is_server and cfg.SecureAll then
	ppr_require('Trainer/addons/secureall')
end

if cfg.HUD then
	ppr_require("Trainer/addons/ppr_text")
end

if cfg.Crosshair then
	ppr_require("Trainer/addons/crosshair")
end

if is_server and (level_id == "chill" or level_id == "chill_combat") then
	ppr_dofile("Trainer/addons/customize_safehouse")
end

--v3.2: cheat profile marked as "automatic" (Hub > Cheat profiles)
try('CheatProfileAuto', function()
	local ok, prof_menu = pcall(ppr_require, 'Trainer/menu/profiles_menu')
	local P = rawget(_G, 'PPR_Profiles')
	if ok and P and P.apply_auto then
		P.apply_auto()
	end
end)

--Requires user scripts

ppr_require('Trainer/custom_game')