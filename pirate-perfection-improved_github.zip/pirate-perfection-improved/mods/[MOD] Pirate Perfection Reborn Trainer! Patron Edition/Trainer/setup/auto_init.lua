--Purpose: initiates autostart scripts here, depending on configuration.
--Note: Scripts here being executed both in game and in pre-game.

--Preloading values from table. You will face more of these preloads in other script files.
--This should increase speed of executing script at all trading off some RAM, because accessing locals & upvalues are much faster, than iterating and comparing with each hash from current table.
local raw_ppr_require = ppr_require
--Improved Edition: one broken feature (for example after a game update) must not stop the rest of the
--trainer from loading. Failed features are logged and listed in the F5 hub.
local failed_features = rawget(_G, 'PPR_FAILED_FEATURES') or {}
rawset(_G, 'PPR_FAILED_FEATURES', failed_features)
local function feature_failed( name, err )
	m_log_error('{auto_init.lua}', 'Feature failed to load:', tostring(name), tostring(err))
	local short = tostring(name):match("([^/]+)$") or tostring(name)
	for _, v in ipairs(failed_features) do
		if v == short then
			return
		end
	end
	table.insert(failed_features, short)
end
local function ppr_require( path, ... )
	local res = { pcall(raw_ppr_require, path, ...) }
	if res[1] then
		return unpack(res, 2)
	end
	feature_failed(path, res[2])
end
local function try( name, func )
	local ok, err = pcall(func)
	if not ok then
		feature_failed(name, err)
	end
end

local managers = managers
local tweak_data = tweak_data
local Global = Global
local backuper = backuper
local backup = backuper.backup
local hijack = backuper.hijack
local os_clock = os.clock
local io_open = ppr_io.open
local tab_insert = table.insert
local ppr_dofile = ppr_dofile
local pairs = pairs

local weapon_skins = tweak_data.blackmarket.weapon_skins

local NetworkMatchMakingSTEAM = NetworkMatchMakingSTEAM
local M_N_matchmake = managers.network.matchmake

local is_server = is_server()

local cfg = ppr_config
local togg_vars = togg_vars

if cfg.StraightToMainMenu then
	ppr_require('Trainer/addons/StraightToMainMenu')
end


-- Protection: blocks other players' forced slow-motion/time-stop on you (PPR Improved)
if cfg.slowmo_protect then
	ppr_require 'Trainer/addons/slowmo_protect'
end

-- Keeps the game from wiping/reshuffling skills & infamy loaded from an edited save
if cfg.DisableSkillsCheck ~= false then
	ppr_require 'Trainer/addons/disable_skills_check'
	if InfamyManager then
		-- v3.2: run the game's own clean-up, but never let it break loading
		local orig_infamy_verify = InfamyManager._verify_loaded_data
		if orig_infamy_verify then
			function InfamyManager:_verify_loaded_data(...)
				local ok, err = pcall(orig_infamy_verify, self, ...)
				if not ok then m_log_error('InfamyManager:_verify_loaded_data', tostring(err)) end
			end
		end
	end
end

-- Removes the small-loot value cap (was part of the old disable_anticheat.lua)
if cfg.NoSmallLootCap ~= false and tweak_data.money_manager then
	tweak_data.money_manager.max_small_loot_value = math.huge
end

if cfg.EnableDebug then
	ppr_require 'Trainer/addons/debugenable'
end

-- Fixes
if cfg.CheckGhostBonus then
	ppr_require 'Trainer/addons/fixes/Check Ghost Bonus'
end

if cfg.CheckLobbyHandler then
	ppr_require 'Trainer/addons/fixes/Check Lobby Handler'
end

if cfg.CheckMeleeAttack then
	ppr_require 'Trainer/addons/fixes/Check Melee Attack'
end

if cfg.CheckMissionDoorDevicePlaced then
	ppr_require 'Trainer/addons/fixes/Check Mission Door device_placed'
end

if cfg.CrashFixer then
	ppr_require 'Trainer/addons/fixes/Crash Fixer'
end

if cfg.LoopFireSounds then
	ppr_require 'Trainer/addons/fixes/Loop Fire Sounds'
end

if cfg.SentryIgnoresShields then
	ppr_require 'Trainer/addons/fixes/Sentry Ignores Shield'
end

-- Tweaks
if cfg.armor_tweaks then
	ppr_require 'Trainer/addons/tweaks/Armor Tweaks/Armor Tweaks'
end

if cfg.vehicle_tweaks then
	ppr_require 'Trainer/addons/tweaks/Vehicle Tweaks/Vehicle Tweaks'
end

if cfg.iceaxe_tweaks then
	ppr_require 'Trainer/addons/tweaks/Melee Weapons/Iceaxe Tweaks'
end

if cfg.CAR4_tweaks then
	ppr_require 'Trainer/addons/tweaks/Primary Weapons/CAR4 Tweak'
end

if cfg.M79_tweaks then
	ppr_require 'Trainer/addons/tweaks/Primary Weapons/M79 Tweaks'
end

if cfg.Bernetti9mm_tweaks then
	ppr_require 'Trainer/addons/tweaks/Secondary Weapons/Bernetti 9mm Tweaks'
end

if cfg.ChinaPuff_tweaks then
	ppr_require 'Trainer/addons/tweaks/Secondary Weapons/China Puff Tweaks'
end

if cfg.Glock18c_tweaks then
	ppr_require 'Trainer/addons/tweaks/Secondary Weapons/Glock 18c Tweaks'
end

if cfg.Ace_tweaks then
	ppr_require 'Trainer/addons/tweaks/Throwable Weapons/Ace Tweaks'
end

if cfg.Frag_Grenade_tweaks then
	ppr_require 'Trainer/addons/tweaks/Throwable Weapons/Frag Grenade Tweaks'
end

if cfg.Bipod_Freelook then
	ppr_require 'Trainer/addons/tweaks/General Weapon Tweaks/Bipod Freelook'
end

if cfg.Bipod_Standing then
	ppr_require 'Trainer/addons/tweaks/General Weapon Tweaks/Bipod Standing'
end

if cfg.Bullet_Penetration then
	ppr_require 'Trainer/addons/tweaks/General Weapon Tweaks/Bullet Penetration'
end

if cfg.Drum_Magazine_Mod then
	ppr_require 'Trainer/addons/tweaks/General Weapon Tweaks/Drum Magazine Mod'
end

if cfg.Gadget_Always_On then
	ppr_require 'Trainer/addons/tweaks/General Weapon Tweaks/Gadget Always On'
end

if cfg.Improved_Tripmine then
	ppr_require 'Trainer/addons/tweaks/General Weapon Tweaks/Improved Tripmine'
end

if cfg.Increased_Pickup_Ammo then
	ppr_require 'Trainer/addons/tweaks/General Weapon Tweaks/Increased Pickup Ammo'
end

if cfg.LMG_Scopes then
	ppr_require 'Trainer/addons/tweaks/General Weapon Tweaks/LMG Scopes'
end

if cfg.projectiles_Tweaks then
	ppr_require 'Trainer/addons/tweaks/General Weapon Tweaks/projectiles Tweaks'
end

if cfg.Rocket_Jump then
	ppr_require 'Trainer/addons/tweaks/General Weapon Tweaks/Rocket Jump'
end

if cfg.Sentry_Gun_Tweaks then
	ppr_require 'Trainer/addons/tweaks/General Weapon Tweaks/Sentry Gun Tweaks'
end

if cfg.Shotgun_Physics then
	ppr_require 'Trainer/addons/tweaks/General Weapon Tweaks/Shotgun Physics'
end

if cfg.Weapon_Parts_Tweaks then
	ppr_require 'Trainer/addons/tweaks/General Weapon Tweaks/Weapon Parts Tweaks'
end

if cfg.Weapon_Tweaks then
	ppr_require 'Trainer/addons/tweaks/General Weapon Tweaks/Weapon Tweaks'
end

try('FreeAssets', function()
if cfg.FreeAssets then
	backup(backuper, 'MoneyManager.get_mission_asset_cost_by_id')
	function MoneyManager.get_mission_asset_cost_by_id()return
		0
	end
	for _, asset in pairs(tweak_data.crime_spree.assets) do
		asset.cost = 0
	end
end
end)
if cfg.FreeBlackMarket then
	ppr_require 'Trainer/addons/FreeBlackMarket'
end

if cfg.FreePreplanning then
	ppr_require 'Trainer/addons/freepreplanning'
end

if cfg.FreeCrimeSpree then
	ppr_require 'Trainer/addons/freecrimespree'
end

if cfg.HostMatters and is_server then
	ppr_require 'Trainer/addons/hostchooseplan'
end

if cfg.NoDropinPause then
	ppr_require('Trainer/addons/nopause')
end

try('NoStatsSynced', function()
if cfg.NoStatsSynced then
	function NetworkAccountSTEAM.publish_statistics() end
end
end)
if cfg.AllPerks then
	ppr_require 'Trainer/addons/all_perks'
end

if cfg.DisableAutoKick then
	Global.game_settings.auto_kick = false
end


if cfg.CrewUnlocker then
	ppr_require 'Trainer/addons/crew_unlocker'
end

if cfg.unlocked_aldstone_items then
	ppr_require 'Trainer/addons/unlock_aldstone_items'
end

if cfg.EnableJobFix then
	ppr_require 'Trainer/addons/jobfix'
end

if cfg.unlocked_hoxton then
	ppr_require 'Trainer/addons/unlock_hoxton'
end

if cfg.unlocked_arbiter then
	ppr_require 'Trainer/addons/unlock_arbiter'
end

if cfg.Extend_Inventory_Slots then
	ppr_require 'Trainer/addons/Extend_Inventory_Slots'
end


try('DebugConsole', function()
if cfg.DebugConsole then
	local console = rawget(_G, 'console')
	if console and console.CreateConsole then console.CreateConsole() end
end
end)
--First launch check
ppr_require('Trainer/menu/firstlaunch')

--Notices users, if crash happened.
if cfg.ExceptionsCrashDetect and managers.exception then
	ppr_require 'Trainer/menu/crashnoticer'
end

-- Enables Secret Skills to work
try('SecretSkills', function()
hijack(backuper, 'PlayerManager.aquire_default_upgrades', function(o, self, ...)
	local skills_path = "Trainer/configs/secret_skills/skills_config.lua"
	local f = io_open(skills_path, "r")
	if f then
		f:close()
		local _, secret_skills, ver = ppr_dofile(skills_path)
		if ver == 2 then
			for _, upgrade in pairs(secret_skills) do
				tab_insert(tweak_data.skilltree.default_upgrades, upgrade)
			end
		end
	end
	o(self, ...)
end)
end)
try('CrewFinder', function()
	if not togg_vars.backup_key then
		togg_vars.backup_key = NetworkMatchMakingSTEAM._BUILD_SEARCH_INTEREST_KEY
	end
	local f = io_open("Trainer/configs/crew_finder/password", "r")
	if f then
		togg_vars.add_string = f:read() or ""
		f:close()
		if togg_vars.add_string ~= "" and M_N_matchmake then
			M_N_matchmake._distance_filter = 3
		end
		NetworkMatchMakingSTEAM._BUILD_SEARCH_INTEREST_KEY = togg_vars.backup_key..togg_vars.add_string
	else
		togg_vars.add_string = ""
	end
end)

try('NoSkinMods', function()
if cfg.NoSkinMods then
	for _, skin in pairs(weapon_skins) do
		if skin.rarity ~= "legendary" then
			skin.default_blueprint = nil
		end
	end
end
end)
--Requires user scripts
ppr_require 'Trainer/custom_auto'