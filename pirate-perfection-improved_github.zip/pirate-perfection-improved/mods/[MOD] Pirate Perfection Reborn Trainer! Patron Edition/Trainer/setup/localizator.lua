--Translation class (original by baldwin, rewritten for PPR Improved Edition)
--Purpose: translate trainer texts using text ids.
--
--Translation files live in Trainer/translations/<Name>.txt and contain a single Lua table:
--	{ text_id = "Localized string", text_id2 = [[Multi
--	line string]], ... }
--
--Usage:
--	local tr = Localization.translate	-- tr.some_id / tr['some_id']
--	Localization:text('id_with_%s', value)	-- string.format with safety
--	Localization:change_language('turkish', true)	-- switch + save choice
--
--What is new in the Improved Edition:
--	* UTF-8 BOM is stripped (the old Turkish file never loaded because of it).
--	* "translate" is ONE persistent table. Changing language refills it in place,
--	  so every script that cached "local tr = Localization.translate" sees the new language.
--	* Missing keys fall back to English and are reported only once each.
--	* Turkish character modes (ppr_config.TurkishCharMode):
--		"safe"  (default) - keeps c/o/u with dots, replaces g-breve, s-cedilla, dotless i, dotted I
--		                    (PAYDAY 2's fonts have no glyphs for those)
--		"full"  - keeps every Turkish character (use it if you have a font mod)
--		"ascii" - plain ASCII only
--	* No network code at all (old version downloaded and executed remote files).

local setmetatable = setmetatable
local rawget = rawget
local pairs = pairs
local type = type
local pcall = pcall
local tostring = tostring
local next = next
local string = string
local str_format = string.format
local str_gsub = string.gsub
local str_lower = string.lower
local io_open = ppr_io.open
local loadstring_execute = loadstring_execute

local DEFAULT_LANGUAGE = 'english'

--Known languages: id -> { file, native name, complete? }
--Only English and Turkish are maintained in the Improved Edition, the others are the old community
--translations (incomplete, missing texts are shown in English).
local LANGUAGES = {
	english					= { file = 'English',				name = 'English',				complete = true },
	turkish					= { file = 'Turkish',				name = 'Türkçe',				complete = true },
	german					= { file = 'German',				name = 'Deutsch' },
	french					= { file = 'French',				name = 'Français' },
	italian					= { file = 'Italian',				name = 'Italiano' },
	spanish					= { file = 'Spanish',				name = 'Español' },
	portuguese				= { file = 'Portuguese',			name = 'Português' },
	russian					= { file = 'Russian',				name = 'Русский' },
	korean					= { file = 'Korean',				name = 'Korean' },
	['chinese-simplified']	= { file = 'Chinese-Simplified',	name = 'Chinese (Simplified)' },
	['chinese-traditional']	= { file = 'Chinese-Traditional',	name = 'Chinese (Traditional)' },
}
--Steam / old config names -> our ids
local ALIASES = {
	schinese = 'chinese-simplified',
	tchinese = 'chinese-traditional',
	brazilian = 'portuguese',
	latam = 'spanish',
	['türkçe'] = 'turkish',
	tr = 'turkish',
	en = 'english',
}
local LANGUAGE_ORDER = { 'english', 'turkish', 'german', 'french', 'italian', 'spanish', 'portuguese', 'russian', 'korean', 'chinese-simplified', 'chinese-traditional' }

local function normalize_language( language )
	if type(language) ~= 'string' or language == '' then
		return nil
	end
	local id = str_lower(language)
	id = ALIASES[id] or id
	if LANGUAGES[id] then
		return id
	end
	return nil
end

--UTF-8 sequences, replaced depending on TurkishCharMode
local TR_UNSAFE = { --Not present in PAYDAY 2 fonts
	["\196\159"] = "g", ["\196\158"] = "G",	-- ğ Ğ
	["\197\159"] = "s", ["\197\158"] = "S",	-- ş Ş
	["\196\177"] = "i", ["\196\176"] = "I",	-- ı İ
}
local TR_LATIN1 = { --Present in PAYDAY 2 fonts (used by German/French), only removed in "ascii" mode
	["\195\167"] = "c", ["\195\135"] = "C",	-- ç Ç
	["\195\182"] = "o", ["\195\150"] = "O",	-- ö Ö
	["\195\188"] = "u", ["\195\156"] = "U",	-- ü Ü
	["\195\162"] = "a", ["\195\130"] = "A",	-- â Â
	["\195\174"] = "i", ["\195\142"] = "I",	-- î Î
	["\195\187"] = "u", ["\195\155"] = "U",	-- û Û
}

local function char_mode()
	local cfg = rawget(_G, 'ppr_config')
	local mode = cfg and rawget(cfg, 'TurkishCharMode')
	if mode == 'full' or mode == 'ascii' then
		return mode
	end
	return 'safe'
end

local function fold_string( s, mode )
	for from, to in pairs(TR_UNSAFE) do
		s = str_gsub(s, from, to)
	end
	if mode == 'ascii' then
		for from, to in pairs(TR_LATIN1) do
			s = str_gsub(s, from, to)
		end
	end
	return s
end

local function fold_table( t, mode )
	if mode == 'full' then
		return t
	end
	for k, v in pairs(t) do
		if type(v) == 'string' then
			t[k] = fold_string(v, mode)
		end
	end
	return t
end

local function read_file( path )
	local f = io_open(path, 'rb')
	if not f then
		return nil
	end
	local contents = f:read('*all')
	f:close()
	return contents
end

--Returns translation table or nil
local function load_language_table( language )
	local info = LANGUAGES[language]
	if not info then
		return nil
	end
	local path = 'Trainer/translations/' .. info.file .. '.txt'
	local contents = read_file(path)
	if not contents or contents == '' then
		m_log_error('localizator', 'Translation file not found:', path)
		return nil
	end
	--Strip UTF-8 BOM (it breaks loadstring: "unexpected symbol near '<\239>'")
	if contents:sub(1, 3) == "\239\187\191" then
		contents = contents:sub(4)
	end
	local ok, result = pcall(loadstring_execute, 'return ' .. contents, {}, path)
	if not ok or type(result) ~= 'table' then
		m_log_error('localizator', 'Translation file is broken:', path, ok and '' or tostring(result))
		return nil
	end
	if language ~= 'english' then
		fold_table(result, char_mode())
	end
	return result
end

local localizator = class()

function localizator:init( language )
	self.translate = {}
	self._missing_reported = {}
	self.default_lan = load_language_table(DEFAULT_LANGUAGE) or {}
	self:_set_fallback()
	self:load_language( normalize_language(language) or DEFAULT_LANGUAGE )
end

function localizator:_set_fallback()
	local this = self
	setmetatable(self.translate, {
		__index = function( _, k )
			local def = this.default_lan[k]
			if not this._missing_reported[k] then
				this._missing_reported[k] = true
				if def == nil then
					m_log_error('localizator.translate', 'No text for', k)
				end
			end
			if def ~= nil then
				return def
			end
			return tostring(k) --Unknown id: show the id itself instead of crashing
		end
	})
end

--Replace contents of the persistent translate table with new_table
function localizator:_fill( new_table )
	local t = self.translate
	for k in pairs(t) do
		t[k] = nil
	end
	for k, v in pairs(new_table) do
		t[k] = v
	end
	self._missing_reported = {}
end

--Loads self.lan or given language. Returns true on success.
function localizator:load_language( language )
	language = normalize_language(language or self.lan) or DEFAULT_LANGUAGE
	local result = load_language_table(language)
	if not result or not next(result) then
		m_log_error('localizator:load_language()', 'Failed to load', language, '- using English')
		language = DEFAULT_LANGUAGE
		result = self.default_lan
	end
	self.lan = language
	self:_fill(result)
	self:register_game_strings()
	return language ~= DEFAULT_LANGUAGE or result == self.default_lan
end

--Switch language at runtime. saveme = true stores the choice in config (menu_config.lua)
function localizator:change_language( language, saveme )
	local ok = self:load_language(language)
	local cfg = rawget(_G, 'ppr_config')
	if saveme and cfg then
		cfg.Language = self.lan
		pcall(cfg) --Saves changed config values (configmt.lua)
	end
	return ok
end

--Reload current language (used when Turkish character mode changes)
function localizator:reload()
	return self:load_language(self.lan)
end

--Formatted text: Localization:text('id', ...)
function localizator:text( id, ... )
	local str = self.translate[id]
	local ok, res = pcall(str_format, str, ...)
	if ok then
		return res
	end
	return str
end

function localizator:current()
	return self.lan
end

function localizator:language_name( language )
	local info = LANGUAGES[normalize_language(language) or self.lan]
	return info and info.name or tostring(language)
end

--Ordered list: { { id = 'english', name = 'English', complete = true }, ... } (only languages whose file exists)
function localizator:available_languages()
	local list = {}
	for _, id in pairs(LANGUAGE_ORDER) do
		local info = LANGUAGES[id]
		local f = io_open('Trainer/translations/' .. info.file .. '.txt', 'rb')
		if f then
			f:close()
			list[#list + 1] = { id = id, name = info.name, complete = info.complete or false }
		end
	end
	return list
end

--Adds "ppr_" prefixed strings (BLT keybind names etc.) to the game's localization manager,
--so SuperBLT's "Mod Keybinds" menu shows them in the trainer language.
function localizator:register_game_strings()
	local M_loc = managers and managers.localization
	if not M_loc or not M_loc.add_localized_strings then
		return
	end
	local strings = {}
	local function collect( t )
		for k, v in pairs(t) do
			if type(k) == 'string' and type(v) == 'string' and k:sub(1, 7) == 'ppr_kb_' then
				strings[k] = v
			end
		end
	end
	collect(self.default_lan)
	collect(self.translate)
	if next(strings) then
		pcall(M_loc.add_localized_strings, M_loc, strings)
	end
end

localizator.normalize_language = normalize_language
localizator.LANGUAGES = LANGUAGES

return localizator
