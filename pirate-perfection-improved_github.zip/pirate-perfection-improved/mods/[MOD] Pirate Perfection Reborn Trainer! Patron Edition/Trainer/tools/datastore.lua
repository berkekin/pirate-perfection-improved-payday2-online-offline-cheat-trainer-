--Purpose: small, safe save/load of Lua tables to files inside the mod folder.
--PPR Improved Edition v3.2. Used by user key bindings, saved teleports and cheat profiles.
--Files are plain Lua ("return { ... }"); loading runs them in an empty sandbox.

local type = type
local pairs = pairs
local tostring = tostring
local format = string.format
local sort = table.sort
local concat = table.concat
local loadstring = loadstring
local setfenv = setfenv
local pcall = pcall

local datastore = {}

local function is_identifier(s)
	return type(s) == 'string' and s:match('^[%a_][%w_]*$') ~= nil
end

local function key_order(a, b)
	local ta, tb = type(a), type(b)
	if ta ~= tb then
		return ta < tb
	end
	if ta == 'number' or ta == 'string' then
		return a < b
	end
	return tostring(a) < tostring(b)
end

local function encode(value, indent, out, seen)
	local t = type(value)
	if t == 'string' then
		out[#out + 1] = format('%q', value)
	elseif t == 'number' then
		if value ~= value or value == math.huge or value == -math.huge then
			out[#out + 1] = '0'
		else
			out[#out + 1] = format('%.17g', value)
		end
	elseif t == 'boolean' then
		out[#out + 1] = value and 'true' or 'false'
	elseif t == 'table' then
		if seen[value] then
			out[#out + 1] = 'nil'
			return
		end
		seen[value] = true
		local keys = {}
		for k, v in pairs(value) do
			local kt, vt = type(k), type(v)
			if (kt == 'string' or kt == 'number') and (vt == 'string' or vt == 'number' or vt == 'boolean' or vt == 'table') then
				keys[#keys + 1] = k
			end
		end
		sort(keys, key_order)
		out[#out + 1] = '{\n'
		local inner = indent .. '\t'
		for _, k in pairs(keys) do
			out[#out + 1] = inner
			if is_identifier(k) then
				out[#out + 1] = k
			else
				out[#out + 1] = '['
				encode(k, inner, out, seen)
				out[#out + 1] = ']'
			end
			out[#out + 1] = ' = '
			encode(value[k], inner, out, seen)
			out[#out + 1] = ',\n'
		end
		out[#out + 1] = indent .. '}'
		seen[value] = nil
	else
		out[#out + 1] = 'nil'
	end
end

--Returns the Lua source text for a table
function datastore.encode(tbl)
	local out = { 'return ' }
	encode(type(tbl) == 'table' and tbl or {}, '', out, {})
	out[#out + 1] = '\n'
	return concat(out)
end

--Turns saved text back into a table (nil on any problem)
function datastore.decode(text)
	if type(text) ~= 'string' or text == '' then
		return nil
	end
	text = text:gsub('^\239\187\191', '')
	local chunk = loadstring(text)
	if not chunk then
		return nil
	end
	setfenv(chunk, {})
	local ok, res = pcall(chunk)
	if ok and type(res) == 'table' then
		return res
	end
	return nil
end

--path is relative to the mod folder, e.g. 'Trainer/configs/teleports.lua'
function datastore.load(path)
	local f = ppr_io.open(path, 'rb')
	if not f then
		return nil
	end
	local text = f:read('*all')
	f:close()
	return datastore.decode(text)
end

function datastore.save(path, tbl)
	local f = ppr_io.open(path, 'wb')
	if not f then
		if m_log_error then
			m_log_error('datastore.save()', 'Failed to write', path)
		end
		return false
	end
	f:write(datastore.encode(tbl))
	f:close()
	return true
end

return datastore
