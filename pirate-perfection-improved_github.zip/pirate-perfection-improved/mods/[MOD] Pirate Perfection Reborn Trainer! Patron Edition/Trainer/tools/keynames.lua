--Purpose: helpers to show which key opens which trainer script (used by the F1 help and F5 hub menus).
--PPR Improved Edition.

local type = type
local rawget = rawget
local string = string
local str_upper = string.upper
local str_gsub = string.gsub

local M = {}

--Pretty key name: 'f5' -> 'F5', 'page up' -> 'Page Up', 'x_button_1' -> 'Mouse 4'
function M.display( key )
	if type(key) ~= 'string' then
		return nil
	end
	local tr = Localization.translate
	local special = {
		x_button_1 = tr.key_mouse4,
		x_button_2 = tr.key_mouse5,
		middle_button = tr.key_mouse3,
		left_button = tr.key_mouse1,
		right_button = tr.key_mouse2,
		wheel_up = tr.key_wheel_up,
		wheel_down = tr.key_wheel_down,
	}
	if special[key] then
		return special[key]
	end
	if key:match('^f%d+$') then
		return str_upper(key)
	end
	--Capitalize words: "page up" -> "Page Up", "num enter" -> "Num Enter"
	return (str_gsub(key, "(%a)([%w]*)", function(first, rest) return str_upper(first) .. rest end))
end

--Key bound to a script file name (file name without .lua, e.g. 'help', 'hub', 'xray'), or nil
function M.key_for( id )
	local KI = rawget(_G, 'KeyInput')
	local fn = KI and rawget(KI, 'filenames')
	if not fn then
		return nil
	end
	local key = rawget(fn, id)
	if type(key) == 'string' then
		return key
	end
	return nil
end

--Callback bound to a script file name (same function instance the hotkey uses), or nil
function M.callback_for( id )
	local key = M.key_for(id)
	local KI = rawget(_G, 'KeyInput')
	local entry = key and KI and KI.keys and KI.keys[key]
	local clbk = entry and entry.callback
	if type(clbk) == 'function' and clbk ~= void then
		return clbk
	end
	return nil
end

--"[F5] " prefix or "" when not bound
function M.prefix( id )
	local key = M.display(M.key_for(id))
	return key and ("[" .. key .. "]  ") or ""
end

return M
