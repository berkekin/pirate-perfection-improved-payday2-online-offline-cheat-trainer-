--Purpose: the list of quick cheats (hub "Quick cheats", key bindings, cheat profiles)
--and one place to switch them on/off. PPR Improved Edition v3.2.
--These are the same plugins as in the original menus, so their on/off state is shared.

local rawget = rawget
local type = type
local pcall = pcall
local ipairs = ipairs
local format = string.format
local tr = Localization.translate

local CHAR = 'Trainer/addons/charmenu/'
local STEALTH = 'Trainer/addons/stealthmenu/'
local INTER = 'Trainer/addons/interactions/'
local EQUIP = 'Trainer/addons/equipment_menu/'

local quick = {}

--false = spacer in menus
quick.LIST = {
	{ id = 'god_mode',			label = 'togg_godmode',				path = CHAR },
	{ id = 'infinite_ammo',		label = 'togg_ammo',				path = CHAR },
	{ id = 'no_recoil',			label = 'togg_recoil',				path = CHAR },
	{ id = 'max_accurate',		label = 'togg_accurate',			path = CHAR },
	{ id = 'infinite_stamina',	label = 'togg_infinite_stamina',	path = CHAR },
	{ id = 'no_fall_damage',	label = 'togg_no_fall_damage',		path = CHAR },
	{ id = 'no_flash_bangs',	label = 'togg_no_flash_bangs',		path = CHAR },
	{ id = 'increase_speed',	label = 'togg_speed',				path = CHAR },
	{ id = 'high_jump',			label = 'togg_jumping',				path = CHAR },
	{ id = 'kill_in_one_hit',	label = 'togg_kill_in_one_hit',		path = CHAR },
	{ id = 'no_bag_cooldown',	label = 'togg_no_bag_cooldown',		path = CHAR },
	false,
	{ id = 'interact_with_all',	label = 'patch_int_all',			path = INTER },
	{ id = 'infinite_distance',	label = 'patch_int_distance',		path = INTER },
	{ id = 'interact_and_look',	label = 'patch_interact_and_look',			path = INTER },
	{ id = 'inf_equipments',	label = 'equip_inf_equipments',		path = EQUIP },
	{ id = 'drill_auto_service',label = 'equip_drill_service',		path = EQUIP },
	false,
	{ id = 'invisible_player',	label = 'invisible_player',			path = STEALTH,	host_only = true },
	{ id = 'dont_call_police',	label = 'people_dont_call_police',	path = STEALTH,	host_only = true },
	{ id = 'disable_cams',		label = 'dis_cams',					path = STEALTH,	host_only = true },
}

quick.BY_ID = {}
for _, q in ipairs(quick.LIST) do
	if q then
		quick.BY_ID[q.id] = q
	end
end

function quick.label(id)
	local q = quick.BY_ID[id]
	return q and tr[q.label] or tostring(id)
end

--true/false: is the plugin switched on right now
function quick.is_on(id)
	local pm = rawget(_G, 'plugins')
	local p = pm and pm.plugins and pm.plugins[id]
	return type(p) == 'table' and p.loaded and true or false
end

--Switch one cheat. want: nil = toggle, true = on, false = off. Returns the new state.
function quick.set(id, want, silent)
	local q = quick.BY_ID[id]
	if not q then
		return nil
	end
	if not inGame() then
		return quick.is_on(id)
	end
	local current = quick.is_on(id)
	if want ~= nil and (want and true or false) == current then
		return current
	end
	if q.host_only and not current and not isHost() then
		if not silent then
			pcall(show_hint, tr.kb_host_only)
		end
		return current
	end
	local lp = rawget(_G, 'load_plugin')
	if type(lp) ~= 'function' then
		return current
	end
	local ok, err = pcall(function() lp(q.path)(id) end)
	if not ok and m_log_error then
		m_log_error('quickcheats.set()', id, tostring(err))
	end
	local now = quick.is_on(id)
	if not silent then
		pcall(show_hint, format('%s: %s', quick.label(id), now and tr.state_on or tr.state_off))
	end
	return now
end

function quick.toggle(id)
	return quick.set(id, nil)
end

--ids of quick cheats that are on right now (in list order)
function quick.active_ids()
	local res = {}
	for _, q in ipairs(quick.LIST) do
		if q and quick.is_on(q.id) then
			res[#res + 1] = q.id
		end
	end
	return res
end

return quick
