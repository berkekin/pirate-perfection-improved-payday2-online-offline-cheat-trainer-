--Purpose: change trainer keys in game (no need to edit keyconfig.lua) and bind quick cheats
--to keys. PPR Improved Edition v3.2.
--Saved in Trainer/configs/user_keybinds.lua:
--	actions = { [script id] = "key name" or "none" }   (script id = file name, e.g. "hub", "xray")
--	quick   = { [plugin id] = "key name" }              (see Trainer/tools/quickcheats.lua)

local pairs = pairs
local ipairs = ipairs
local type = type
local pcall = pcall
local rawget = rawget
local tostring = tostring

local datastore = ppr_require 'Trainer/tools/datastore'
local quick = ppr_require 'Trainer/tools/quickcheats'

local FILE = 'Trainer/configs/user_keybinds.lua'
local QUICK_PREFIX = 'quick:'

local ub = rawget(_G, 'PPR_UserBinds')
if type(ub) == 'table' then
	return ub
end
ub = {}
rawset(_G, 'PPR_UserBinds', ub)

ub.FILE = FILE
ub.defaults = {}	--script id -> key from keyconfig.lua

local function load_data()
	local d = datastore.load(FILE) or {}
	d.actions = type(d.actions) == 'table' and d.actions or {}
	d.quick = type(d.quick) == 'table' and d.quick or {}
	return d
end
ub.data = load_data()

function ub.save()
	return datastore.save(FILE, ub.data)
end

local function ki()
	return rawget(_G, 'KeyInput')
end

local function find_key(k, id)
	for key, value in pairs(k.keys) do
		if value.id == id then
			return key, value
		end
	end
end

function ub.key_of(id)
	local k = ki()
	if not k then
		return nil
	end
	return (find_key(k, id))
end

local function quick_value(pid)
	return {
		id = QUICK_PREFIX .. pid,
		quick = pid,
		ig_chat = false,
		callback = function() quick.toggle(pid) end,
	}
end

--Puts value on key. Whatever used that key before becomes unbound (and is remembered so).
local function place(k, key, value, remember)
	local displaced = k.keys[key]
	if displaced and displaced ~= value and displaced.id then
		k.unbound[displaced.id] = displaced
		k.keys[key] = nil
		if remember then
			local pid = displaced.quick
			if pid then
				ub.data.quick[pid] = nil
			else
				ub.data.actions[displaced.id] = 'none'
			end
		end
		ub.last_displaced = displaced.id
	end
	k.keys[key] = value
end

--Bind a trainer action (script id) to key; key = 'none' removes the key.
function ub.bind_action(id, key, from_file)
	local k = ki()
	if not k then
		return false
	end
	k.unbound = k.unbound or {}
	ub.last_displaced = nil
	local old_key, value = find_key(k, id)
	value = value or k.unbound[id]
	if not value then
		return false
	end
	if old_key then
		k.keys[old_key] = nil
	end
	k.unbound[id] = nil
	if not key or key == 'none' then
		k.unbound[id] = value
	else
		place(k, key, value, not from_file)
	end
	if not from_file then
		if key == ub.defaults[id] then
			ub.data.actions[id] = nil
		else
			ub.data.actions[id] = key or 'none'
		end
		ub.save()
		k:help_setup()
	end
	return true
end

--Bind a quick cheat (plugin id) to key; key = 'none' removes it.
function ub.bind_quick(pid, key, from_file)
	local k = ki()
	if not k or not quick.BY_ID[pid] then
		return false
	end
	k.unbound = k.unbound or {}
	ub.last_displaced = nil
	local old_key, value = find_key(k, QUICK_PREFIX .. pid)
	if old_key then
		k.keys[old_key] = nil
	end
	if key and key ~= 'none' then
		place(k, key, value or quick_value(pid), not from_file)
	end
	if not from_file then
		ub.data.quick[pid] = (key and key ~= 'none') and key or nil
		ub.save()
		k:help_setup()
	end
	return true
end

function ub.reset_action(id)
	local def = ub.defaults[id]
	ub.data.actions[id] = nil
	return ub.bind_action(id, def or 'none')
end

function ub.reset_all()
	ub.data = { actions = {}, quick = {} }
	ub.save()
	local k = ki()
	if not k then
		return
	end
	--Rebuild from keyconfig.lua
	local cfg = ppr_dofile((rawget(_G, 'ppr_config') and ppr_config.keyconfig) or 'Trainer/keyconfig.lua')
	if type(cfg) == 'table' then
		k.keys = cfg
		k.unbound = {}
		k:help_setup()
	end
end

--v3.2 actions without a default key (bind them in Hub > Key bindings)
local function teleport_call(fn)
	return function()
		pcall(ppr_require, 'Trainer/menu/ingame/teleport_menu')
		local M = rawget(_G, 'PPR_Teleports')
		if M and type(M[fn]) == 'function' then
			M[fn]()
		end
	end
end
local EXTRA = {
	{ id = 'keybinds_menu', handled_callback = 'Trainer/menu/keybinds_menu' },
	{ id = 'profiles_menu', handled_callback = 'Trainer/menu/profiles_menu' },
	{ id = 'teleport_menu', handled_callback = 'Trainer/menu/ingame/teleport_menu' },
	{ id = 'tp_save', callback = teleport_call('save_here') },
	{ id = 'tp_undo', callback = teleport_call('undo') },
}

--Called once at start (setup/init.lua), after keyconfig.lua was loaded
function ub.apply(k)
	k = k or ki()
	if not k then
		return
	end
	k.unbound = k.unbound or {}
	for _, e in ipairs(EXTRA) do
		if not find_key(k, e.id) and not k.unbound[e.id] then
			k.unbound[e.id] = { id = e.id, handled_callback = e.handled_callback, callback = e.callback }
		end
	end
	for key, value in pairs(k.keys) do
		if value.id and not ub.defaults[value.id] then
			ub.defaults[value.id] = key
		end
	end
	for id, key in pairs(ub.data.actions) do
		pcall(ub.bind_action, id, key, true)
	end
	for pid, key in pairs(ub.data.quick) do
		pcall(ub.bind_quick, pid, key, true)
	end
	k:help_setup()
end

--All script ids that can be bound (bound and unbound), for the menu
function ub.action_ids()
	local k = ki()
	local res, seen = {}, {}
	if not k then
		return res
	end
	for _, value in pairs(k.keys) do
		local id = value.id
		if id and not value.quick and not seen[id] then
			seen[id] = true
			res[#res + 1] = id
		end
	end
	for id, value in pairs(k.unbound or {}) do
		if not value.quick and not seen[id] then
			seen[id] = true
			res[#res + 1] = id
		end
	end
	table.sort(res)
	return res
end

-------------------------------------------------------------------------------
--Key capture: waits for the next key (or extra mouse button) and calls done(key).
--done(nil) when cancelled with Esc or after 10 seconds.
local NOT_ALLOWED = { ['esc'] = true, ['enter'] = true, ['num enter'] = true }
local MOUSE_NAMES = { [2] = 'middle_button', [3] = 'x_button_1', [4] = 'x_button_2', [5] = 'x_button_3', [6] = 'x_button_4', [7] = 'x_button_5' }

function ub.capture(done)
	local k = ki()
	local kb = Input:keyboard()
	local mouse = Input:mouse()
	local start_t = Application:time()
	local was_running = k and k.upd_id ~= nil
	if was_running then
		k:run_updating(false)
		k.upd_id = nil
	end
	local finished = false
	local function finish(key)
		if finished then
			return
		end
		finished = true
		StopLoopIdent('ppr_key_capture')
		if was_running then
			k:run_updating(true)
		end
		pcall(done, key)
	end
	RunNewLoopIdent('ppr_key_capture', function()
		local now = Application:time()
		if now - start_t < 0.35 then
			return	--ignore the key/click that opened the capture
		end
		if now - start_t > 10 then
			return finish(nil)
		end
		local list = kb:pressed_list()
		for i = 1, #list do
			local name = kb:button_name_str(list[i])
			if name == 'esc' then
				return finish(nil)
			end
			if name and name ~= '' and not NOT_ALLOWED[name] then
				return finish(name)
			end
		end
		for idx, name in pairs(MOUSE_NAMES) do
			if mouse:pressed(mouse:button_name(idx)) then
				return finish(name)
			end
		end
	end)
end

return ub
